<article class="box post">
	<a href="#" class="image featured"><img src="<?=base_url()?>images/berita/<?=$data->gambar?>" alt="a" /></a>
	<header>
		<h3><?=$data->judul?></h3>
		<p>Lorem ipsum dolor sit amet feugiat</p>
	</header>
	<p>
		<?=$data->isi_konten?>
	</p>
	
	
	
</article>