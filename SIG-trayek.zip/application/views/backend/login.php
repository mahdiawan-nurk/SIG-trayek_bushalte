
<!DOCTYPE html>
<html>
<head>
<title>LOGIN ADMIN SIG TRAYEK BUS</title>
<?php $url=base_url().'assets/login/';?>
<meta name="viewport" content="width=device-width, initial-scale=1">
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<meta name="keywords" content="Fancy Login Form Responsive web template, Bootstrap Web Templates, Flat Web Templates, Android Compatible web template, Smartphone Compatible web template, free webdesigns for Nokia, Samsung, LG, SonyEricsson, Motorola web design" />
<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false);
		function hideURLbar(){ window.scrollTo(0,1); } </script>
<!-- //custom-theme -->
<link href="<?=$url?>css/font-awesome.css" rel="stylesheet">
<link href="<?=$url?>css/style.css" rel="stylesheet" type="text/css" media="all" />
<link href="//fonts.googleapis.com/css?family=Catamaran:100,200,300,400,500,600,700,800,900" rel="stylesheet">
</head>
<body class="bg-agileinfo">
	<h1 class="agile-head">SIG TRAYEK LOGIN ADMIN</h1>
    <div class="container-w3l">
			<div class="image">
				<div class="agileits-img">
				</div>
			</div>
			<div class="main-head">
				<form action="autentikasi.html" method="post" class="form-1">
					<h2>login</h2>
					<p class="field">
						<input type="text" name="email" placeholder="Username or email" required>
						<i class="icon-user icon-large"></i>
					</p>
						<p class="field">
							<input type="password" name="password" placeholder="Password" required>
							<i class="icon-lock icon-large"></i>
					   </p>
					<p class="submit">
						<button type="submit" name="submit" value="submit"><i class="icon-arrow-right icon-large"></i></button>
					</p>
				</form>
			</div>	
			<div class="clearfix"></div>
	</div>	
	<div class="agileits_w3layouts-footer text-center">
		<p>© 2017 Fancy Login Form. All rights reserved | Design by <a href="//w3layouts.com/">W3layouts</a></p>
	</div>
    </body>
</html>