<div class="col-lg-12">
    <div class="card">
        <div class="card-header">
            <strong class="card-title">Basic Table</strong>
        </div>
        <div class="card-body">
            <table class="table" id="tab">
                <thead>
                    <tr>
                        <th scope="col">#</th>
                        <th scope="col">Rute Pergi</th>
                        <th scope="col">Rute Pulang</th>
                        <th scope="col">Pemberhentian</th>
                        <th scope="col">Waktu</th>
                        <th scope="col">Jarak Tempuh</th>
                        <th scope="col">Act</th>
                    </tr>
                </thead>
                <tbody>
                    <tr>
                        <th scope="row">1</th>
                        <td>Mark</td>
                        <td>Otto</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                        <td>@mdo</td>
                    </tr>
                 
                </tbody>
            </table>
        </div>
    </div>
</div>