<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-04-04 13:24:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:24:41 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:24:42 --> Total execution time: 0.0171
DEBUG - 2021-04-04 13:26:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:26:35 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:26:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:26:52 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:26:52 --> Total execution time: 0.0215
DEBUG - 2021-04-04 13:26:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:26:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:26:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:26:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:26:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:26:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:26:54 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:26:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:26:54 --> Total execution time: 0.0156
DEBUG - 2021-04-04 13:26:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:26:56 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:26:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:26:56 --> Total execution time: 0.0151
DEBUG - 2021-04-04 13:35:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:35:59 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:35:59 --> Total execution time: 0.0238
DEBUG - 2021-04-04 13:36:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:36:01 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:36:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:36:01 --> Total execution time: 0.0183
DEBUG - 2021-04-04 13:36:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:36:22 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:36:22 --> Total execution time: 0.0270
DEBUG - 2021-04-04 13:37:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:26 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:37:26 --> Total execution time: 0.0160
DEBUG - 2021-04-04 13:37:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:37:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-04 13:37:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:37:52 --> UTF-8 Support Enabled
ERROR - 2021-04-04 13:37:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:58 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:37:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:37:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:37:59 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-04 13:38:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:38:25 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:38:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:38:25 --> Total execution time: 0.0162
DEBUG - 2021-04-04 13:38:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:38:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:38:30 --> 404 Page Not Found: Left-sidebarhtml/index
DEBUG - 2021-04-04 13:39:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:39:04 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:39:04 --> Total execution time: 0.0148
DEBUG - 2021-04-04 13:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:39:37 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:39:37 --> Total execution time: 0.0157
DEBUG - 2021-04-04 13:39:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:39:42 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:39:42 --> Total execution time: 0.0146
DEBUG - 2021-04-04 13:39:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:39:59 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:39:59 --> Total execution time: 0.0151
DEBUG - 2021-04-04 13:40:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:40:09 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:40:09 --> Total execution time: 0.0150
DEBUG - 2021-04-04 13:40:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:40:16 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:40:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:40:16 --> Total execution time: 0.0145
DEBUG - 2021-04-04 13:40:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:40:37 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:40:37 --> Total execution time: 0.0146
DEBUG - 2021-04-04 13:40:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:40:52 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:40:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:40:52 --> Total execution time: 0.0150
DEBUG - 2021-04-04 13:49:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:25 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:25 --> Total execution time: 0.0168
DEBUG - 2021-04-04 13:49:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:25 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Assets/js
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Images/pic03.jpg
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Images/pic02.jpg
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Images/pic04.jpg
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Images/pic05.jpg
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Images/pic06.jpg
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Images/pic07.jpg
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Images/pic08.jpg
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Images/pic09.jpg
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Images/pic10.jpg
DEBUG - 2021-04-04 13:49:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:26 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:27 --> Total execution time: 0.0151
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Images/pic03.jpg
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Images/pic04.jpg
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Images/pic05.jpg
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Images/pic02.jpg
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Images/pic06.jpg
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Assets/js
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Images/pic10.jpg
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Images/pic08.jpg
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Images/pic07.jpg
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Images/pic09.jpg
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:27 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:28 --> Total execution time: 0.0155
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Images/pic03.jpg
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Images/pic02.jpg
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Images/pic05.jpg
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Images/pic04.jpg
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Images/pic06.jpg
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Images/pic07.jpg
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Images/pic08.jpg
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Images/pic09.jpg
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Images/pic10.jpg
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:49:28 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-04 13:49:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:37 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:49:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:37 --> Total execution time: 0.0156
DEBUG - 2021-04-04 13:49:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:49:50 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:49:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:49:50 --> Total execution time: 0.0153
DEBUG - 2021-04-04 13:51:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:51:12 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:51:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:51:12 --> Total execution time: 0.0160
DEBUG - 2021-04-04 13:51:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:51:23 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:51:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:51:23 --> Total execution time: 0.0155
DEBUG - 2021-04-04 13:51:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:51:33 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:51:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:51:33 --> Total execution time: 0.0150
DEBUG - 2021-04-04 13:51:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:51:36 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:51:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:51:36 --> Total execution time: 0.0154
DEBUG - 2021-04-04 13:51:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:51:37 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:51:37 --> Total execution time: 0.0149
DEBUG - 2021-04-04 13:51:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:51:37 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:51:37 --> Total execution time: 0.0156
DEBUG - 2021-04-04 13:51:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:51:38 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:51:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:51:38 --> Total execution time: 0.0158
DEBUG - 2021-04-04 13:52:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:52:04 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:52:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:52:04 --> Total execution time: 0.0160
DEBUG - 2021-04-04 13:52:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:52:06 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:52:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:52:06 --> Total execution time: 0.0181
DEBUG - 2021-04-04 13:52:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:52:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:52:15 --> 404 Page Not Found: Indexhtml/index
DEBUG - 2021-04-04 13:52:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:52:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:52:29 --> 404 Page Not Found: Vendor/bootstrap
DEBUG - 2021-04-04 13:53:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:53:24 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:53:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:53:24 --> Total execution time: 0.0165
DEBUG - 2021-04-04 13:53:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:53:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:53:25 --> 404 Page Not Found: Vendor/bootstrap
DEBUG - 2021-04-04 13:53:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:53:26 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:53:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:53:26 --> Total execution time: 0.0163
DEBUG - 2021-04-04 13:53:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:53:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 13:53:26 --> 404 Page Not Found: Vendor/bootstrap
DEBUG - 2021-04-04 13:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:53:46 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:53:46 --> Total execution time: 0.0179
DEBUG - 2021-04-04 13:54:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:54:08 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:54:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:54:08 --> Total execution time: 0.0152
DEBUG - 2021-04-04 13:54:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:54:35 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:54:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:54:35 --> Total execution time: 0.0165
DEBUG - 2021-04-04 13:58:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:58:37 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:58:37 --> Total execution time: 0.0159
DEBUG - 2021-04-04 13:58:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:58:41 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:58:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:58:41 --> Total execution time: 0.0145
DEBUG - 2021-04-04 13:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 13:59:48 --> No URI present. Default controller set.
DEBUG - 2021-04-04 13:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 13:59:48 --> Total execution time: 0.0168
DEBUG - 2021-04-04 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 14:00:02 --> No URI present. Default controller set.
DEBUG - 2021-04-04 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 14:00:02 --> Total execution time: 0.0321
DEBUG - 2021-04-04 14:02:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 14:02:05 --> No URI present. Default controller set.
DEBUG - 2021-04-04 14:02:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 14:02:05 --> Total execution time: 0.0153
DEBUG - 2021-04-04 14:02:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 14:02:55 --> No URI present. Default controller set.
DEBUG - 2021-04-04 14:02:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 14:02:55 --> Total execution time: 0.0153
DEBUG - 2021-04-04 14:03:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 14:03:29 --> No URI present. Default controller set.
DEBUG - 2021-04-04 14:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 14:03:29 --> Total execution time: 0.0151
DEBUG - 2021-04-04 14:03:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 14:03:35 --> No URI present. Default controller set.
DEBUG - 2021-04-04 14:03:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 14:03:35 --> Total execution time: 0.0150
DEBUG - 2021-04-04 14:03:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 14:03:42 --> No URI present. Default controller set.
DEBUG - 2021-04-04 14:03:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 14:03:42 --> Total execution time: 0.0149
DEBUG - 2021-04-04 14:03:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 14:03:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-04 14:03:42 --> 404 Page Not Found: Simple_pagehtml/index
DEBUG - 2021-04-04 14:04:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 14:04:15 --> No URI present. Default controller set.
DEBUG - 2021-04-04 14:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 14:04:15 --> Total execution time: 0.0155
DEBUG - 2021-04-04 14:04:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 14:04:31 --> No URI present. Default controller set.
DEBUG - 2021-04-04 14:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 14:04:31 --> Total execution time: 0.0262
DEBUG - 2021-04-04 14:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 14:05:16 --> No URI present. Default controller set.
DEBUG - 2021-04-04 14:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 14:05:16 --> Total execution time: 0.0219
DEBUG - 2021-04-04 14:05:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-04 14:05:28 --> No URI present. Default controller set.
DEBUG - 2021-04-04 14:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-04 14:05:28 --> Total execution time: 0.0163
