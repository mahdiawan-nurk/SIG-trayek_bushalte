<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-04-05 18:07:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:07:36 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:07:37 --> Total execution time: 0.2069
DEBUG - 2021-04-05 18:25:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:25:17 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:25:17 --> Total execution time: 0.0200
DEBUG - 2021-04-05 18:25:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:25:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:25:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:25:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-05 18:25:18 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:26:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:26:08 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:26:08 --> Total execution time: 0.0309
DEBUG - 2021-04-05 18:26:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:26:22 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:26:22 --> Total execution time: 0.0156
DEBUG - 2021-04-05 18:26:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:26:22 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:26:22 --> Total execution time: 0.0162
DEBUG - 2021-04-05 18:26:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:26:23 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:26:23 --> Total execution time: 0.0157
DEBUG - 2021-04-05 18:26:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:26:23 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:26:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:26:23 --> Total execution time: 0.0161
DEBUG - 2021-04-05 18:26:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:26:48 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:26:48 --> Total execution time: 0.0188
DEBUG - 2021-04-05 18:26:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:26:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:26:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:26:48 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:26:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:26:48 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:27:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:27:03 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:27:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:27:03 --> Total execution time: 0.0156
DEBUG - 2021-04-05 18:27:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:27:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:27:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:27:03 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:27:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:27:03 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:27:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:27:05 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:27:05 --> Total execution time: 0.0217
DEBUG - 2021-04-05 18:28:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:28:01 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:28:01 --> Total execution time: 0.0162
DEBUG - 2021-04-05 18:28:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:28:58 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:28:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:28:58 --> Total execution time: 0.0158
DEBUG - 2021-04-05 18:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:31:15 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:31:15 --> Total execution time: 0.0163
DEBUG - 2021-04-05 18:31:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:31:24 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:31:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:31:24 --> Total execution time: 0.0174
DEBUG - 2021-04-05 18:31:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:31:52 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:31:52 --> Total execution time: 0.0228
DEBUG - 2021-04-05 18:32:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:32:44 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:32:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:32:44 --> Total execution time: 0.0209
DEBUG - 2021-04-05 18:32:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:32:53 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:32:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:32:53 --> Total execution time: 0.0347
DEBUG - 2021-04-05 18:34:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:34:12 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:34:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:34:12 --> Total execution time: 0.0161
DEBUG - 2021-04-05 18:35:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:35:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:35:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:35:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:35:18 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-05 18:35:18 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:35:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:35:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:35:19 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:35:19 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:35:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:35:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:35:19 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:35:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:35:19 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:35:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:35:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:35:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:35:20 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:35:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:35:20 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:35:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:35:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:35:26 --> UTF-8 Support Enabled
ERROR - 2021-04-05 18:35:26 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:35:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:35:26 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:35:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:35:46 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:35:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:35:46 --> Total execution time: 0.0506
DEBUG - 2021-04-05 18:36:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:36:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:36:06 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:36:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:36:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:36:06 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:36:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:36:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:36:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:36:06 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:36:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:36:06 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:36:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:36:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:36:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:36:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:36:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:36:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:36:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:36:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:36:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:36:08 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-05 18:36:08 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:36:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:36:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:36:13 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:36:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 18:36:13 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 18:36:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:36:20 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:36:20 --> Total execution time: 0.0162
DEBUG - 2021-04-05 18:39:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:39:29 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:39:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:39:29 --> Total execution time: 0.0425
DEBUG - 2021-04-05 18:39:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:39:47 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:39:47 --> Total execution time: 0.0206
DEBUG - 2021-04-05 18:39:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 18:39:55 --> No URI present. Default controller set.
DEBUG - 2021-04-05 18:39:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 18:39:55 --> Total execution time: 0.0191
DEBUG - 2021-04-05 21:14:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:14:13 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:14:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:14:13 --> Total execution time: 0.0173
DEBUG - 2021-04-05 21:14:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:14:24 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:14:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:14:24 --> Total execution time: 0.0160
DEBUG - 2021-04-05 21:14:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:14:59 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:14:59 --> Total execution time: 0.0195
DEBUG - 2021-04-05 21:15:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:15:13 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:15:14 --> Total execution time: 0.0169
DEBUG - 2021-04-05 21:19:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:19:56 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:19:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:19:56 --> Total execution time: 0.0187
DEBUG - 2021-04-05 21:20:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:20:10 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:20:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:20:10 --> Total execution time: 0.0228
DEBUG - 2021-04-05 21:20:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:20:43 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:20:43 --> Total execution time: 0.0171
DEBUG - 2021-04-05 21:21:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:21:23 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:21:23 --> Total execution time: 0.0283
DEBUG - 2021-04-05 21:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:21:31 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:21:31 --> Total execution time: 0.0157
DEBUG - 2021-04-05 21:21:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:21:59 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:21:59 --> Total execution time: 0.0158
DEBUG - 2021-04-05 21:22:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:22:03 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:22:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:22:03 --> Total execution time: 0.0156
DEBUG - 2021-04-05 21:23:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:23:17 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:23:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:23:17 --> Total execution time: 0.0286
DEBUG - 2021-04-05 21:23:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:23:33 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:23:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:23:33 --> Total execution time: 0.0335
DEBUG - 2021-04-05 21:23:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:23:43 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:23:43 --> Total execution time: 0.0170
DEBUG - 2021-04-05 21:24:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:24:00 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:24:00 --> Total execution time: 0.0181
DEBUG - 2021-04-05 21:24:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:24:59 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:24:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:24:59 --> Total execution time: 0.0305
DEBUG - 2021-04-05 21:25:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:25:08 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:25:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:25:08 --> Total execution time: 0.0310
DEBUG - 2021-04-05 21:25:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:25:12 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:25:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:25:12 --> Total execution time: 0.0158
DEBUG - 2021-04-05 21:25:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:25:22 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:25:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:25:22 --> Total execution time: 0.0181
DEBUG - 2021-04-05 21:25:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:25:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:25:22 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:25:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:25:22 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:26:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:26:39 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:26:39 --> Total execution time: 0.0158
DEBUG - 2021-04-05 21:26:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:26:55 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:26:55 --> Total execution time: 0.0220
DEBUG - 2021-04-05 21:27:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:27:42 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:27:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:27:42 --> Total execution time: 0.0250
DEBUG - 2021-04-05 21:27:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:27:54 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:27:54 --> Total execution time: 0.0174
DEBUG - 2021-04-05 21:28:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:28:17 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:28:17 --> Total execution time: 0.0215
DEBUG - 2021-04-05 21:28:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:28:51 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:28:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:28:51 --> Total execution time: 0.0210
DEBUG - 2021-04-05 21:29:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:29:14 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:29:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:29:14 --> Total execution time: 0.0189
DEBUG - 2021-04-05 21:29:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:29:24 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:29:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:29:24 --> Total execution time: 0.0236
DEBUG - 2021-04-05 21:29:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:29:36 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:29:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:29:36 --> Total execution time: 0.0191
DEBUG - 2021-04-05 21:30:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:04 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:04 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:06 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:06 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:10 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:10 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-05 21:30:11 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:11 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:11 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:12 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:12 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:12 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:12 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:12 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:12 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:13 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:13 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:14 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:30:14 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:30:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:16 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:30:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:30:16 --> Total execution time: 0.0159
DEBUG - 2021-04-05 21:30:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:30:48 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:30:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:30:48 --> Total execution time: 0.0155
DEBUG - 2021-04-05 21:31:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:31:01 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:31:01 --> Total execution time: 0.0198
DEBUG - 2021-04-05 21:31:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:31:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:31:03 --> 404 Page Not Found: Indexhtml/index
DEBUG - 2021-04-05 21:31:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:31:16 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:31:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:31:16 --> Total execution time: 0.0207
DEBUG - 2021-04-05 21:31:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:31:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:31:19 --> 404 Page Not Found: Indexhtml/index
DEBUG - 2021-04-05 21:31:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:31:29 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:31:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:31:29 --> Total execution time: 0.0196
DEBUG - 2021-04-05 21:31:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:31:33 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:31:33 --> Total execution time: 0.0275
DEBUG - 2021-04-05 21:32:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:32:09 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:32:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:32:09 --> Total execution time: 0.0175
DEBUG - 2021-04-05 21:34:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:34:05 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:34:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:34:06 --> Total execution time: 0.0166
DEBUG - 2021-04-05 21:34:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:34:45 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:34:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:34:45 --> Total execution time: 0.0157
DEBUG - 2021-04-05 21:35:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:35:12 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:35:12 --> Total execution time: 0.0165
DEBUG - 2021-04-05 21:35:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:35:32 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:35:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:35:32 --> Total execution time: 0.0303
DEBUG - 2021-04-05 21:36:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:36:00 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:36:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:36:00 --> Total execution time: 0.0169
DEBUG - 2021-04-05 21:36:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:36:13 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:36:13 --> Total execution time: 0.0268
DEBUG - 2021-04-05 21:36:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:36:22 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:36:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:36:22 --> Total execution time: 0.0162
DEBUG - 2021-04-05 21:36:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:36:34 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:36:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:36:34 --> Total execution time: 0.0164
DEBUG - 2021-04-05 21:36:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:36:53 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:36:53 --> Total execution time: 0.0182
DEBUG - 2021-04-05 21:37:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:37:01 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:37:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:37:01 --> Total execution time: 0.0255
DEBUG - 2021-04-05 21:37:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:37:42 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:37:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:37:42 --> Total execution time: 0.0202
DEBUG - 2021-04-05 21:37:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:37:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:37:49 --> 404 Page Not Found: Indexhtml/index
DEBUG - 2021-04-05 21:38:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:38:08 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:38:08 --> Total execution time: 0.0244
DEBUG - 2021-04-05 21:38:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:38:10 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:38:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:38:10 --> Total execution time: 0.0156
DEBUG - 2021-04-05 21:38:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:38:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:38:11 --> 404 Page Not Found: Indexhtml/index
DEBUG - 2021-04-05 21:40:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:40:08 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:40:08 --> Total execution time: 0.0178
DEBUG - 2021-04-05 21:40:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:40:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:40:09 --> 404 Page Not Found: Welcome/bus
DEBUG - 2021-04-05 21:40:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:40:37 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:40:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:40:37 --> Total execution time: 0.0165
DEBUG - 2021-04-05 21:40:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:40:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:40:38 --> Total execution time: 0.0151
DEBUG - 2021-04-05 21:43:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:43:48 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:43:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:43:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:43:48 --> Total execution time: 0.0601
DEBUG - 2021-04-05 21:43:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:43:57 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:43:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:43:57 --> Total execution time: 0.0183
DEBUG - 2021-04-05 21:43:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:43:57 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:43:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:43:57 --> Total execution time: 0.0167
DEBUG - 2021-04-05 21:43:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:43:57 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:43:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:43:57 --> Total execution time: 0.0178
DEBUG - 2021-04-05 21:43:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:43:57 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:43:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:43:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:43:57 --> Total execution time: 0.0169
DEBUG - 2021-04-05 21:43:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:43:58 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:43:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:43:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:43:58 --> Total execution time: 0.0166
DEBUG - 2021-04-05 21:44:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:44:16 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:44:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:44:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:44:16 --> Total execution time: 0.0222
DEBUG - 2021-04-05 21:44:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:44:21 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:44:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:44:21 --> Total execution time: 0.0151
DEBUG - 2021-04-05 21:44:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:44:31 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:44:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:44:31 --> Total execution time: 0.0177
DEBUG - 2021-04-05 21:44:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:44:42 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:44:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:44:42 --> Total execution time: 0.0159
DEBUG - 2021-04-05 21:44:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:44:42 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:44:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:44:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:44:42 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:44:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:44:51 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:44:52 --> Total execution time: 0.0158
DEBUG - 2021-04-05 21:45:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:45:10 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:45:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:45:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:45:10 --> Total execution time: 0.0178
DEBUG - 2021-04-05 21:45:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:45:20 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:45:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:45:20 --> Total execution time: 0.0172
DEBUG - 2021-04-05 21:45:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:45:30 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:45:30 --> Total execution time: 0.0211
DEBUG - 2021-04-05 21:45:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:45:41 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:45:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:45:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:45:41 --> Total execution time: 0.0305
DEBUG - 2021-04-05 21:45:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:45:55 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:45:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:45:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:45:55 --> Total execution time: 0.0174
DEBUG - 2021-04-05 21:46:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:46:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:46:00 --> Total execution time: 0.0159
DEBUG - 2021-04-05 21:47:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:47:17 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:47:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:47:17 --> Total execution time: 0.0170
DEBUG - 2021-04-05 21:47:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:47:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:47:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:47:17 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-05 21:47:17 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:47:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:47:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:47:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:47:18 --> Total execution time: 0.0157
DEBUG - 2021-04-05 21:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:49:33 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:49:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:49:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 97
DEBUG - 2021-04-05 21:49:33 --> Total execution time: 0.0184
DEBUG - 2021-04-05 21:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:49:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:49:33 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:49:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:49:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:49:33 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:49:41 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:49:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:49:46 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:49:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:49:51 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:49:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:49:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:49:52 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:49:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:50:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:50:11 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:50:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:50:11 --> Total execution time: 0.0163
DEBUG - 2021-04-05 21:50:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:50:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:50:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:50:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:50:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-05 21:50:11 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:50:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:50:31 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:50:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:50:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:50:31 --> Total execution time: 0.0168
DEBUG - 2021-04-05 21:50:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:50:52 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:50:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:50:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:50:52 --> Total execution time: 0.0184
DEBUG - 2021-04-05 21:50:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:50:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:50:53 --> 404 Page Not Found: Homehtml/index
DEBUG - 2021-04-05 21:51:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:51:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:51:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:51:11 --> Total execution time: 0.0226
DEBUG - 2021-04-05 21:51:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:51:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:51:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:51:13 --> Total execution time: 0.0161
DEBUG - 2021-04-05 21:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:51:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:51:31 --> Total execution time: 0.0171
DEBUG - 2021-04-05 21:51:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:51:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:51:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:51:37 --> Total execution time: 0.0188
DEBUG - 2021-04-05 21:51:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:51:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:51:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:51:40 --> Total execution time: 0.0171
DEBUG - 2021-04-05 21:51:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:51:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:51:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:51:41 --> Total execution time: 0.0162
DEBUG - 2021-04-05 21:51:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:51:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:51:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:51:57 --> Total execution time: 0.0249
DEBUG - 2021-04-05 21:51:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:51:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:51:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:51:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:51:57 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-05 21:51:57 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:51:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:51:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:51:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:51:59 --> Total execution time: 0.0161
DEBUG - 2021-04-05 21:52:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:52:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:52:16 --> 404 Page Not Found: Indexhtml/index
DEBUG - 2021-04-05 21:52:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:52:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:52:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:52:31 --> Total execution time: 0.0178
DEBUG - 2021-04-05 21:52:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:52:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:52:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:52:32 --> Total execution time: 0.0164
DEBUG - 2021-04-05 21:52:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:52:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:52:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:52:34 --> Total execution time: 0.0382
DEBUG - 2021-04-05 21:52:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:52:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:52:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:52:35 --> Total execution time: 0.0174
DEBUG - 2021-04-05 21:52:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:52:38 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:52:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:52:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 99
DEBUG - 2021-04-05 21:52:38 --> Total execution time: 0.0165
DEBUG - 2021-04-05 21:53:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:53:43 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:53:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:53:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:53:43 --> Total execution time: 0.0167
DEBUG - 2021-04-05 21:53:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:53:44 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:53:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:53:44 --> Total execution time: 0.0165
DEBUG - 2021-04-05 21:53:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:53:44 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:53:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:53:44 --> Total execution time: 0.0164
DEBUG - 2021-04-05 21:53:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:53:45 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:53:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:53:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:53:45 --> Total execution time: 0.0166
DEBUG - 2021-04-05 21:53:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:53:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:53:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:53:54 --> Total execution time: 0.0186
DEBUG - 2021-04-05 21:53:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:53:58 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:53:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:53:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:53:58 --> Total execution time: 0.0161
DEBUG - 2021-04-05 21:53:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:53:58 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:53:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:53:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:53:58 --> Total execution time: 0.0155
DEBUG - 2021-04-05 21:53:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:53:59 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:53:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:53:59 --> Total execution time: 0.0165
DEBUG - 2021-04-05 21:53:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:53:59 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:53:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:53:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:53:59 --> Total execution time: 0.0168
DEBUG - 2021-04-05 21:54:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:54:06 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:54:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:54:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:54:06 --> Total execution time: 0.0172
DEBUG - 2021-04-05 21:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:54:07 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:54:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:54:07 --> Total execution time: 0.0168
DEBUG - 2021-04-05 21:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:54:07 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:54:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:54:07 --> Total execution time: 0.0167
DEBUG - 2021-04-05 21:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:54:19 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:54:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:54:19 --> Total execution time: 0.0193
DEBUG - 2021-04-05 21:54:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:54:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:54:34 --> Total execution time: 0.0172
DEBUG - 2021-04-05 21:54:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:54:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 21:54:34 --> UTF-8 Support Enabled
ERROR - 2021-04-05 21:54:34 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:54:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:54:34 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:54:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:54:38 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:54:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:54:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:54:38 --> Total execution time: 0.0160
DEBUG - 2021-04-05 21:54:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:54:39 --> No URI present. Default controller set.
DEBUG - 2021-04-05 21:54:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:54:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:54:39 --> Total execution time: 0.0172
DEBUG - 2021-04-05 21:54:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:54:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:54:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:54:42 --> Total execution time: 0.0170
DEBUG - 2021-04-05 21:54:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:54:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:54:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:54:43 --> Total execution time: 0.0165
DEBUG - 2021-04-05 21:56:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:56:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:56:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:56:08 --> Total execution time: 0.0177
DEBUG - 2021-04-05 21:56:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:56:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:56:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:56:09 --> Total execution time: 0.0163
DEBUG - 2021-04-05 21:56:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:56:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:56:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:56:10 --> Total execution time: 0.0163
DEBUG - 2021-04-05 21:56:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:56:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:56:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:56:11 --> Total execution time: 0.0169
DEBUG - 2021-04-05 21:56:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:56:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:56:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:56:18 --> Total execution time: 0.0174
DEBUG - 2021-04-05 21:56:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:56:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:56:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:56:32 --> Total execution time: 0.0189
DEBUG - 2021-04-05 21:56:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:56:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:56:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:56:33 --> Total execution time: 0.0163
DEBUG - 2021-04-05 21:59:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:59:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:59:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:59:16 --> Total execution time: 0.0168
DEBUG - 2021-04-05 21:59:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:59:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:59:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:59:16 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:59:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:59:16 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 21:59:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 21:59:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 21:59:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 21:59:51 --> Total execution time: 0.0162
DEBUG - 2021-04-05 22:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:00:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:00:35 --> Total execution time: 0.0172
DEBUG - 2021-04-05 22:00:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:00:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:00:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:00:38 --> Total execution time: 0.0170
DEBUG - 2021-04-05 22:01:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:01:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:01:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:01:25 --> Total execution time: 0.0255
DEBUG - 2021-04-05 22:02:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:02:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:02:01 --> Total execution time: 0.0169
DEBUG - 2021-04-05 22:02:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:02:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 22:02:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:02:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 22:02:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:02:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:02:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:02:26 --> Total execution time: 0.0172
DEBUG - 2021-04-05 22:02:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:02:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:02:43 --> Total execution time: 0.0166
DEBUG - 2021-04-05 22:02:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:02:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:02:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 22:02:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:02:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-05 22:02:43 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 22:04:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:04:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:04:20 --> Total execution time: 0.0173
DEBUG - 2021-04-05 22:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:05:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:05:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:05:45 --> Total execution time: 0.0315
DEBUG - 2021-04-05 22:05:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:05:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:05:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:05:45 --> Total execution time: 0.0165
DEBUG - 2021-04-05 22:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:06:08 --> Total execution time: 0.0194
DEBUG - 2021-04-05 22:06:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:06:09 --> Total execution time: 0.0162
DEBUG - 2021-04-05 22:06:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:09 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 22:06:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:06:11 --> Total execution time: 0.0162
DEBUG - 2021-04-05 22:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:06:23 --> Total execution time: 0.0159
DEBUG - 2021-04-05 22:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:23 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 22:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:23 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 22:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:06:24 --> Total execution time: 0.0162
DEBUG - 2021-04-05 22:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:24 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 22:06:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:06:26 --> Total execution time: 0.0166
DEBUG - 2021-04-05 22:06:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:06:27 --> Total execution time: 0.0165
DEBUG - 2021-04-05 22:06:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:06:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:06:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:06:27 --> Total execution time: 0.0160
DEBUG - 2021-04-05 22:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:14:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:14:18 --> Total execution time: 0.0219
DEBUG - 2021-04-05 22:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:14:18 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 22:14:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:14:18 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 22:27:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:27:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:27:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:27:20 --> Total execution time: 0.1965
DEBUG - 2021-04-05 22:27:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:27:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 22:27:20 --> UTF-8 Support Enabled
ERROR - 2021-04-05 22:27:20 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 22:27:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:27:20 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 22:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:32:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:32:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:32:46 --> Total execution time: 0.8116
DEBUG - 2021-04-05 22:32:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:32:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:32:46 --> Total execution time: 0.0171
DEBUG - 2021-04-05 22:43:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:43:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:43:18 --> Total execution time: 0.0364
DEBUG - 2021-04-05 22:43:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:43:18 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 22:43:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:43:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:43:18 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 22:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:46:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:46:45 --> Total execution time: 0.0859
DEBUG - 2021-04-05 22:48:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 22:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 22:48:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 22:48:58 --> Total execution time: 0.3465
DEBUG - 2021-04-05 23:25:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 23:25:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 23:25:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 23:25:16 --> Total execution time: 0.0900
DEBUG - 2021-04-05 23:25:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 23:25:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 23:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 23:25:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 23:25:16 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-05 23:25:16 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 23:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 23:56:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 23:56:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-05 23:56:44 --> Total execution time: 0.0173
DEBUG - 2021-04-05 23:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 23:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 23:56:44 --> UTF-8 Support Enabled
ERROR - 2021-04-05 23:56:44 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 23:56:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 23:56:44 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-05 23:56:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 23:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 23:56:50 --> Total execution time: 0.0152
DEBUG - 2021-04-05 23:59:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 23:59:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 23:59:26 --> Total execution time: 0.0245
DEBUG - 2021-04-05 23:59:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 23:59:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 23:59:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 23:59:26 --> 404 Page Not Found: Css/font-awesome.css
DEBUG - 2021-04-05 23:59:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-05 23:59:26 --> 404 Page Not Found: Css/style.css
DEBUG - 2021-04-05 23:59:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-05 23:59:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-05 23:59:44 --> Total execution time: 0.0163
