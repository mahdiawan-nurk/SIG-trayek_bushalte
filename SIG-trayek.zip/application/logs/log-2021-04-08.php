<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-04-08 14:33:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:33:48 --> No URI present. Default controller set.
DEBUG - 2021-04-08 14:33:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:33:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:33:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-08 14:33:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-08 14:33:50 --> Total execution time: 3.1420
DEBUG - 2021-04-08 14:33:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:33:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:33:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:33:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 14:33:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-08 14:33:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-08 14:33:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:33:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:33:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:33:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-08 14:33:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-08 14:33:57 --> Total execution time: 0.1246
DEBUG - 2021-04-08 14:34:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:34:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:34:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:34:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-08 14:34:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-08 14:34:01 --> Total execution time: 0.0532
DEBUG - 2021-04-08 14:34:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:34:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-08 14:34:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-08 14:34:05 --> Total execution time: 0.0851
DEBUG - 2021-04-08 14:34:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:34:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:34:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:34:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-08 14:34:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-08 14:34:07 --> Total execution time: 0.1575
DEBUG - 2021-04-08 14:34:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:34:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:34:19 --> Total execution time: 1.7540
DEBUG - 2021-04-08 14:36:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:36:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:36:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:36:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:36:17 --> Total execution time: 0.0489
DEBUG - 2021-04-08 14:37:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:37:28 --> Total execution time: 0.0551
DEBUG - 2021-04-08 14:37:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:37:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:37:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:37:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:37:44 --> Total execution time: 0.0666
DEBUG - 2021-04-08 14:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:46:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:46:05 --> Total execution time: 0.3446
DEBUG - 2021-04-08 14:46:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:46:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:46:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:46:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:46:07 --> Total execution time: 0.0324
DEBUG - 2021-04-08 14:52:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:52:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 14:52:17 --> 404 Page Not Found: Admin/template
DEBUG - 2021-04-08 14:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:52:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 14:52:26 --> 404 Page Not Found: Admin/template
DEBUG - 2021-04-08 14:52:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:52:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:52:41 --> Total execution time: 0.0347
DEBUG - 2021-04-08 14:52:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:52:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 14:52:41 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-08 14:52:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:52:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 14:52:41 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-08 14:53:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:53:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:53:51 --> Total execution time: 0.0357
DEBUG - 2021-04-08 14:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:53:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:53:53 --> Total execution time: 0.0373
DEBUG - 2021-04-08 14:54:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:54:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:54:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:54:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:54:36 --> Total execution time: 0.0329
DEBUG - 2021-04-08 14:54:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:54:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:54:40 --> Total execution time: 0.0573
DEBUG - 2021-04-08 14:54:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:54:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:54:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:54:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:54:50 --> Total execution time: 0.0354
DEBUG - 2021-04-08 14:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:55:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:55:55 --> Total execution time: 0.0437
DEBUG - 2021-04-08 14:56:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:56:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:56:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:56:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:56:08 --> Total execution time: 0.0329
DEBUG - 2021-04-08 14:56:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:56:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:56:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:56:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:56:48 --> Total execution time: 0.0342
DEBUG - 2021-04-08 14:58:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:58:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:58:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:58:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:58:04 --> Total execution time: 0.0446
DEBUG - 2021-04-08 14:58:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:58:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:58:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:58:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:58:22 --> Total execution time: 0.0349
DEBUG - 2021-04-08 14:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:58:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:58:43 --> Total execution time: 0.0468
DEBUG - 2021-04-08 14:58:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:58:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:58:53 --> Total execution time: 0.0402
DEBUG - 2021-04-08 14:58:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:58:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:58:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:58:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:58:57 --> Total execution time: 0.0494
DEBUG - 2021-04-08 14:59:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:59:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:59:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:59:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:59:04 --> Total execution time: 0.0433
DEBUG - 2021-04-08 14:59:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:59:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:59:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:59:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:59:09 --> Total execution time: 0.0339
DEBUG - 2021-04-08 14:59:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 14:59:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 14:59:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 14:59:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 14:59:57 --> Total execution time: 0.0362
DEBUG - 2021-04-08 15:00:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:00:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:00:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:00:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:00:18 --> Total execution time: 0.0445
DEBUG - 2021-04-08 15:00:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:00:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:00:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:00:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:00:25 --> Total execution time: 0.0316
DEBUG - 2021-04-08 15:00:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:00:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:00:31 --> Total execution time: 0.0550
DEBUG - 2021-04-08 15:00:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:00:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:00:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:00:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:00:56 --> Total execution time: 0.0397
DEBUG - 2021-04-08 15:01:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:01:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:01:06 --> Total execution time: 0.0457
DEBUG - 2021-04-08 15:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:01:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:01:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:01:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:01:41 --> Total execution time: 0.0390
DEBUG - 2021-04-08 15:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:01:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:01:45 --> Total execution time: 0.0378
DEBUG - 2021-04-08 15:01:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:01:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:01:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:01:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:01:56 --> Total execution time: 0.0354
DEBUG - 2021-04-08 15:02:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:02:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:02:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:02:33 --> Total execution time: 0.0442
DEBUG - 2021-04-08 15:03:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:03:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:03:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:03:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:03:18 --> Total execution time: 0.0372
DEBUG - 2021-04-08 15:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:03:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:03:25 --> Total execution time: 0.0377
DEBUG - 2021-04-08 15:03:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:03:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:03:51 --> Total execution time: 0.0408
DEBUG - 2021-04-08 15:03:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:03:57 --> Total execution time: 0.0368
DEBUG - 2021-04-08 15:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:04:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:04:05 --> Total execution time: 0.0343
DEBUG - 2021-04-08 15:04:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:04:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:04:21 --> Total execution time: 0.0358
DEBUG - 2021-04-08 15:04:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:04:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:04:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:04:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:04:33 --> Total execution time: 0.0456
DEBUG - 2021-04-08 15:04:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:04:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:04:42 --> Total execution time: 0.0440
DEBUG - 2021-04-08 15:04:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:04:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:04:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:04:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:04:59 --> Total execution time: 0.0361
DEBUG - 2021-04-08 15:05:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:05:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:05:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:05:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:05:03 --> Total execution time: 0.0386
DEBUG - 2021-04-08 15:05:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:05:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:05:13 --> Total execution time: 0.0409
DEBUG - 2021-04-08 15:05:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:05:19 --> Total execution time: 0.0396
DEBUG - 2021-04-08 15:07:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:07:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:07:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:07:12 --> Total execution time: 0.0453
DEBUG - 2021-04-08 15:07:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:07:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:07:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:07:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:07:32 --> Total execution time: 0.0360
DEBUG - 2021-04-08 15:07:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:07:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:07:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:07:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:07:42 --> Total execution time: 0.0351
DEBUG - 2021-04-08 15:08:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:08:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:08:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:08:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:08:13 --> Total execution time: 0.0351
DEBUG - 2021-04-08 15:08:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:08:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:08:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:08:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:08:58 --> Total execution time: 0.0457
DEBUG - 2021-04-08 15:09:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:09:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:09:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:09:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:09:23 --> Total execution time: 0.0392
DEBUG - 2021-04-08 15:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:09:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:09:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:09:42 --> Total execution time: 0.0343
DEBUG - 2021-04-08 15:09:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:09:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:09:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:09:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:09:47 --> Total execution time: 0.0345
DEBUG - 2021-04-08 15:09:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:09:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:09:51 --> Total execution time: 0.0370
DEBUG - 2021-04-08 15:09:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:09:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:09:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:09:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:09:56 --> Total execution time: 0.0344
DEBUG - 2021-04-08 15:10:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:10:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:10:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:10:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:10:28 --> Total execution time: 0.0449
DEBUG - 2021-04-08 15:10:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:10:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:10:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:10:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:10:38 --> Total execution time: 0.0355
DEBUG - 2021-04-08 15:11:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:11:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:11:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:11:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:11:01 --> Total execution time: 0.0447
DEBUG - 2021-04-08 15:11:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:11:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:11:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:11:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:11:55 --> Total execution time: 0.0336
DEBUG - 2021-04-08 15:12:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:12:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:12:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:12:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:12:26 --> Total execution time: 0.0460
DEBUG - 2021-04-08 15:12:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:12:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:12:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:12:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:12:34 --> Total execution time: 0.0381
DEBUG - 2021-04-08 15:12:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:12:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:12:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:12:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:12:40 --> Total execution time: 0.0340
DEBUG - 2021-04-08 15:12:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:12:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:12:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:12:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:12:52 --> Total execution time: 0.0319
DEBUG - 2021-04-08 15:13:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:13:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:13:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:13:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:13:18 --> Total execution time: 0.0513
DEBUG - 2021-04-08 15:13:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:13:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:13:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:13:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:13:45 --> Total execution time: 0.0345
DEBUG - 2021-04-08 15:13:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:13:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:13:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:13:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:13:55 --> Total execution time: 0.0463
DEBUG - 2021-04-08 15:14:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:14:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:14:03 --> Total execution time: 0.0447
DEBUG - 2021-04-08 15:14:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:14:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:14:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:14:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:14:16 --> Total execution time: 0.0351
DEBUG - 2021-04-08 15:14:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:14:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:14:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:14:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:14:29 --> Total execution time: 0.0450
DEBUG - 2021-04-08 15:14:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:14:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:14:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:14:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:14:36 --> Total execution time: 0.0365
DEBUG - 2021-04-08 15:16:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:16:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:16:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:16:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:16:13 --> Total execution time: 0.0333
DEBUG - 2021-04-08 15:17:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:17:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:17:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:17:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:17:19 --> Total execution time: 0.0493
DEBUG - 2021-04-08 15:17:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:17:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 15:17:19 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-08 15:17:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:17:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 15:17:19 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-08 15:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:19:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:19:22 --> Total execution time: 0.0448
DEBUG - 2021-04-08 15:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 15:19:22 --> 404 Page Not Found: Admin/apple-icon.png
ERROR - 2021-04-08 15:19:22 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-08 15:20:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:20:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:20:49 --> Total execution time: 0.0427
DEBUG - 2021-04-08 15:20:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:20:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:20:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 15:20:49 --> 404 Page Not Found: Admin/favicon.ico
ERROR - 2021-04-08 15:20:49 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-08 15:21:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:21:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:21:04 --> Total execution time: 0.0374
DEBUG - 2021-04-08 15:21:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:21:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 15:21:04 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-08 15:21:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:21:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:21:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:21:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:21:11 --> Total execution time: 0.0373
DEBUG - 2021-04-08 15:22:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:22:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:22:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:22:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:22:25 --> Total execution time: 0.0329
DEBUG - 2021-04-08 15:22:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:22:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:22:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:22:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:22:31 --> Total execution time: 0.0375
DEBUG - 2021-04-08 15:23:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:23:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:23:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:23:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:23:15 --> Total execution time: 0.0479
DEBUG - 2021-04-08 15:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:24:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:24:18 --> Total execution time: 0.0330
DEBUG - 2021-04-08 15:24:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:24:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:24:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:24:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:24:47 --> Total execution time: 0.0852
DEBUG - 2021-04-08 15:25:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:25:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:25:00 --> Total execution time: 0.0469
DEBUG - 2021-04-08 15:25:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:25:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:25:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:25:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:25:26 --> Total execution time: 0.0366
DEBUG - 2021-04-08 15:25:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:25:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 15:25:26 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-08 15:26:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:26:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:26:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:26:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:26:08 --> Total execution time: 0.0370
DEBUG - 2021-04-08 15:27:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:27:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:27:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:27:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:27:54 --> Total execution time: 0.0431
DEBUG - 2021-04-08 15:28:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:28:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:28:07 --> Total execution time: 0.0419
DEBUG - 2021-04-08 15:28:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:28:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:28:10 --> Total execution time: 0.0380
DEBUG - 2021-04-08 15:33:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:33:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:33:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:33:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:33:56 --> Total execution time: 0.0352
DEBUG - 2021-04-08 15:43:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:43:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:43:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:43:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:43:26 --> Total execution time: 0.0363
DEBUG - 2021-04-08 15:44:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:44:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:44:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:44:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:44:51 --> Total execution time: 0.0520
DEBUG - 2021-04-08 15:46:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:46:08 --> Total execution time: 0.0498
DEBUG - 2021-04-08 15:46:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:46:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:46:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:46:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:46:19 --> Total execution time: 0.0330
DEBUG - 2021-04-08 15:46:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:46:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:46:36 --> Total execution time: 0.0348
DEBUG - 2021-04-08 15:48:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:48:37 --> Total execution time: 0.0557
DEBUG - 2021-04-08 15:48:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:48:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:48:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:48:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-08 15:48:39 --> 404 Page Not Found: Admin/favicon.ico
ERROR - 2021-04-08 15:48:39 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-08 15:49:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:49:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:49:30 --> Total execution time: 0.0439
DEBUG - 2021-04-08 15:49:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-08 15:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-08 15:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-08 15:49:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-08 15:49:45 --> Total execution time: 0.0329
