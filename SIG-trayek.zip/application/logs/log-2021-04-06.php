<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-04-06 00:00:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:00:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:00:12 --> Total execution time: 0.0223
DEBUG - 2021-04-06 00:02:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:12 --> Total execution time: 0.0150
DEBUG - 2021-04-06 00:02:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:13 --> Total execution time: 0.0152
DEBUG - 2021-04-06 00:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:14 --> Total execution time: 0.0154
DEBUG - 2021-04-06 00:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:14 --> Total execution time: 0.0162
DEBUG - 2021-04-06 00:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:14 --> Total execution time: 0.0163
DEBUG - 2021-04-06 00:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:14 --> Total execution time: 0.0147
DEBUG - 2021-04-06 00:02:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:14 --> Total execution time: 0.0152
DEBUG - 2021-04-06 00:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:15 --> Total execution time: 0.0150
DEBUG - 2021-04-06 00:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:15 --> Total execution time: 0.0150
DEBUG - 2021-04-06 00:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:15 --> Total execution time: 0.0153
DEBUG - 2021-04-06 00:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:15 --> Total execution time: 0.0147
DEBUG - 2021-04-06 00:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:15 --> Total execution time: 0.0153
DEBUG - 2021-04-06 00:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:15 --> Total execution time: 0.0152
DEBUG - 2021-04-06 00:02:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:16 --> Total execution time: 0.0144
DEBUG - 2021-04-06 00:02:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:02:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:02:22 --> Total execution time: 0.0164
DEBUG - 2021-04-06 00:02:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:23 --> Total execution time: 0.0149
DEBUG - 2021-04-06 00:02:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:23 --> Total execution time: 0.0154
DEBUG - 2021-04-06 00:02:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:23 --> Total execution time: 0.0150
DEBUG - 2021-04-06 00:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:24 --> Total execution time: 0.0349
DEBUG - 2021-04-06 00:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:24 --> Total execution time: 0.0148
DEBUG - 2021-04-06 00:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:24 --> Total execution time: 0.0143
DEBUG - 2021-04-06 00:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:24 --> Total execution time: 0.0151
DEBUG - 2021-04-06 00:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:25 --> Total execution time: 0.0155
DEBUG - 2021-04-06 00:02:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:30 --> Total execution time: 0.0160
DEBUG - 2021-04-06 00:02:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:46 --> Total execution time: 0.0157
DEBUG - 2021-04-06 00:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:47 --> Total execution time: 0.0150
DEBUG - 2021-04-06 00:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:47 --> Total execution time: 0.0145
DEBUG - 2021-04-06 00:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:47 --> Total execution time: 0.0150
DEBUG - 2021-04-06 00:02:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:47 --> Total execution time: 0.0147
DEBUG - 2021-04-06 00:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:02:48 --> Total execution time: 0.0142
DEBUG - 2021-04-06 00:04:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:04:51 --> Total execution time: 0.0174
DEBUG - 2021-04-06 00:04:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:04:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:04:52 --> Total execution time: 0.0165
DEBUG - 2021-04-06 00:05:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:05:15 --> Total execution time: 0.0156
DEBUG - 2021-04-06 00:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:05:16 --> Total execution time: 0.0162
DEBUG - 2021-04-06 00:05:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:05:17 --> Total execution time: 0.0154
DEBUG - 2021-04-06 00:05:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:05:17 --> Total execution time: 0.0158
DEBUG - 2021-04-06 00:05:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:05:17 --> Total execution time: 0.0162
DEBUG - 2021-04-06 00:05:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:05:18 --> Total execution time: 0.0157
DEBUG - 2021-04-06 00:05:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:05:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:05:19 --> Total execution time: 0.0168
DEBUG - 2021-04-06 00:05:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:05:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:05:20 --> Total execution time: 0.0166
DEBUG - 2021-04-06 00:05:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:05:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:05:20 --> Total execution time: 0.0167
DEBUG - 2021-04-06 00:05:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:05:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:05:20 --> Total execution time: 0.0162
DEBUG - 2021-04-06 00:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:05:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:05:21 --> Total execution time: 0.0396
DEBUG - 2021-04-06 00:05:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:05:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:05:22 --> Total execution time: 0.0166
DEBUG - 2021-04-06 00:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:05:39 --> Total execution time: 0.0150
DEBUG - 2021-04-06 00:06:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:06:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:06:01 --> Total execution time: 0.0155
DEBUG - 2021-04-06 00:07:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:07:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:07:13 --> Total execution time: 0.0158
DEBUG - 2021-04-06 00:07:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:07:27 --> Total execution time: 0.0155
DEBUG - 2021-04-06 00:07:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:07:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:07:28 --> Total execution time: 0.0152
DEBUG - 2021-04-06 00:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:08:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:08:21 --> Total execution time: 0.0156
DEBUG - 2021-04-06 00:09:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:09:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:09:42 --> Total execution time: 0.0148
DEBUG - 2021-04-06 00:10:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:10:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:10:01 --> Total execution time: 0.0154
DEBUG - 2021-04-06 00:10:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:10:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:10:52 --> Total execution time: 0.0165
DEBUG - 2021-04-06 00:11:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:11:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:11:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:11:56 --> Total execution time: 0.0169
DEBUG - 2021-04-06 00:11:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:11:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:11:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 00:11:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:11:56 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 00:11:56 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 00:12:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:01 --> Total execution time: 0.0170
DEBUG - 2021-04-06 00:12:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:02 --> Total execution time: 0.0386
DEBUG - 2021-04-06 00:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:03 --> Total execution time: 0.0176
DEBUG - 2021-04-06 00:12:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:04 --> Total execution time: 0.0176
DEBUG - 2021-04-06 00:12:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:04 --> Total execution time: 0.0164
DEBUG - 2021-04-06 00:12:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:06 --> Total execution time: 0.0158
DEBUG - 2021-04-06 00:12:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:06 --> Total execution time: 0.0163
DEBUG - 2021-04-06 00:12:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:07 --> Total execution time: 0.0167
DEBUG - 2021-04-06 00:12:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:07 --> Total execution time: 0.0162
DEBUG - 2021-04-06 00:12:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:08 --> Total execution time: 0.0158
DEBUG - 2021-04-06 00:12:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:09 --> Total execution time: 0.0163
DEBUG - 2021-04-06 00:12:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 00:12:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 00:12:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 00:12:10 --> Total execution time: 0.0161
DEBUG - 2021-04-06 02:08:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:16 --> Total execution time: 0.0405
DEBUG - 2021-04-06 02:08:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:16 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 02:08:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:16 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 02:08:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:17 --> Total execution time: 0.0161
DEBUG - 2021-04-06 02:08:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:17 --> Total execution time: 0.0163
DEBUG - 2021-04-06 02:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:18 --> Total execution time: 0.0163
DEBUG - 2021-04-06 02:08:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:19 --> Total execution time: 0.0159
DEBUG - 2021-04-06 02:08:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:19 --> Total execution time: 0.0168
DEBUG - 2021-04-06 02:08:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:20 --> Total execution time: 0.0172
DEBUG - 2021-04-06 02:08:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:20 --> Total execution time: 0.0161
DEBUG - 2021-04-06 02:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:21 --> Total execution time: 0.0170
DEBUG - 2021-04-06 02:08:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:21 --> Total execution time: 0.0160
DEBUG - 2021-04-06 02:08:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:22 --> Total execution time: 0.0161
DEBUG - 2021-04-06 02:08:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:08:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:08:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:08:22 --> Total execution time: 0.0162
DEBUG - 2021-04-06 02:31:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:31:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:31:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:31:59 --> Total execution time: 0.0187
DEBUG - 2021-04-06 02:31:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:31:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:31:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:31:59 --> Total execution time: 0.0168
DEBUG - 2021-04-06 02:32:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:32:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:32:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:32:34 --> Total execution time: 0.0194
DEBUG - 2021-04-06 02:32:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:32:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:32:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:32:52 --> Total execution time: 0.0282
DEBUG - 2021-04-06 02:40:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:40:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:40:43 --> Total execution time: 0.0385
DEBUG - 2021-04-06 02:40:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:40:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:40:43 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 02:40:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:40:43 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 02:42:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:42:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:42:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:42:30 --> Total execution time: 0.0231
DEBUG - 2021-04-06 02:42:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:42:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:42:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:42:42 --> Total execution time: 0.0555
DEBUG - 2021-04-06 02:42:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:42:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:42:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:42:57 --> Total execution time: 0.0187
DEBUG - 2021-04-06 02:42:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:42:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:42:59 --> 404 Page Not Found: Lupapasshtml/index
DEBUG - 2021-04-06 02:43:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:43:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:43:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:43:30 --> Total execution time: 0.0191
DEBUG - 2021-04-06 02:43:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:43:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:43:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:43:40 --> Total execution time: 0.0163
DEBUG - 2021-04-06 02:43:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:43:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:43:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:43:45 --> Total execution time: 0.0168
DEBUG - 2021-04-06 02:43:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:43:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:43:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:43:56 --> Total execution time: 0.0190
DEBUG - 2021-04-06 02:44:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:44:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:44:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:44:06 --> Total execution time: 0.0178
DEBUG - 2021-04-06 02:44:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:44:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:44:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:44:30 --> Total execution time: 0.0176
DEBUG - 2021-04-06 02:44:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:44:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:44:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:44:36 --> Total execution time: 0.0169
DEBUG - 2021-04-06 02:44:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:44:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:44:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:44:58 --> Total execution time: 0.0192
DEBUG - 2021-04-06 02:45:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:45:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:45:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:45:03 --> Total execution time: 0.0179
DEBUG - 2021-04-06 02:45:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:45:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:45:06 --> 404 Page Not Found: Lupapasshtml/index
DEBUG - 2021-04-06 02:59:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:59:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:59:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 02:59:50 --> Total execution time: 0.0396
DEBUG - 2021-04-06 02:59:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 02:59:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 02:59:59 --> 404 Page Not Found: Lupapasshtml/index
DEBUG - 2021-04-06 03:01:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:01:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:01:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:01:31 --> Total execution time: 0.0183
DEBUG - 2021-04-06 03:01:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:01:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:01:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:01:37 --> Total execution time: 0.0164
DEBUG - 2021-04-06 03:01:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:01:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:01:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:01:38 --> Total execution time: 0.0163
DEBUG - 2021-04-06 03:01:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:01:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:01:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:01:41 --> Total execution time: 0.0180
DEBUG - 2021-04-06 03:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:01:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:01:42 --> Total execution time: 0.0169
DEBUG - 2021-04-06 03:02:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:02:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:02:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:02:00 --> Total execution time: 0.0173
DEBUG - 2021-04-06 03:26:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:26:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:26:27 --> 404 Page Not Found: Loginadminhtml/index
DEBUG - 2021-04-06 03:26:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:26:39 --> Total execution time: 0.0162
DEBUG - 2021-04-06 03:26:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:26:57 --> Total execution time: 0.0158
DEBUG - 2021-04-06 03:28:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:28:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:28:52 --> Total execution time: 0.0229
DEBUG - 2021-04-06 03:29:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:29:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:29:04 --> Total execution time: 0.0204
DEBUG - 2021-04-06 03:31:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:31:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:31:23 --> Total execution time: 0.0455
DEBUG - 2021-04-06 03:31:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:31:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:31:26 --> Total execution time: 0.0169
DEBUG - 2021-04-06 03:31:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:31:37 --> Total execution time: 0.0158
DEBUG - 2021-04-06 03:31:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:31:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:31:45 --> Total execution time: 0.0168
DEBUG - 2021-04-06 03:31:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:31:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:31:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 03:31:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:31:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 03:32:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:32:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:32:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:32:05 --> Total execution time: 0.0164
DEBUG - 2021-04-06 03:32:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:32:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:32:06 --> Total execution time: 0.0161
DEBUG - 2021-04-06 03:32:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:32:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:32:22 --> Total execution time: 0.0169
DEBUG - 2021-04-06 03:32:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:32:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:32:34 --> Total execution time: 0.0149
DEBUG - 2021-04-06 03:32:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:32:37 --> Total execution time: 0.0153
DEBUG - 2021-04-06 03:32:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:32:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:32:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:32:40 --> Total execution time: 0.0176
DEBUG - 2021-04-06 03:32:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:32:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:32:41 --> Total execution time: 0.0162
DEBUG - 2021-04-06 03:33:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:33:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:33:55 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user ''@'localhost' (using password: NO) D:\__myproject.my\SIG-trayek\system\database\drivers\mysqli\mysqli_driver.php 203
ERROR - 2021-04-06 03:33:55 --> Unable to connect to the database
DEBUG - 2021-04-06 03:33:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:33:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:33:55 --> Total execution time: 0.0982
DEBUG - 2021-04-06 03:34:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:34:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:34:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:34:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:34:19 --> Total execution time: 0.0577
DEBUG - 2021-04-06 03:37:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:37:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:37:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:37:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:37:37 --> Total execution time: 0.1028
DEBUG - 2021-04-06 03:37:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:37:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:37:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:37:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:37:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:37:39 --> Total execution time: 0.0340
DEBUG - 2021-04-06 03:37:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:37:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:37:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:37:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:37:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:37:40 --> Total execution time: 0.0335
DEBUG - 2021-04-06 03:38:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:38:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:38:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:38:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:38:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:38:21 --> Total execution time: 0.0653
DEBUG - 2021-04-06 03:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:38:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:38:23 --> Total execution time: 0.0384
DEBUG - 2021-04-06 03:38:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:38:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:38:41 --> Total execution time: 0.0374
DEBUG - 2021-04-06 03:39:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:39:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:39:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:39:16 --> Total execution time: 0.0563
DEBUG - 2021-04-06 03:39:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:39:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:39:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:39:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:39:21 --> Total execution time: 0.0452
DEBUG - 2021-04-06 03:39:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:39:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:39:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:39:23 --> Total execution time: 0.0337
DEBUG - 2021-04-06 03:39:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:39:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:39:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:39:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:39:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:39:23 --> Total execution time: 0.0457
DEBUG - 2021-04-06 03:39:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:39:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:39:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:39:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:39:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:39:24 --> Total execution time: 0.0470
DEBUG - 2021-04-06 03:39:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:39:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:39:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:39:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:39:25 --> Total execution time: 0.0372
DEBUG - 2021-04-06 03:40:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:40:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:40:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:40:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:40:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:40:06 --> Total execution time: 0.0336
DEBUG - 2021-04-06 03:40:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:40:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:40:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:40:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:40:08 --> Total execution time: 0.0360
DEBUG - 2021-04-06 03:40:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:40:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:40:13 --> Total execution time: 0.0485
DEBUG - 2021-04-06 03:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:40:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:40:17 --> Total execution time: 0.0333
DEBUG - 2021-04-06 03:40:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:40:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:40:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:40:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:40:30 --> Total execution time: 0.0599
DEBUG - 2021-04-06 03:41:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:41:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:41:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:41:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:41:10 --> Severity: Notice --> Undefined variable: ceklogin D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 34
DEBUG - 2021-04-06 03:41:10 --> Total execution time: 0.0365
DEBUG - 2021-04-06 03:41:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:41:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:41:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:41:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:41:29 --> Total execution time: 0.0325
DEBUG - 2021-04-06 03:41:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:41:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:41:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:41:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:41:32 --> Total execution time: 0.0364
DEBUG - 2021-04-06 03:41:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:41:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:41:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:41:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:41:39 --> Severity: Notice --> Undefined variable: cls D:\__myproject.my\SIG-trayek\application\views\front\awal.php 76
ERROR - 2021-04-06 03:41:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:41:39 --> Total execution time: 0.0473
DEBUG - 2021-04-06 03:41:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:41:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:41:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:41:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:41:48 --> Total execution time: 0.0619
DEBUG - 2021-04-06 03:41:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:41:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:41:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:41:57 --> Total execution time: 0.0352
DEBUG - 2021-04-06 03:41:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:41:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:41:58 --> Total execution time: 0.0542
DEBUG - 2021-04-06 03:42:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:42:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:42:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:42:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:42:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:42:23 --> Total execution time: 0.0346
DEBUG - 2021-04-06 03:42:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:42:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:42:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:42:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:42:24 --> Total execution time: 0.0482
DEBUG - 2021-04-06 03:42:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:42:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:42:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:42:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:42:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:42:56 --> Total execution time: 0.0349
DEBUG - 2021-04-06 03:42:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:42:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:42:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:42:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:42:57 --> Total execution time: 0.0362
DEBUG - 2021-04-06 03:43:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:43:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:43:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:43:42 --> Total execution time: 0.0468
DEBUG - 2021-04-06 03:43:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:43:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:43:43 --> Total execution time: 0.0388
DEBUG - 2021-04-06 03:43:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:43:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:43:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:43:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:43:48 --> Total execution time: 0.0458
DEBUG - 2021-04-06 03:44:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:44:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:44:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:44:49 --> Total execution time: 0.0563
DEBUG - 2021-04-06 03:44:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:44:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:44:52 --> Total execution time: 0.0356
DEBUG - 2021-04-06 03:46:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:46:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:46:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:46:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:46:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:46:27 --> Total execution time: 0.0355
DEBUG - 2021-04-06 03:46:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:46:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 03:46:28 --> Total execution time: 0.0364
DEBUG - 2021-04-06 03:46:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:46:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:46:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:46:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:46:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:46:56 --> Total execution time: 0.0409
DEBUG - 2021-04-06 03:57:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:57:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:57:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:57:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:57:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:57:32 --> Total execution time: 0.0432
DEBUG - 2021-04-06 03:57:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:57:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 03:57:43 --> 404 Page Not Found: Daftarakunhtml/index
DEBUG - 2021-04-06 03:57:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 03:57:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 03:57:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 03:57:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 03:57:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 03:57:45 --> Total execution time: 0.0339
DEBUG - 2021-04-06 04:00:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:00:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:00:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:00:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:00:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:00:36 --> Total execution time: 0.0496
DEBUG - 2021-04-06 04:00:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:00:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:00:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:00:39 --> Total execution time: 0.0435
DEBUG - 2021-04-06 04:01:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:01:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:01:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:01:06 --> Total execution time: 0.0467
DEBUG - 2021-04-06 04:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:01:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:01:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:01:08 --> Total execution time: 0.0405
DEBUG - 2021-04-06 04:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:44 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:45 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:46 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:46 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:46 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:46 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:46 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:49 --> UTF-8 Support Enabled
ERROR - 2021-04-06 04:01:49 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:49 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:49 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:49 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:53 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:54 --> UTF-8 Support Enabled
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:54 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:55 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:55 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:55 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:55 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:55 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:55 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-06 04:01:55 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:56 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:56 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:56 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:56 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:58 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:01:58 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:01:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:01:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:01:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:01:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:01:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:01:58 --> Total execution time: 0.0389
DEBUG - 2021-04-06 04:03:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:03:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:03:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:03:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:03:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:03:19 --> Total execution time: 0.0461
DEBUG - 2021-04-06 04:03:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:03:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:03:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:03:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:03:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:03:28 --> Total execution time: 0.0619
DEBUG - 2021-04-06 04:03:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:03:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:03:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:03:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:03:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:03:41 --> Total execution time: 0.0628
DEBUG - 2021-04-06 04:03:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:03:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:03:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:03:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:03:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:03:51 --> Total execution time: 0.0597
DEBUG - 2021-04-06 04:04:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:04:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:04:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:04:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:04:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:04:18 --> Total execution time: 0.0741
DEBUG - 2021-04-06 04:05:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:05:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:05:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:05:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:05:33 --> Total execution time: 0.0347
DEBUG - 2021-04-06 04:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:05:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:05:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:05:54 --> Total execution time: 0.0367
DEBUG - 2021-04-06 04:06:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:06:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:06:02 --> 404 Page Not Found: Daftarakunhtml/index
DEBUG - 2021-04-06 04:06:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:06:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:06:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:06:05 --> Total execution time: 0.0438
DEBUG - 2021-04-06 04:10:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:10:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:10:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:10:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:10:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:10:07 --> Total execution time: 0.0525
DEBUG - 2021-04-06 04:10:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:10:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:10:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:10:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:10:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:10:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:10:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:10:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:10:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:10:26 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:10:26 --> Total execution time: 0.0674
DEBUG - 2021-04-06 04:11:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:11:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:11:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:11:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:11:41 --> Total execution time: 0.0367
DEBUG - 2021-04-06 04:36:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:36:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:36:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:36:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:36:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:36:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:36:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:36:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:36:40 --> Total execution time: 1.3121
DEBUG - 2021-04-06 04:37:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:37:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:37:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:37:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:37:09 --> Total execution time: 0.9991
DEBUG - 2021-04-06 04:38:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:38:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:38:08 --> Total execution time: 3.1665
DEBUG - 2021-04-06 04:39:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:39:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:39:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:39:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:39:52 --> Total execution time: 2.3437
DEBUG - 2021-04-06 04:45:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:45:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:45:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:45:13 --> Total execution time: 0.0611
DEBUG - 2021-04-06 04:45:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:45:13 --> UTF-8 Support Enabled
ERROR - 2021-04-06 04:45:13 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:45:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:45:13 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-06 04:45:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:45:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:45:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:45:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:45:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 04:45:14 --> Total execution time: 0.0340
DEBUG - 2021-04-06 04:45:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:45:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:45:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:45:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:45:30 --> Total execution time: 0.0891
DEBUG - 2021-04-06 04:45:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:45:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:45:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:45:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:45:45 --> Total execution time: 0.0347
DEBUG - 2021-04-06 04:47:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:47:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:47:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:47:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 04:47:02 --> Severity: error --> Exception: Call to undefined function random_string() D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 67
DEBUG - 2021-04-06 04:48:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:48:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:48:27 --> Total execution time: 0.0348
DEBUG - 2021-04-06 04:48:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:48:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:48:37 --> Total execution time: 0.0337
DEBUG - 2021-04-06 04:54:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:55:00 --> Total execution time: 2.7193
DEBUG - 2021-04-06 04:55:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:55:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-06 04:55:13 --> 404 Page Not Found: Secure/konfirmasiakun
DEBUG - 2021-04-06 04:56:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 04:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 04:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 04:56:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 04:56:03 --> Total execution time: 0.0451
DEBUG - 2021-04-06 05:00:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 05:00:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 05:00:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 05:00:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 05:00:32 --> Total execution time: 2.6416
DEBUG - 2021-04-06 05:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 05:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 05:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 05:00:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 05:00:42 --> Total execution time: 0.0353
DEBUG - 2021-04-06 05:01:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 05:01:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 05:01:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 05:01:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-06 05:01:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-06 05:01:05 --> Total execution time: 0.0350
DEBUG - 2021-04-06 05:01:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-06 05:01:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-06 05:01:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-06 05:01:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-06 05:01:34 --> Total execution time: 2.5081
