<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-04-15 13:09:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:09:52 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:09:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:09:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:09:52 --> Total execution time: 0.1165
DEBUG - 2021-04-15 13:09:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:09:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:09:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:09:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-15 13:09:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:42:34 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:42:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:42:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:42:34 --> Total execution time: 0.0376
DEBUG - 2021-04-15 13:43:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:43:52 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:43:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:43:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:43:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:43:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:43:52 --> Total execution time: 0.0554
DEBUG - 2021-04-15 13:46:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:46:33 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:46:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:46:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:46:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:46:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:46:33 --> Total execution time: 0.0544
DEBUG - 2021-04-15 13:46:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:46:52 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:46:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:46:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:46:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:46:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:46:52 --> Total execution time: 0.0352
DEBUG - 2021-04-15 13:47:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:06 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:06 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:06 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:47:07 --> UTF-8 Support Enabled
ERROR - 2021-04-15 13:47:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:47:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:07 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-15 13:47:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:08 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:08 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:08 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:08 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:08 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:08 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:08 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:08 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:09 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:09 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:47:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 13:47:11 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-15 13:47:11 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 13:47:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:47:51 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:47:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:47:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:47:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:47:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:47:51 --> Total execution time: 0.0537
DEBUG - 2021-04-15 13:48:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:48:08 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:48:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:48:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:48:08 --> Total execution time: 0.0344
DEBUG - 2021-04-15 13:49:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:49:27 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:49:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:49:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:49:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:49:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:49:27 --> Total execution time: 0.0379
DEBUG - 2021-04-15 13:49:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:49:45 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:49:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:49:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:49:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:49:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:49:45 --> Total execution time: 0.0352
DEBUG - 2021-04-15 13:49:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:49:54 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:49:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:49:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:49:54 --> Total execution time: 0.0601
DEBUG - 2021-04-15 13:50:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:50:14 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:50:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:50:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:50:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:50:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:50:14 --> Total execution time: 0.0359
DEBUG - 2021-04-15 13:50:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:50:35 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:50:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:50:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:50:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:50:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:50:35 --> Total execution time: 0.0344
DEBUG - 2021-04-15 13:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:52:39 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:52:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:52:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:52:39 --> Total execution time: 0.0356
DEBUG - 2021-04-15 13:52:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:52:51 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:52:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:52:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:52:51 --> Total execution time: 0.0366
DEBUG - 2021-04-15 13:52:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:52:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:52:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:52:53 --> Total execution time: 0.0370
DEBUG - 2021-04-15 13:54:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:21 --> Total execution time: 0.0359
DEBUG - 2021-04-15 13:54:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:22 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:54:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:22 --> Total execution time: 0.0340
DEBUG - 2021-04-15 13:54:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:23 --> No URI present. Default controller set.
DEBUG - 2021-04-15 13:54:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:23 --> Total execution time: 0.0349
DEBUG - 2021-04-15 13:54:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:37 --> Total execution time: 0.0522
DEBUG - 2021-04-15 13:54:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:40 --> Total execution time: 0.0344
DEBUG - 2021-04-15 13:54:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:42 --> Total execution time: 0.0359
DEBUG - 2021-04-15 13:54:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:46 --> Total execution time: 0.0344
DEBUG - 2021-04-15 13:54:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:46 --> Total execution time: 0.0634
DEBUG - 2021-04-15 13:54:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:55 --> Total execution time: 0.0348
DEBUG - 2021-04-15 13:54:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:57 --> Total execution time: 0.0348
DEBUG - 2021-04-15 13:54:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:58 --> Total execution time: 0.0576
DEBUG - 2021-04-15 13:54:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:54:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:54:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:54:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:54:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:54:59 --> Total execution time: 0.0436
DEBUG - 2021-04-15 13:55:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:55:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:55:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:55:00 --> Total execution time: 0.0591
DEBUG - 2021-04-15 13:55:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:55:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:55:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:55:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:55:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:55:04 --> Total execution time: 0.0343
DEBUG - 2021-04-15 13:55:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:55:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:55:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:55:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:55:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:55:10 --> Total execution time: 0.0363
DEBUG - 2021-04-15 13:56:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:03 --> Total execution time: 0.0355
DEBUG - 2021-04-15 13:56:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:05 --> Total execution time: 0.0345
DEBUG - 2021-04-15 13:56:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:06 --> Total execution time: 0.0544
DEBUG - 2021-04-15 13:56:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:07 --> Total execution time: 0.0350
DEBUG - 2021-04-15 13:56:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:14 --> Total execution time: 0.0352
DEBUG - 2021-04-15 13:56:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:15 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:15 --> Total execution time: 0.0345
DEBUG - 2021-04-15 13:56:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:22 --> Total execution time: 0.0339
DEBUG - 2021-04-15 13:56:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:34 --> Total execution time: 0.0338
DEBUG - 2021-04-15 13:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:35 --> Total execution time: 0.0604
DEBUG - 2021-04-15 13:56:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:38 --> Total execution time: 0.0343
DEBUG - 2021-04-15 13:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:45 --> Total execution time: 0.0348
DEBUG - 2021-04-15 13:56:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:45 --> Total execution time: 0.0354
DEBUG - 2021-04-15 13:56:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:54 --> Total execution time: 0.0350
DEBUG - 2021-04-15 13:56:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:55 --> Total execution time: 0.0360
DEBUG - 2021-04-15 13:56:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:56:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:56:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:56:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:56:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:56:56 --> Total execution time: 0.0358
DEBUG - 2021-04-15 13:58:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:58:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:58:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:58:53 --> Total execution time: 0.0356
DEBUG - 2021-04-15 13:58:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:58:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:58:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:58:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:58:54 --> Total execution time: 0.0349
DEBUG - 2021-04-15 13:58:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:58:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:58:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:58:55 --> Total execution time: 0.0578
DEBUG - 2021-04-15 13:59:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:59:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:59:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:59:22 --> Total execution time: 0.0334
DEBUG - 2021-04-15 13:59:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:59:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:59:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:59:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:59:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:59:22 --> Total execution time: 0.0367
DEBUG - 2021-04-15 13:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:59:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:59:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:59:29 --> Total execution time: 0.0338
DEBUG - 2021-04-15 13:59:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 13:59:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 13:59:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 13:59:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 13:59:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 13:59:29 --> Total execution time: 0.0391
DEBUG - 2021-04-15 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:00:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:00:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:00:00 --> Total execution time: 0.0344
DEBUG - 2021-04-15 14:00:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:00:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:00:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:00:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:00:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:00:00 --> Total execution time: 0.0388
DEBUG - 2021-04-15 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:00:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:00:02 --> Total execution time: 0.0446
DEBUG - 2021-04-15 14:00:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:00:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:00:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:00:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:00:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:00:02 --> Total execution time: 0.0378
DEBUG - 2021-04-15 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:00:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:00:03 --> Total execution time: 0.0338
DEBUG - 2021-04-15 14:00:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:00:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:00:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:00:03 --> Total execution time: 0.0388
DEBUG - 2021-04-15 14:00:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:00:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:00:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:00:09 --> Total execution time: 0.0352
DEBUG - 2021-04-15 14:00:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:00:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:00:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:00:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:00:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:00:09 --> Total execution time: 0.0400
DEBUG - 2021-04-15 14:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:00:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:00:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:00:41 --> Total execution time: 0.0389
DEBUG - 2021-04-15 14:01:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:01:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:01:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:01:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:01:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:01:01 --> Total execution time: 0.0349
DEBUG - 2021-04-15 14:01:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:01:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:01:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:01:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:01:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:01:12 --> Total execution time: 0.0350
DEBUG - 2021-04-15 14:01:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:01:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:01:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:01:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:01:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:01:21 --> Total execution time: 0.0340
DEBUG - 2021-04-15 14:04:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:04:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:04:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:04:47 --> Total execution time: 0.0546
DEBUG - 2021-04-15 14:04:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:04:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:04:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:04:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:04:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:04:48 --> Total execution time: 0.0562
DEBUG - 2021-04-15 14:04:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:04:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:04:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:04:49 --> Total execution time: 0.0531
DEBUG - 2021-04-15 14:04:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:04:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:04:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:04:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:04:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:04:50 --> Total execution time: 0.0476
DEBUG - 2021-04-15 14:05:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:02 --> Total execution time: 0.0451
DEBUG - 2021-04-15 14:05:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:04 --> Total execution time: 0.0454
DEBUG - 2021-04-15 14:05:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:04 --> Total execution time: 0.0563
DEBUG - 2021-04-15 14:05:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:05 --> Total execution time: 0.0478
DEBUG - 2021-04-15 14:05:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:06 --> Total execution time: 0.0330
DEBUG - 2021-04-15 14:05:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:07 --> Total execution time: 0.0549
DEBUG - 2021-04-15 14:05:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:09 --> Total execution time: 0.0456
DEBUG - 2021-04-15 14:05:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:11 --> Total execution time: 0.0527
DEBUG - 2021-04-15 14:05:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:13 --> Total execution time: 0.0570
DEBUG - 2021-04-15 14:05:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:15 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:15 --> Total execution time: 0.0356
DEBUG - 2021-04-15 14:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:16 --> Total execution time: 0.0572
DEBUG - 2021-04-15 14:05:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:16 --> Total execution time: 0.0547
DEBUG - 2021-04-15 14:05:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:17 --> Total execution time: 0.0335
DEBUG - 2021-04-15 14:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:05:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:05:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:05:48 --> Total execution time: 0.0462
DEBUG - 2021-04-15 14:05:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:05:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:05:50 --> 404 Page Not Found: Readmorehtml/index
DEBUG - 2021-04-15 14:06:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:04 --> Total execution time: 0.0555
DEBUG - 2021-04-15 14:06:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:04 --> Total execution time: 0.0333
DEBUG - 2021-04-15 14:06:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:05 --> Total execution time: 0.0346
DEBUG - 2021-04-15 14:06:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:08 --> Total execution time: 0.0450
DEBUG - 2021-04-15 14:06:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:12 --> Total execution time: 0.0557
DEBUG - 2021-04-15 14:06:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:49 --> Total execution time: 0.0446
DEBUG - 2021-04-15 14:06:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:51 --> Total execution time: 0.0526
DEBUG - 2021-04-15 14:06:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:52 --> Total execution time: 0.0490
DEBUG - 2021-04-15 14:06:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:54 --> Total execution time: 0.0361
DEBUG - 2021-04-15 14:06:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:55 --> Total execution time: 0.0583
DEBUG - 2021-04-15 14:06:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:57 --> Total execution time: 0.0334
DEBUG - 2021-04-15 14:06:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:06:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:06:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:06:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:06:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:06:59 --> Total execution time: 0.0802
DEBUG - 2021-04-15 14:07:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:07:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:07:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:07:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:07:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:07:00 --> Total execution time: 0.0548
DEBUG - 2021-04-15 14:11:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:11:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:11:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:11:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:11:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:11:12 --> Total execution time: 0.0373
DEBUG - 2021-04-15 14:11:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:11:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:11:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:11:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:11:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:11:16 --> Total execution time: 0.0488
DEBUG - 2021-04-15 14:14:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:14:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:14:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:14:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:14:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:14:45 --> Total execution time: 0.0370
DEBUG - 2021-04-15 14:15:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:15:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:15:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:15:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:15:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:15:40 --> Total execution time: 0.0352
DEBUG - 2021-04-15 14:15:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:15:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:15:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:15:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:15:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:15:59 --> Total execution time: 0.0533
DEBUG - 2021-04-15 14:16:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:16:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:16:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:16:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:16:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:16:02 --> Total execution time: 0.0479
DEBUG - 2021-04-15 14:16:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:16:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:16:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:16:03 --> Total execution time: 0.0330
DEBUG - 2021-04-15 14:17:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:17:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:17:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:17:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:17:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:17:10 --> Total execution time: 0.0391
DEBUG - 2021-04-15 14:17:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:17:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:17:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:17:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:17:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:17:24 --> Total execution time: 0.0541
DEBUG - 2021-04-15 14:18:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:18:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:18:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:18:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:18:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:18:51 --> Total execution time: 0.0600
DEBUG - 2021-04-15 14:19:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:19:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:19:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:19:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:19:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:19:12 --> Total execution time: 0.0349
DEBUG - 2021-04-15 14:19:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:19:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:19:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:19:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:19:24 --> Total execution time: 0.0464
DEBUG - 2021-04-15 14:20:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:20:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:20:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:20:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:20:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:20:16 --> Total execution time: 0.0515
DEBUG - 2021-04-15 14:20:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:20:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:20:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:20:51 --> Total execution time: 0.0581
DEBUG - 2021-04-15 14:22:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:22:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:22:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:22:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:22:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:22:06 --> Total execution time: 0.0336
DEBUG - 2021-04-15 14:22:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:22:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:22:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:22:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:22:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:22:17 --> Total execution time: 0.0527
DEBUG - 2021-04-15 14:22:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:22:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:22:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:22:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:22:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:22:29 --> Total execution time: 0.0361
DEBUG - 2021-04-15 14:22:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:22:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:22:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:22:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:22:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:22:38 --> Total execution time: 0.0476
DEBUG - 2021-04-15 14:22:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:22:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:22:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:22:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:22:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:22:44 --> Total execution time: 0.0420
DEBUG - 2021-04-15 14:23:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:23:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:23:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:23:10 --> Total execution time: 0.0457
DEBUG - 2021-04-15 14:24:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:24:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:24:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:24:04 --> Total execution time: 0.0578
DEBUG - 2021-04-15 14:24:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:24:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:24:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:24:28 --> Total execution time: 0.0662
DEBUG - 2021-04-15 14:24:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:24:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:24:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:24:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:24:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-15 14:24:43 --> Total execution time: 0.0562
DEBUG - 2021-04-15 14:26:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:26:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:26:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:26:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:26:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:26:35 --> Total execution time: 0.0550
DEBUG - 2021-04-15 14:26:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:26:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:26:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:26:48 --> Total execution time: 0.0531
DEBUG - 2021-04-15 14:29:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:29:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:29:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:29:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:29:16 --> Total execution time: 0.0530
DEBUG - 2021-04-15 14:31:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:31:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:31:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:31:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:31:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:31:00 --> Total execution time: 0.0447
DEBUG - 2021-04-15 14:31:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:31:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:31:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:31:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:31:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:31:07 --> Total execution time: 0.0538
DEBUG - 2021-04-15 14:31:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:31:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:31:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:31:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:31:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:31:45 --> Total execution time: 0.0556
DEBUG - 2021-04-15 14:32:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:32:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:32:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:32:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:32:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:32:13 --> Total execution time: 0.0355
DEBUG - 2021-04-15 14:33:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:33:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:33:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:33:12 --> Total execution time: 0.0358
DEBUG - 2021-04-15 14:34:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:34:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:34:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:34:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:34:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:34:05 --> Total execution time: 0.0349
DEBUG - 2021-04-15 14:34:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:34:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:34:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:34:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:34:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:34:17 --> Total execution time: 0.0498
DEBUG - 2021-04-15 14:35:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:35:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:35:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:35:04 --> Total execution time: 0.0353
DEBUG - 2021-04-15 14:35:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:35:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:35:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:35:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:35:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:35:06 --> Total execution time: 0.0553
DEBUG - 2021-04-15 14:35:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:35:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:35:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:35:07 --> Total execution time: 0.0559
DEBUG - 2021-04-15 14:35:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:35:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:35:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:35:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:35:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:35:07 --> Total execution time: 0.0346
DEBUG - 2021-04-15 14:36:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:36:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:36:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:36:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:36:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:36:57 --> Total execution time: 0.0346
DEBUG - 2021-04-15 14:37:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:37:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:37:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:37:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:37:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:37:57 --> Total execution time: 0.0465
DEBUG - 2021-04-15 14:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:38:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:38:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:38:23 --> Total execution time: 0.0351
DEBUG - 2021-04-15 14:38:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:38:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:38:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:38:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:38:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:38:41 --> Total execution time: 0.0348
DEBUG - 2021-04-15 14:38:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:38:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:38:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:38:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:38:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:38:43 --> Total execution time: 0.0347
DEBUG - 2021-04-15 14:39:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:39:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:39:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:39:07 --> Total execution time: 0.0570
DEBUG - 2021-04-15 14:39:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:39:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:39:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:39:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:39:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:39:38 --> Total execution time: 0.0471
DEBUG - 2021-04-15 14:39:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:39:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:39:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:39:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:39:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:39:53 --> Total execution time: 0.0346
DEBUG - 2021-04-15 14:39:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:39:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:39:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:39:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:39:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:39:59 --> Total execution time: 0.0337
DEBUG - 2021-04-15 14:44:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:44:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:44:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:44:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:44:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:44:36 --> Total execution time: 0.0545
DEBUG - 2021-04-15 14:44:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:44:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:44:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:44:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:44:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:44:48 --> Total execution time: 0.0377
DEBUG - 2021-04-15 14:45:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:45:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:45:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:45:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:45:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:45:13 --> Total execution time: 0.0345
DEBUG - 2021-04-15 14:45:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:45:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:45:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:45:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:45:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:45:44 --> Total execution time: 0.0548
DEBUG - 2021-04-15 14:45:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:45:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:45:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:45:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:45:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:45:56 --> Total execution time: 0.0358
DEBUG - 2021-04-15 14:47:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:47:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:47:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:47:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:47:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:47:55 --> Total execution time: 0.0347
DEBUG - 2021-04-15 14:48:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:48:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:48:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:48:12 --> Total execution time: 0.0386
DEBUG - 2021-04-15 14:48:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:48:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:48:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:48:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:48:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:48:37 --> Total execution time: 0.0348
DEBUG - 2021-04-15 14:48:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:48:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:48:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:48:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:48:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:48:46 --> Total execution time: 0.0535
DEBUG - 2021-04-15 14:49:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:49:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:49:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:49:00 --> Total execution time: 0.0360
DEBUG - 2021-04-15 14:49:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:49:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:49:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:49:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:49:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:49:12 --> Total execution time: 0.0471
DEBUG - 2021-04-15 14:49:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:49:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:49:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:49:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:49:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:49:30 --> Total execution time: 0.0514
DEBUG - 2021-04-15 14:49:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:49:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:49:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:49:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:49:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:49:36 --> Total execution time: 0.0390
DEBUG - 2021-04-15 14:50:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:50:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:50:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:50:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:50:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:50:29 --> Total execution time: 0.0428
DEBUG - 2021-04-15 14:50:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:50:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:50:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:50:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:50:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:50:46 --> Total execution time: 0.0547
DEBUG - 2021-04-15 14:50:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:50:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:50:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:50:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:50:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:50:54 --> Total execution time: 0.0376
DEBUG - 2021-04-15 14:51:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:51:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:51:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:51:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:51:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:51:37 --> Total execution time: 0.0388
DEBUG - 2021-04-15 14:51:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:51:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:51:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:51:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:51:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:51:49 --> Total execution time: 0.0380
DEBUG - 2021-04-15 14:52:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:52:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:52:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:52:02 --> Total execution time: 0.0355
DEBUG - 2021-04-15 14:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:52:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:52:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:52:26 --> Total execution time: 0.0379
DEBUG - 2021-04-15 14:53:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:53:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:53:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:53:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:53:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:53:25 --> Total execution time: 0.0408
DEBUG - 2021-04-15 14:53:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:53:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:53:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:53:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:53:43 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-15 14:53:43 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:53:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:53:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:53:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:53:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:53:44 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-15 14:53:44 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:53:46 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:53:46 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:53:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:53:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:53:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:53:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:53:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:53:51 --> Total execution time: 0.0405
DEBUG - 2021-04-15 14:54:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:03 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-15 14:54:03 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:03 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:03 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:04 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:04 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:54:04 --> UTF-8 Support Enabled
ERROR - 2021-04-15 14:54:04 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:04 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:05 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-15 14:54:05 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:05 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:05 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:54:07 --> UTF-8 Support Enabled
ERROR - 2021-04-15 14:54:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:54:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:54:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:54:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:54:31 --> Total execution time: 0.0411
DEBUG - 2021-04-15 14:54:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:55 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:55 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:55 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:54:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:54:55 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:55:02 --> UTF-8 Support Enabled
ERROR - 2021-04-15 14:55:02 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:02 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:03 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:03 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:04 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:04 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:04 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:04 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:05 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:05 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:09 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:09 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:10 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:10 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:55:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-15 14:55:14 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:22 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 14:55:22 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 14:55:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:55:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:55:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:55:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:55:29 --> Total execution time: 0.0519
DEBUG - 2021-04-15 14:55:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:55:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:55:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:55:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:55:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:55:40 --> Total execution time: 0.0552
DEBUG - 2021-04-15 14:56:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:56:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:56:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:56:34 --> Total execution time: 0.0340
DEBUG - 2021-04-15 14:56:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:56:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:56:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:56:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:56:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:56:34 --> Total execution time: 0.0348
DEBUG - 2021-04-15 14:56:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:56:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:56:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:56:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:56:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:56:35 --> Total execution time: 0.0437
DEBUG - 2021-04-15 14:56:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:56:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:56:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:56:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:56:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:56:36 --> Total execution time: 0.1474
DEBUG - 2021-04-15 14:56:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:56:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:56:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:56:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 14:56:41 --> Total execution time: 0.1131
DEBUG - 2021-04-15 14:56:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:56:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:56:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:56:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:56:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:56:43 --> Total execution time: 0.0553
DEBUG - 2021-04-15 14:56:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 14:56:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 14:56:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 14:56:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 14:56:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 14:56:44 --> Total execution time: 0.0459
DEBUG - 2021-04-15 15:07:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:07:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:07:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:07:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:07:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:07:14 --> Total execution time: 0.0385
DEBUG - 2021-04-15 15:07:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:07:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:07:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:07:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:07:31 --> Total execution time: 3.4577
DEBUG - 2021-04-15 15:07:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:07:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:07:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:07:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:07:57 --> Total execution time: 0.0361
DEBUG - 2021-04-15 15:12:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:12:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 15:12:44 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 59
DEBUG - 2021-04-15 15:12:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:12:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 15:12:46 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 59
DEBUG - 2021-04-15 15:12:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:12:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 15:12:49 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 59
DEBUG - 2021-04-15 15:12:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 15:12:50 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ',' or ')' D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 59
DEBUG - 2021-04-15 15:14:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:14:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:14:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:14:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:14:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:14:00 --> Total execution time: 0.0393
DEBUG - 2021-04-15 15:14:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:14:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:14:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:14:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:14:18 --> Total execution time: 3.1663
DEBUG - 2021-04-15 15:14:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:14:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:14:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:14:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:14:59 --> Total execution time: 0.0547
DEBUG - 2021-04-15 15:17:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:17:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:17:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:17:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:17:16 --> Total execution time: 0.0619
DEBUG - 2021-04-15 15:17:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:17:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:17:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:17:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:17:29 --> Total execution time: 0.0403
DEBUG - 2021-04-15 15:18:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:18:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 15:18:21 --> Severity: error --> Exception: syntax error, unexpected '_' (T_STRING) D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 87
DEBUG - 2021-04-15 15:18:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:18:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 15:18:22 --> Severity: error --> Exception: syntax error, unexpected '_' (T_STRING) D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 87
DEBUG - 2021-04-15 15:18:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:18:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:18:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:18:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:18:46 --> Total execution time: 0.0640
DEBUG - 2021-04-15 15:19:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:19:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:19:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:19:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:19:11 --> Total execution time: 0.0379
DEBUG - 2021-04-15 15:20:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:20:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:20:17 --> Total execution time: 0.0382
DEBUG - 2021-04-15 15:20:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:20:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:20:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:20:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:20:40 --> Total execution time: 0.0347
DEBUG - 2021-04-15 15:20:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:20:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:20:49 --> Severity: error --> Exception: Call to undefined method stdClass::num_rows() D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 88
DEBUG - 2021-04-15 15:20:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:20:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:20:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:20:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:20:50 --> Severity: error --> Exception: Call to undefined method stdClass::num_rows() D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 88
DEBUG - 2021-04-15 15:20:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:20:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:20:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:20:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:20:57 --> Total execution time: 0.0513
DEBUG - 2021-04-15 15:21:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:21:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:21:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:21:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:21:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:21:53 --> Total execution time: 0.0628
DEBUG - 2021-04-15 15:23:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:23:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:23:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:23:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:23:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:23:20 --> Total execution time: 0.0612
DEBUG - 2021-04-15 15:23:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:23:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:23:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:23:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:23:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:23:37 --> Total execution time: 0.0609
DEBUG - 2021-04-15 15:25:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:25:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:25:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:25:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:25:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:25:00 --> Total execution time: 0.0556
DEBUG - 2021-04-15 15:25:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:25:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:25:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:25:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:25:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:25:10 --> Total execution time: 0.0436
DEBUG - 2021-04-15 15:25:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:25:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:25:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:25:29 --> Total execution time: 0.0552
DEBUG - 2021-04-15 15:26:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:26:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:26:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:26:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:26:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:26:12 --> Total execution time: 0.0503
DEBUG - 2021-04-15 15:27:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:27:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:27:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:27:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:27:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:27:13 --> Total execution time: 0.0606
DEBUG - 2021-04-15 15:27:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:27:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:27:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:27:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:27:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:27:40 --> Total execution time: 0.0613
DEBUG - 2021-04-15 15:28:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:01 --> Total execution time: 0.0599
DEBUG - 2021-04-15 15:28:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:03 --> Total execution time: 0.0364
DEBUG - 2021-04-15 15:28:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:04 --> Total execution time: 0.0550
DEBUG - 2021-04-15 15:28:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:06 --> Total execution time: 0.0598
DEBUG - 2021-04-15 15:28:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:07 --> Total execution time: 0.0607
DEBUG - 2021-04-15 15:28:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:07 --> Total execution time: 0.0542
DEBUG - 2021-04-15 15:28:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:08 --> Total execution time: 0.0371
DEBUG - 2021-04-15 15:28:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:08 --> Total execution time: 0.0513
DEBUG - 2021-04-15 15:28:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:10 --> Total execution time: 0.0343
DEBUG - 2021-04-15 15:28:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:11 --> Total execution time: 0.0467
DEBUG - 2021-04-15 15:28:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:24 --> Total execution time: 0.0527
DEBUG - 2021-04-15 15:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 15:28:30 --> Total execution time: 0.0618
DEBUG - 2021-04-15 15:28:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:28:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:28:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:28:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:28:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:28:44 --> Total execution time: 0.0383
DEBUG - 2021-04-15 15:30:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:30:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:30:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:30:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:30:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:30:55 --> Total execution time: 0.1136
DEBUG - 2021-04-15 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:31:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:31:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:31:14 --> Total execution time: 0.0340
DEBUG - 2021-04-15 15:33:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:33:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:33:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:33:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:33:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:33:53 --> Total execution time: 0.0384
DEBUG - 2021-04-15 15:34:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:34:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:34:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:34:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:34:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:34:26 --> Total execution time: 3.9288
DEBUG - 2021-04-15 15:35:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:35:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:35:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:35:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:35:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:35:10 --> Total execution time: 0.1952
DEBUG - 2021-04-15 15:35:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 15:35:10 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 15:35:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:35:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 15:35:10 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 15:35:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:35:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:35:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:35:37 --> Total execution time: 0.0527
DEBUG - 2021-04-15 15:35:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:35:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:35:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:35:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:35:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:35:40 --> Total execution time: 0.0543
DEBUG - 2021-04-15 15:35:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:35:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:35:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:35:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:35:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:35:41 --> Total execution time: 0.0351
DEBUG - 2021-04-15 15:36:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:36:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:36:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:36:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:36:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:36:32 --> Total execution time: 0.0399
DEBUG - 2021-04-15 15:47:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:47:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 15:47:17 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 92
DEBUG - 2021-04-15 15:47:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:47:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 15:47:42 --> Severity: error --> Exception: syntax error, unexpected '=>' (T_DOUBLE_ARROW), expecting ']' D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 92
DEBUG - 2021-04-15 15:48:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:48:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:48:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:48:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:48:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:48:08 --> Total execution time: 0.0531
DEBUG - 2021-04-15 15:48:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:48:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:48:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:48:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:48:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:48:22 --> Total execution time: 0.0497
DEBUG - 2021-04-15 15:50:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:50:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:50:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:50:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:50:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:50:53 --> Total execution time: 0.0457
DEBUG - 2021-04-15 15:50:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 15:50:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 15:50:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 15:50:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 15:50:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 15:50:58 --> Total execution time: 0.0928
DEBUG - 2021-04-15 16:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:07:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:07:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:07:05 --> Total execution time: 0.1052
DEBUG - 2021-04-15 16:07:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:07:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:07:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:07:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:07:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:07:31 --> Total execution time: 0.0363
DEBUG - 2021-04-15 16:07:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:07:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:07:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:07:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:07:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:07:50 --> Total execution time: 3.5603
DEBUG - 2021-04-15 16:08:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:08:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:08:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:08:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:08:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:08:02 --> Total execution time: 0.0848
DEBUG - 2021-04-15 16:08:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:08:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:08:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:08:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:08:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:08:18 --> Total execution time: 0.0540
DEBUG - 2021-04-15 16:08:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:08:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:08:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:08:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:08:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:08:20 --> Total execution time: 0.0449
DEBUG - 2021-04-15 16:08:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:08:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:08:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:08:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:08:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:08:57 --> Total execution time: 0.0386
DEBUG - 2021-04-15 16:09:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:09:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:09:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:09:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:09:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:09:12 --> Total execution time: 0.0351
DEBUG - 2021-04-15 16:09:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:09:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:09:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:09:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:09:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:09:19 --> Total execution time: 0.0495
DEBUG - 2021-04-15 16:10:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:10:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:10:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:10:00 --> Total execution time: 0.0381
DEBUG - 2021-04-15 16:11:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:11:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:11:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:11:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:11:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:11:06 --> Total execution time: 0.0419
DEBUG - 2021-04-15 16:11:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:11:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:11:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:11:31 --> Total execution time: 0.0365
DEBUG - 2021-04-15 16:11:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:11:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:11:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:11:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:11:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:11:53 --> Total execution time: 0.0389
DEBUG - 2021-04-15 16:13:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:13:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:13:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:13:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:13:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:13:28 --> Total execution time: 0.0371
DEBUG - 2021-04-15 16:13:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:13:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:13:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:13:40 --> Total execution time: 0.0353
DEBUG - 2021-04-15 16:13:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:13:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:13:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:13:41 --> Total execution time: 0.0345
DEBUG - 2021-04-15 16:13:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:13:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:13:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:13:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:13:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:13:49 --> Total execution time: 0.0560
DEBUG - 2021-04-15 16:14:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:14:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:14:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:14:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:14:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:14:02 --> Total execution time: 0.0337
DEBUG - 2021-04-15 16:14:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:14:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:14:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:14:03 --> Total execution time: 0.0339
DEBUG - 2021-04-15 16:14:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:14:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:14:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:14:03 --> Total execution time: 0.0356
DEBUG - 2021-04-15 16:14:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:14:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:14:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:14:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:14:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:14:03 --> Total execution time: 0.0575
DEBUG - 2021-04-15 16:14:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:14:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:14:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:14:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:14:13 --> Total execution time: 0.0355
DEBUG - 2021-04-15 16:14:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:14:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:14:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:14:19 --> Total execution time: 0.0350
DEBUG - 2021-04-15 16:15:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:15:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:15:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:15:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:15:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:15:04 --> Total execution time: 0.0355
DEBUG - 2021-04-15 16:15:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:15:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:15:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:15:05 --> Total execution time: 0.0554
DEBUG - 2021-04-15 16:15:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:15:24 --> No URI present. Default controller set.
DEBUG - 2021-04-15 16:15:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:15:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:15:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:15:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:15:24 --> Total execution time: 0.0347
DEBUG - 2021-04-15 16:15:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:15:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:15:25 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 16:15:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:15:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:15:25 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 16:15:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:15:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:15:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:15:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:15:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:15:26 --> Total execution time: 0.0525
DEBUG - 2021-04-15 16:15:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:15:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:15:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:15:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:15:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:15:44 --> Total execution time: 0.0365
DEBUG - 2021-04-15 16:15:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:15:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:15:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:15:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:15:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:15:46 --> Total execution time: 0.0511
DEBUG - 2021-04-15 16:18:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:18:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:18:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:18:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:18:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:18:05 --> Total execution time: 0.0392
DEBUG - 2021-04-15 16:18:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:18:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:18:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:18:06 --> Total execution time: 0.0346
DEBUG - 2021-04-15 16:18:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:18:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:18:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:18:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:18:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:18:06 --> Total execution time: 0.0345
DEBUG - 2021-04-15 16:18:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:18:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:18:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:18:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:18:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:18:07 --> Total execution time: 0.0335
DEBUG - 2021-04-15 16:18:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:18:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:18:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:18:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:18:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:18:20 --> Total execution time: 3.1638
DEBUG - 2021-04-15 16:19:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:19:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:19:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:19:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:19:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:19:04 --> Total execution time: 2.2004
DEBUG - 2021-04-15 16:19:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:19:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:19:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:19:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:19:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:19:32 --> Total execution time: 0.0380
DEBUG - 2021-04-15 16:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:19:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:19:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:19:37 --> Total execution time: 0.0560
DEBUG - 2021-04-15 16:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:19:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:19:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:19:37 --> Total execution time: 0.0357
DEBUG - 2021-04-15 16:19:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:19:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:19:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:19:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:19:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:19:37 --> Total execution time: 0.0497
DEBUG - 2021-04-15 16:19:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:19:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:19:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:19:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:19:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:19:39 --> Total execution time: 0.0383
DEBUG - 2021-04-15 16:19:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:19:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:19:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:19:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:19:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:19:46 --> Total execution time: 0.0524
DEBUG - 2021-04-15 16:20:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:20:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:20:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:20:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:20:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:20:01 --> Total execution time: 0.0481
DEBUG - 2021-04-15 16:20:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:20:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:20:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:20:29 --> Total execution time: 0.0490
DEBUG - 2021-04-15 16:20:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:20:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:20:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:20:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:20:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:20:30 --> Total execution time: 0.0358
DEBUG - 2021-04-15 16:20:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:20:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:20:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:20:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:20:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:20:37 --> Total execution time: 0.0601
DEBUG - 2021-04-15 16:20:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:20:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:20:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:20:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:20:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:20:49 --> Total execution time: 0.0587
DEBUG - 2021-04-15 16:20:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:20:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:20:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:20:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:20:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:20:51 --> Total execution time: 0.0570
DEBUG - 2021-04-15 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:21:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:21:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:21:48 --> Total execution time: 0.0369
DEBUG - 2021-04-15 16:21:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:21:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:21:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:21:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:21:48 --> Total execution time: 0.0526
DEBUG - 2021-04-15 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:21:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:21:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:21:49 --> Total execution time: 0.0368
DEBUG - 2021-04-15 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:21:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:21:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:21:49 --> Total execution time: 0.0554
DEBUG - 2021-04-15 16:21:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:21:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:21:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:21:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:21:50 --> Total execution time: 0.0541
DEBUG - 2021-04-15 16:22:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:22:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:22:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:22:33 --> Total execution time: 0.0407
DEBUG - 2021-04-15 16:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:22:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:22:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:22:51 --> Total execution time: 0.0356
DEBUG - 2021-04-15 16:22:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:22:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:22:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:22:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:22:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:22:52 --> Total execution time: 0.0373
DEBUG - 2021-04-15 16:23:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:23:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:23:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:23:08 --> Total execution time: 0.0364
DEBUG - 2021-04-15 16:23:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:23:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:23:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:23:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:23:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:23:12 --> Total execution time: 0.0372
DEBUG - 2021-04-15 16:23:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:23:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:23:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:23:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:23:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:23:22 --> Total execution time: 0.0415
DEBUG - 2021-04-15 16:23:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:23:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:23:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:23:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:23:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:23:30 --> Total execution time: 0.0590
DEBUG - 2021-04-15 16:24:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:24:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:24:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:24:04 --> Total execution time: 0.0567
DEBUG - 2021-04-15 16:24:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:24:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:24:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:24:05 --> Total execution time: 0.0543
DEBUG - 2021-04-15 16:24:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:24:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:24:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:24:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 16:24:12 --> Total execution time: 0.0598
DEBUG - 2021-04-15 16:24:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:24:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:24:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:24:14 --> Total execution time: 0.0347
DEBUG - 2021-04-15 16:24:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:24:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 16:24:22 --> Total execution time: 0.0540
DEBUG - 2021-04-15 16:24:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:24:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:24:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:24:23 --> Total execution time: 0.0553
DEBUG - 2021-04-15 16:24:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:24:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:24:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:24:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 16:24:52 --> Total execution time: 0.0552
DEBUG - 2021-04-15 16:24:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:24:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:24:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:24:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:24:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:24:58 --> Total execution time: 0.0430
DEBUG - 2021-04-15 16:25:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:25:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:25:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:25:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:25:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:25:03 --> Total execution time: 0.0375
DEBUG - 2021-04-15 16:25:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:25:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:25:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:25:07 --> Total execution time: 0.0343
DEBUG - 2021-04-15 16:25:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:25:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:25:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:25:07 --> Total execution time: 0.0494
DEBUG - 2021-04-15 16:25:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:25:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:25:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:25:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 16:25:29 --> Total execution time: 0.0368
DEBUG - 2021-04-15 16:25:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:25:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:25:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:25:31 --> Total execution time: 0.0340
DEBUG - 2021-04-15 16:26:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:26:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:26:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:26:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:26:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:26:47 --> Total execution time: 0.0402
DEBUG - 2021-04-15 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:27:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:27:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:27:14 --> Total execution time: 0.0406
DEBUG - 2021-04-15 16:27:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:27:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:27:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:27:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:27:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:27:47 --> Total execution time: 0.0473
DEBUG - 2021-04-15 16:27:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:27:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:27:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:27:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:27:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:27:49 --> Total execution time: 0.0346
DEBUG - 2021-04-15 16:27:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:27:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:27:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:27:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:27:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:27:56 --> Total execution time: 3.0543
DEBUG - 2021-04-15 16:28:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:28:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:28:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:28:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:28:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:28:03 --> Total execution time: 0.0399
DEBUG - 2021-04-15 16:28:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:28:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:28:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:28:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:28:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:28:05 --> Total execution time: 0.0447
DEBUG - 2021-04-15 16:28:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:28:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:28:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:28:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:28:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:28:18 --> Total execution time: 0.1107
DEBUG - 2021-04-15 16:28:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:28:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:28:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:28:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:28:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:28:25 --> Total execution time: 0.0594
DEBUG - 2021-04-15 16:28:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:28:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:28:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:28:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 16:28:31 --> Total execution time: 0.0380
DEBUG - 2021-04-15 16:28:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:28:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:28:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:28:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:28:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:28:33 --> Total execution time: 0.0464
DEBUG - 2021-04-15 16:29:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:29:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:29:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:29:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:29:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:29:34 --> Total execution time: 0.0427
DEBUG - 2021-04-15 16:29:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:29:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:29:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:29:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 16:29:42 --> Total execution time: 0.0466
DEBUG - 2021-04-15 16:29:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:29:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:29:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:29:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 16:29:57 --> Total execution time: 0.0529
DEBUG - 2021-04-15 16:30:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:30:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:30:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:30:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 16:30:27 --> Total execution time: 0.0965
DEBUG - 2021-04-15 16:30:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:30:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:30:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:30:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:30:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:30:45 --> Total execution time: 0.0397
DEBUG - 2021-04-15 16:30:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:30:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:30:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:30:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:30:52 --> Severity: Warning --> Cannot use a scalar value as an array D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 127
ERROR - 2021-04-15 16:30:52 --> Severity: Warning --> Cannot use a scalar value as an array D:\__myproject.my\SIG-trayek\application\controllers\Secure.php 128
DEBUG - 2021-04-15 16:31:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:01 --> Total execution time: 0.0533
DEBUG - 2021-04-15 16:31:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 16:31:22 --> Total execution time: 0.0581
DEBUG - 2021-04-15 16:31:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:25 --> Total execution time: 0.0351
DEBUG - 2021-04-15 16:31:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:30 --> Total execution time: 0.0331
DEBUG - 2021-04-15 16:31:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:32 --> Total execution time: 0.0330
DEBUG - 2021-04-15 16:31:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:32 --> Total execution time: 0.0439
DEBUG - 2021-04-15 16:31:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:33 --> Total execution time: 0.0311
DEBUG - 2021-04-15 16:31:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:34 --> Total execution time: 0.0347
DEBUG - 2021-04-15 16:31:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:35 --> Total execution time: 0.0534
DEBUG - 2021-04-15 16:31:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:35 --> Total execution time: 0.0590
DEBUG - 2021-04-15 16:31:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:36 --> Total execution time: 0.0549
DEBUG - 2021-04-15 16:31:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:36 --> Total execution time: 0.0357
DEBUG - 2021-04-15 16:31:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:37 --> Total execution time: 0.0533
DEBUG - 2021-04-15 16:31:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:37 --> Total execution time: 0.0556
DEBUG - 2021-04-15 16:31:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:38 --> Total execution time: 0.0483
DEBUG - 2021-04-15 16:31:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:31:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:31:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:31:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:31:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:31:56 --> Total execution time: 0.0551
DEBUG - 2021-04-15 16:38:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:38:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:38:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:38:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:38:14 --> Total execution time: 0.0493
DEBUG - 2021-04-15 16:38:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:38:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:38:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:38:15 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:38:15 --> Total execution time: 0.0362
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:38:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:38:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:38:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 16:38:23 --> Total execution time: 0.0596
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/avatar
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/avatar
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/logo2.png
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/avatar
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 16:38:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:23 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-15 16:38:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:38:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:24 --> 404 Page Not Found: Apple-iconpng/index
DEBUG - 2021-04-15 16:38:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 16:38:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-04-15 16:39:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:39:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:39:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:39:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:39:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 16:39:12 --> Total execution time: 0.0530
DEBUG - 2021-04-15 16:39:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:39:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:39:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:39:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:39:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 16:39:14 --> Total execution time: 0.0565
DEBUG - 2021-04-15 16:39:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:39:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:39:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:39:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:39:15 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 16:39:15 --> Total execution time: 0.0517
DEBUG - 2021-04-15 16:39:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:39:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:39:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 16:39:16 --> Total execution time: 0.0544
DEBUG - 2021-04-15 16:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:39:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:39:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 16:39:37 --> Total execution time: 0.0568
DEBUG - 2021-04-15 16:40:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:40:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:40:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:40:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:40:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 16:40:07 --> Total execution time: 0.0437
DEBUG - 2021-04-15 16:40:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:40:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:40:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 16:40:09 --> Total execution time: 0.0572
DEBUG - 2021-04-15 16:40:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:40:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:40:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 16:40:10 --> Total execution time: 0.0542
DEBUG - 2021-04-15 16:40:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:40:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:40:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:40:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:40:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 16:40:55 --> Total execution time: 0.0356
DEBUG - 2021-04-15 16:44:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:44:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:44:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:44:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:44:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 16:44:49 --> Total execution time: 0.0359
DEBUG - 2021-04-15 16:44:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:44:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 16:44:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:44:52 --> No URI present. Default controller set.
DEBUG - 2021-04-15 16:44:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:44:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:44:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:44:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:44:52 --> Total execution time: 0.0509
DEBUG - 2021-04-15 16:57:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 16:57:53 --> No URI present. Default controller set.
DEBUG - 2021-04-15 16:57:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 16:57:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 16:57:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 16:57:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 16:57:53 --> Total execution time: 0.0378
DEBUG - 2021-04-15 17:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:02:24 --> No URI present. Default controller set.
DEBUG - 2021-04-15 17:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:02:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:02:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 17:02:24 --> Total execution time: 0.0345
DEBUG - 2021-04-15 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:02:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:02:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 17:02:25 --> Total execution time: 0.0570
DEBUG - 2021-04-15 17:02:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:02:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:02:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:02:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:02:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:02:32 --> Total execution time: 0.0605
DEBUG - 2021-04-15 17:02:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:02:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:02:32 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-15 17:02:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:02:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:02:33 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:02:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:02:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:02:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:02:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:02:33 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-15 17:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:02:33 --> 404 Page Not Found: Images/avatar
ERROR - 2021-04-15 17:02:33 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-15 17:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:02:33 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:02:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:02:33 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:02:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:02:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:02:33 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-15 17:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:03:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:03:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:03:00 --> Total execution time: 0.0433
DEBUG - 2021-04-15 17:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:03:00 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-15 17:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:03:00 --> UTF-8 Support Enabled
ERROR - 2021-04-15 17:03:00 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:03:00 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:03:00 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-15 17:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:03:00 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:03:00 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:03:00 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-15 17:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:03:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:03:00 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-15 17:03:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:03:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:03:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:03:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:03:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:03:03 --> Total execution time: 0.0491
DEBUG - 2021-04-15 17:03:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:03:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:03:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:03:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:03:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:03:38 --> Total execution time: 0.0497
DEBUG - 2021-04-15 17:04:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:04:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:04:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:04:06 --> Total execution time: 0.0396
DEBUG - 2021-04-15 17:04:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:04:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:04:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:04:21 --> Total execution time: 0.0612
DEBUG - 2021-04-15 17:04:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:04:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:04:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:04:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:04:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:04:40 --> Total execution time: 0.0349
DEBUG - 2021-04-15 17:04:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:04:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:04:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:04:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:04:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:04:42 --> Total execution time: 0.0602
DEBUG - 2021-04-15 17:04:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:04:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:04:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:04:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:04:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:04:44 --> Total execution time: 0.0582
DEBUG - 2021-04-15 17:04:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:04:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:04:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:04:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:04:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:04:45 --> Total execution time: 0.0569
DEBUG - 2021-04-15 17:04:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:04:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:04:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:04:47 --> Total execution time: 0.0356
DEBUG - 2021-04-15 17:04:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:04:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:04:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:04:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:04:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:04:49 --> Total execution time: 0.0361
DEBUG - 2021-04-15 17:04:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:04:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:04:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:04:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:04:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:04:51 --> Total execution time: 0.0584
DEBUG - 2021-04-15 17:04:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:04:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 17:04:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:04:54 --> No URI present. Default controller set.
DEBUG - 2021-04-15 17:04:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:04:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:04:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:04:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 17:04:54 --> Total execution time: 0.0482
DEBUG - 2021-04-15 17:05:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:05:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:05:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:05:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 17:05:11 --> Total execution time: 0.0606
DEBUG - 2021-04-15 17:05:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:05:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:05:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 17:05:19 --> Total execution time: 0.0622
DEBUG - 2021-04-15 17:05:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:05:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:05:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:05:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 17:05:23 --> Total execution time: 0.0477
DEBUG - 2021-04-15 17:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:05:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:05:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 17:05:27 --> Total execution time: 0.0453
DEBUG - 2021-04-15 17:05:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:05:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:05:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:05:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:05:33 --> Total execution time: 0.0557
DEBUG - 2021-04-15 17:05:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:05:33 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-15 17:05:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:05:33 --> 404 Page Not Found: Images/logo2.png
ERROR - 2021-04-15 17:05:33 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:05:33 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:05:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:05:33 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:05:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:05:33 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:05:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:05:33 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-15 17:05:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:05:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:05:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:05:42 --> Total execution time: 0.0667
DEBUG - 2021-04-15 17:05:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:05:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:05:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:05:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:05:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:05:43 --> Total execution time: 0.0372
DEBUG - 2021-04-15 17:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:15 --> No URI present. Default controller set.
DEBUG - 2021-04-15 17:06:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:06:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:06:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:06:15 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 17:06:15 --> Total execution time: 0.0539
DEBUG - 2021-04-15 17:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:15 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 17:06:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:15 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-15 17:06:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:06:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:06:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:06:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 17:06:17 --> Total execution time: 0.0358
DEBUG - 2021-04-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:06:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:06:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:06:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:06:23 --> Total execution time: 0.0652
DEBUG - 2021-04-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:23 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:23 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:23 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:23 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:23 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:23 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:23 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:23 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-15 17:06:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:23 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-15 17:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:06:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:24 --> 404 Page Not Found: Apple-iconpng/index
ERROR - 2021-04-15 17:06:24 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-04-15 17:06:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:06:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:06:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:06:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 222
DEBUG - 2021-04-15 17:06:27 --> Total execution time: 0.0369
DEBUG - 2021-04-15 17:06:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:27 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-15 17:06:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-15 17:06:27 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-15 17:06:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:06:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:06:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:06:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:06:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-15 17:06:52 --> Total execution time: 0.0376
DEBUG - 2021-04-15 17:07:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:07:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:07:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:07:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:07:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-15 17:07:02 --> Total execution time: 0.0492
DEBUG - 2021-04-15 17:07:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:07:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:07:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-15 17:07:58 --> Total execution time: 0.0565
DEBUG - 2021-04-15 17:08:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:08:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:08:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:08:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:08:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-15 17:08:51 --> Total execution time: 0.0413
DEBUG - 2021-04-15 17:08:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:08:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:08:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:08:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:08:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-15 17:08:56 --> Total execution time: 0.0372
DEBUG - 2021-04-15 17:09:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:09:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:09:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:09:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:09:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-15 17:09:18 --> Total execution time: 0.0394
DEBUG - 2021-04-15 17:09:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:09:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:09:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:09:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-15 17:09:20 --> Total execution time: 0.0560
DEBUG - 2021-04-15 17:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:09:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:09:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-15 17:09:36 --> Total execution time: 0.0352
DEBUG - 2021-04-15 17:09:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:09:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:09:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:09:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-15 17:09:49 --> Total execution time: 0.0589
DEBUG - 2021-04-15 17:10:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:10:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:10:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-15 17:10:00 --> Total execution time: 0.0372
DEBUG - 2021-04-15 17:19:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:19:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:19:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:19:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:19:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-15 17:19:06 --> Total execution time: 0.0535
DEBUG - 2021-04-15 17:19:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:19:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-15 17:19:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-15 17:19:09 --> No URI present. Default controller set.
DEBUG - 2021-04-15 17:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-15 17:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-15 17:19:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-15 17:19:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-15 17:19:09 --> Total execution time: 0.0351
