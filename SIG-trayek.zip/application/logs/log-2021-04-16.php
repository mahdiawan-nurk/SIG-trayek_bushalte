<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-04-16 13:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 13:56:37 --> No URI present. Default controller set.
DEBUG - 2021-04-16 13:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 13:56:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 13:56:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 13:56:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 13:56:37 --> Total execution time: 0.0402
DEBUG - 2021-04-16 13:56:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 13:56:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 13:56:37 --> UTF-8 Support Enabled
ERROR - 2021-04-16 13:56:37 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 13:56:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 13:56:37 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 14:24:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:24:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:24:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:24:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:24:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:24:20 --> Total execution time: 0.0371
DEBUG - 2021-04-16 14:24:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:24:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:24:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:24:21 --> Total execution time: 0.0424
DEBUG - 2021-04-16 14:24:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:24:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:24:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:24:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:24:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:24:22 --> Total execution time: 0.0361
DEBUG - 2021-04-16 14:24:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:24:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:24:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:24:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:24:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:24:23 --> Total execution time: 0.0419
DEBUG - 2021-04-16 14:24:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:24:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:24:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:24:24 --> Total execution time: 0.0475
DEBUG - 2021-04-16 14:24:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:24:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:24:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:24:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:24:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:24:25 --> Total execution time: 0.0443
DEBUG - 2021-04-16 14:24:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:24:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:24:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:24:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:24:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:24:26 --> Total execution time: 0.0391
DEBUG - 2021-04-16 14:24:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:24:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:24:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:24:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:24:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:24:30 --> Total execution time: 0.0338
DEBUG - 2021-04-16 14:29:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:29:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:29:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:29:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:29:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:29:02 --> Total execution time: 0.0452
DEBUG - 2021-04-16 14:29:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:29:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:29:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:29:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:29:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:29:13 --> Total execution time: 0.0481
DEBUG - 2021-04-16 14:29:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:29:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:29:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:29:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:29:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:29:18 --> Total execution time: 0.0389
DEBUG - 2021-04-16 14:29:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:29:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:29:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:29:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:29:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:29:19 --> Total execution time: 0.0331
DEBUG - 2021-04-16 14:29:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:29:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:29:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:29:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:29:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:29:20 --> Total execution time: 0.0362
DEBUG - 2021-04-16 14:30:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:30:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:30:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:30:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:30:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 104
DEBUG - 2021-04-16 14:30:02 --> Total execution time: 0.0418
DEBUG - 2021-04-16 14:30:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:30:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:30:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:30:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:30:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 118
DEBUG - 2021-04-16 14:30:50 --> Total execution time: 0.0449
DEBUG - 2021-04-16 14:31:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:31:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:31:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:31:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:31:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 118
DEBUG - 2021-04-16 14:31:17 --> Total execution time: 0.0370
DEBUG - 2021-04-16 14:32:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:32:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:32:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:32:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:32:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 121
DEBUG - 2021-04-16 14:32:35 --> Total execution time: 0.0344
DEBUG - 2021-04-16 14:32:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:32:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:32:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:32:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:32:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 121
DEBUG - 2021-04-16 14:32:36 --> Total execution time: 0.0425
DEBUG - 2021-04-16 14:32:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:32:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:32:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:32:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:32:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 121
DEBUG - 2021-04-16 14:32:37 --> Total execution time: 0.0425
DEBUG - 2021-04-16 14:32:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:32:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:32:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:32:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:32:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:32:48 --> Total execution time: 0.0333
DEBUG - 2021-04-16 14:32:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:32:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:32:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:32:49 --> Total execution time: 0.0330
DEBUG - 2021-04-16 14:32:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:32:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:32:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:32:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:32:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:32:49 --> Total execution time: 0.0412
DEBUG - 2021-04-16 14:32:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:32:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:32:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:32:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:32:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:32:50 --> Total execution time: 0.0382
DEBUG - 2021-04-16 14:33:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:33:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:33:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:33:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:33:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:33:36 --> Total execution time: 0.0399
DEBUG - 2021-04-16 14:34:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:34:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:34:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 123
DEBUG - 2021-04-16 14:34:11 --> Total execution time: 0.0512
DEBUG - 2021-04-16 14:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:34:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:34:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 123
DEBUG - 2021-04-16 14:34:24 --> Total execution time: 0.0395
DEBUG - 2021-04-16 14:35:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:35:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:35:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 14:35:27 --> Total execution time: 0.0404
DEBUG - 2021-04-16 14:35:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:35:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:35:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 14:35:42 --> Total execution time: 0.0484
DEBUG - 2021-04-16 14:35:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:35:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:35:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:35:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:35:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 14:35:49 --> Total execution time: 0.0350
DEBUG - 2021-04-16 14:35:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:35:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:35:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:35:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:35:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 14:35:57 --> Total execution time: 0.0441
DEBUG - 2021-04-16 14:36:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:36:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:36:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:36:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:36:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 14:36:08 --> Total execution time: 0.0332
DEBUG - 2021-04-16 14:37:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:37:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:37:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:37:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:37:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 126
DEBUG - 2021-04-16 14:37:30 --> Total execution time: 0.0371
DEBUG - 2021-04-16 14:37:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:37:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:37:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:37:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:37:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 126
DEBUG - 2021-04-16 14:37:56 --> Total execution time: 0.0342
DEBUG - 2021-04-16 14:38:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:38:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:38:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:38:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:38:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 126
DEBUG - 2021-04-16 14:38:08 --> Total execution time: 0.0390
DEBUG - 2021-04-16 14:38:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:38:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:38:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:38:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:38:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 126
DEBUG - 2021-04-16 14:38:22 --> Total execution time: 0.0476
DEBUG - 2021-04-16 14:39:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:39:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:39:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:39:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:39:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 126
DEBUG - 2021-04-16 14:39:16 --> Total execution time: 0.0388
DEBUG - 2021-04-16 14:40:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:40:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:40:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:40:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:40:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:40:09 --> Total execution time: 0.0360
DEBUG - 2021-04-16 14:40:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:40:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:40:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:40:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:40:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:40:11 --> Total execution time: 0.0367
DEBUG - 2021-04-16 14:40:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:40:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:40:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:40:12 --> Total execution time: 0.0481
DEBUG - 2021-04-16 14:40:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:40:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:40:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:40:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:40:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:40:12 --> Total execution time: 0.0335
DEBUG - 2021-04-16 14:40:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:40:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:40:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:40:13 --> Total execution time: 0.0334
DEBUG - 2021-04-16 14:40:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:40:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:40:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:40:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:40:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:40:13 --> Total execution time: 0.0495
DEBUG - 2021-04-16 14:40:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:40:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:40:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:40:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:40:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:40:25 --> Total execution time: 0.0519
DEBUG - 2021-04-16 14:41:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:41:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:41:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:41:57 --> Total execution time: 0.0356
DEBUG - 2021-04-16 14:44:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:44:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:44:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:44:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:44:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:44:04 --> Total execution time: 0.0390
DEBUG - 2021-04-16 14:44:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:44:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:44:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:44:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:44:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:44:06 --> Total execution time: 0.0370
DEBUG - 2021-04-16 14:44:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:44:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:44:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:44:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:44:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 122
DEBUG - 2021-04-16 14:44:41 --> Total execution time: 0.0409
DEBUG - 2021-04-16 14:45:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:45:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:45:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:45:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:45:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 14:45:40 --> Total execution time: 0.0371
DEBUG - 2021-04-16 14:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:46:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:46:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 14:46:34 --> Total execution time: 0.0442
DEBUG - 2021-04-16 14:46:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:46:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:46:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 14:46:40 --> Total execution time: 0.0436
DEBUG - 2021-04-16 14:46:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:46:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:46:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:46:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 14:46:44 --> Total execution time: 0.0583
DEBUG - 2021-04-16 14:46:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:44 --> 404 Page Not Found: Images/avatar
ERROR - 2021-04-16 14:46:44 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-16 14:46:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:46:44 --> UTF-8 Support Enabled
ERROR - 2021-04-16 14:46:44 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-16 14:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:44 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 14:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:44 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 14:46:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:46:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:44 --> 404 Page Not Found: Images/logo2.png
ERROR - 2021-04-16 14:46:44 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:45 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-16 14:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:45 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-16 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:45 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:45 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 14:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:45 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 14:46:45 --> UTF-8 Support Enabled
ERROR - 2021-04-16 14:46:45 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 14:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:45 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-16 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:45 --> 404 Page Not Found: Apple-iconpng/index
DEBUG - 2021-04-16 14:46:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:45 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-04-16 14:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:46:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:46:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 14:46:47 --> Total execution time: 0.0532
DEBUG - 2021-04-16 14:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:47 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-16 14:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 14:46:47 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-16 14:51:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:51:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:51:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:51:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:51:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 14:51:51 --> Total execution time: 0.0477
DEBUG - 2021-04-16 14:51:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:51:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:51:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:51:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:51:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 14:51:53 --> Total execution time: 0.0380
DEBUG - 2021-04-16 14:52:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:52:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:52:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:52:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:52:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 14:52:51 --> Total execution time: 0.0425
DEBUG - 2021-04-16 14:56:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:56:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:56:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 14:56:13 --> Total execution time: 0.0400
DEBUG - 2021-04-16 14:57:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:57:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:57:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 14:57:04 --> Total execution time: 0.0393
DEBUG - 2021-04-16 14:57:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:57:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:57:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:57:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:57:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 14:57:52 --> Total execution time: 0.0366
DEBUG - 2021-04-16 14:58:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:58:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:58:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:58:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:58:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 14:58:37 --> Total execution time: 0.0414
DEBUG - 2021-04-16 14:59:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:59:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:59:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 14:59:11 --> Total execution time: 0.0439
DEBUG - 2021-04-16 14:59:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 14:59:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 14:59:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 14:59:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 14:59:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 14:59:27 --> Total execution time: 0.0552
DEBUG - 2021-04-16 15:00:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:00:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:00:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:00:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:00:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 15:00:03 --> Total execution time: 0.0493
DEBUG - 2021-04-16 15:00:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:00:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:00:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:00:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:00:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 15:00:22 --> Total execution time: 0.0400
DEBUG - 2021-04-16 15:00:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:00:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:00:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:00:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 15:00:54 --> Total execution time: 0.0432
DEBUG - 2021-04-16 15:02:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:02:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:02:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 15:02:34 --> Total execution time: 0.0391
DEBUG - 2021-04-16 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:02:48 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:02:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:02:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:02:48 --> Total execution time: 0.0356
DEBUG - 2021-04-16 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:02:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:02:48 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:02:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:02:48 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:03:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:03:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:03:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:03:02 --> Total execution time: 0.0483
DEBUG - 2021-04-16 15:03:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:03:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:03:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:03:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:03:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:03:04 --> Total execution time: 0.0399
DEBUG - 2021-04-16 15:03:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:03:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:03:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:03:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:03:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:03:05 --> Total execution time: 0.0462
DEBUG - 2021-04-16 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:03:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:03:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:03:06 --> Total execution time: 0.0495
DEBUG - 2021-04-16 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:03:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:03:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:03:06 --> Total execution time: 0.0341
DEBUG - 2021-04-16 15:15:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:15:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:15:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:15:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:15:29 --> Total execution time: 0.0753
DEBUG - 2021-04-16 15:15:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:15:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:15:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:15:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:15:54 --> Total execution time: 11.9892
DEBUG - 2021-04-16 15:16:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:16:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:16:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:16:09 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:16:09 --> Total execution time: 0.0394
DEBUG - 2021-04-16 15:16:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:16:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:16:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:16:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:16:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:16:22 --> Total execution time: 0.0665
DEBUG - 2021-04-16 15:16:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:16:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:16:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:16:24 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:16:24 --> Total execution time: 0.0367
DEBUG - 2021-04-16 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:17:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:17:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:17:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:17:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:17:44 --> Total execution time: 0.0401
DEBUG - 2021-04-16 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:17:44 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:17:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:17:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:17:44 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:18:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:18:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:18:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:18:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:18:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:18:01 --> Total execution time: 0.0535
DEBUG - 2021-04-16 15:18:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:18:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:18:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:18:29 --> Total execution time: 0.0574
DEBUG - 2021-04-16 15:18:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:18:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:18:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:18:31 --> Total execution time: 0.0382
DEBUG - 2021-04-16 15:18:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:18:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:18:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:18:32 --> Total execution time: 0.0383
DEBUG - 2021-04-16 15:18:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:18:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:18:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:18:32 --> Total execution time: 0.0638
DEBUG - 2021-04-16 15:18:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:18:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:18:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:18:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:18:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:18:32 --> Total execution time: 0.0529
DEBUG - 2021-04-16 15:18:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:18:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:18:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:18:33 --> Total execution time: 0.0508
DEBUG - 2021-04-16 15:18:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:18:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:18:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:18:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:18:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:18:33 --> Total execution time: 0.0543
DEBUG - 2021-04-16 15:18:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:18:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:18:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:18:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:18:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:18:34 --> Total execution time: 0.0612
DEBUG - 2021-04-16 15:18:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:18:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:18:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:18:44 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:18:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:18:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:18:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:18:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:18:44 --> Total execution time: 0.0628
DEBUG - 2021-04-16 15:19:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:19:16 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:19:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:19:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:19:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:19:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:19:16 --> Total execution time: 0.0422
DEBUG - 2021-04-16 15:19:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:19:29 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:19:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:19:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:19:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:19:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:19:29 --> Total execution time: 0.0502
DEBUG - 2021-04-16 15:19:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:19:57 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:19:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:19:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:19:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:19:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:19:57 --> Total execution time: 0.0643
DEBUG - 2021-04-16 15:22:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:22:30 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:22:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:22:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:22:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:22:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 119
DEBUG - 2021-04-16 15:22:30 --> Total execution time: 0.0514
DEBUG - 2021-04-16 15:24:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:24:39 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:24:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:24:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:24:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:24:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:24:39 --> Total execution time: 0.0428
DEBUG - 2021-04-16 15:26:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:26:17 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:26:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:26:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:26:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:26:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:26:17 --> Total execution time: 0.0569
DEBUG - 2021-04-16 15:26:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:26:38 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:26:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:26:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:26:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:26:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:26:38 --> Total execution time: 0.0619
DEBUG - 2021-04-16 15:27:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:27:33 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:27:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:27:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:27:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:27:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:27:33 --> Total execution time: 0.0397
DEBUG - 2021-04-16 15:27:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:27:34 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:27:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:27:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:27:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:27:34 --> Total execution time: 0.0403
DEBUG - 2021-04-16 15:27:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:27:34 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:27:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:27:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:27:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:27:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:27:35 --> Total execution time: 0.0667
DEBUG - 2021-04-16 15:27:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:27:51 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:27:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:27:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:27:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:27:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:27:51 --> Total execution time: 0.0388
DEBUG - 2021-04-16 15:28:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:28:07 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:28:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:28:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:28:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:28:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:28:07 --> Total execution time: 0.0687
DEBUG - 2021-04-16 15:29:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:29:32 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:29:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:29:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:29:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:29:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:29:32 --> Total execution time: 0.0408
DEBUG - 2021-04-16 15:29:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:29:48 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:29:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:29:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:29:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:29:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:29:48 --> Total execution time: 0.0472
DEBUG - 2021-04-16 15:30:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:30:14 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:30:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:30:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:30:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:30:14 --> Total execution time: 0.0617
DEBUG - 2021-04-16 15:31:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:31:08 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:31:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:31:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:31:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:31:08 --> Total execution time: 0.0387
DEBUG - 2021-04-16 15:31:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:31:37 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:31:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:31:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:31:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:31:37 --> Total execution time: 0.0566
DEBUG - 2021-04-16 15:32:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:32:15 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:32:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:32:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:32:16 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:32:16 --> Total execution time: 0.0584
DEBUG - 2021-04-16 15:32:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:32:45 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:32:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:32:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:32:45 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:32:45 --> Total execution time: 0.0379
DEBUG - 2021-04-16 15:33:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:33:37 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:33:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:33:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:33:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:33:37 --> Total execution time: 0.0397
DEBUG - 2021-04-16 15:33:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:33:58 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:33:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:33:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:33:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:33:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:33:58 --> Total execution time: 0.0407
DEBUG - 2021-04-16 15:34:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:34:13 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:34:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:34:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:34:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:34:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:34:13 --> Total execution time: 0.0652
DEBUG - 2021-04-16 15:34:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:34:23 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:34:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:34:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:34:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:34:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:34:23 --> Total execution time: 0.0577
DEBUG - 2021-04-16 15:34:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:34:25 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:34:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:34:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:34:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:34:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:34:25 --> Total execution time: 0.0398
DEBUG - 2021-04-16 15:34:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:34:59 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:34:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:34:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:34:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:34:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:34:59 --> Total execution time: 0.0546
DEBUG - 2021-04-16 15:35:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:35:11 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:35:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:35:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:35:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:35:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:35:11 --> Total execution time: 0.0706
DEBUG - 2021-04-16 15:35:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:35:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:35:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:35:16 --> Total execution time: 0.0391
DEBUG - 2021-04-16 15:35:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:35:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:35:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:35:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:35:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:35:16 --> Total execution time: 0.0463
DEBUG - 2021-04-16 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:35:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:35:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:35:21 --> Total execution time: 0.0380
DEBUG - 2021-04-16 15:35:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:35:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:35:21 --> 404 Page Not Found: Welcome/images
DEBUG - 2021-04-16 15:35:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:35:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:35:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:35:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:35:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:35:23 --> Total execution time: 0.0389
DEBUG - 2021-04-16 15:35:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:35:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:35:23 --> 404 Page Not Found: Welcome/images
DEBUG - 2021-04-16 15:35:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:35:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:35:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:35:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:35:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:35:26 --> Total execution time: 0.0426
DEBUG - 2021-04-16 15:35:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:35:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:35:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:35:37 --> Total execution time: 0.0503
DEBUG - 2021-04-16 15:35:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:35:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:35:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:35:42 --> Total execution time: 0.0387
DEBUG - 2021-04-16 15:35:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:35:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:35:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:35:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:35:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:35:42 --> Total execution time: 0.0532
DEBUG - 2021-04-16 15:36:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:36:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:36:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:36:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:36:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:36:13 --> Total execution time: 0.0408
DEBUG - 2021-04-16 15:36:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:36:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:36:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:36:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:36:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:36:14 --> Total execution time: 0.0426
DEBUG - 2021-04-16 15:36:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:36:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:36:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:36:20 --> Total execution time: 0.0432
DEBUG - 2021-04-16 15:36:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:36:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:36:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:36:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:36:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:36:20 --> Total execution time: 0.0420
DEBUG - 2021-04-16 15:36:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:36:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:36:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:36:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:36:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:36:53 --> Total execution time: 0.0389
DEBUG - 2021-04-16 15:36:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:36:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:36:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:36:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:36:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:36:55 --> Total execution time: 0.0551
DEBUG - 2021-04-16 15:41:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:41:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:41:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:41:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:41:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:41:22 --> Total execution time: 0.0527
DEBUG - 2021-04-16 15:41:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:41:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:41:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:41:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:41:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:41:23 --> Total execution time: 0.0512
DEBUG - 2021-04-16 15:41:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:41:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:41:26 --> 404 Page Not Found: Welcome/page
DEBUG - 2021-04-16 15:41:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:41:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:41:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:41:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:41:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:41:57 --> Total execution time: 0.0495
DEBUG - 2021-04-16 15:41:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:41:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:41:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:41:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:41:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:41:58 --> Total execution time: 0.0404
DEBUG - 2021-04-16 15:41:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:41:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:41:59 --> 404 Page Not Found: Welcome/6
DEBUG - 2021-04-16 15:42:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:42:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:42:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:42:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:42:50 --> Total execution time: 0.0579
DEBUG - 2021-04-16 15:42:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:42:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:42:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:42:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:42:51 --> Total execution time: 0.0364
DEBUG - 2021-04-16 15:42:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:42:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:42:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:42:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:42:52 --> Total execution time: 0.0368
DEBUG - 2021-04-16 15:43:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:43:04 --> Total execution time: 0.0385
DEBUG - 2021-04-16 15:43:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:43:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:43:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:43:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:43:04 --> Total execution time: 0.0592
DEBUG - 2021-04-16 15:43:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:43:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:43:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:43:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:43:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:43:30 --> Total execution time: 0.0535
DEBUG - 2021-04-16 15:43:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:43:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:43:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:43:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:43:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:43:32 --> Total execution time: 0.0494
DEBUG - 2021-04-16 15:43:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:43:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:43:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:43:41 --> Total execution time: 0.0398
DEBUG - 2021-04-16 15:43:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:43:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:43:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:43:46 --> Total execution time: 0.0389
DEBUG - 2021-04-16 15:43:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:43:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:43:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:43:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:43:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:43:49 --> Total execution time: 0.0559
DEBUG - 2021-04-16 15:43:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:43:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:43:54 --> 404 Page Not Found: Homehtml/page
DEBUG - 2021-04-16 15:44:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:44:09 --> No URI present. Default controller set.
DEBUG - 2021-04-16 15:44:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:44:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:44:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:44:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:44:09 --> Total execution time: 0.0390
DEBUG - 2021-04-16 15:44:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:44:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:44:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:44:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:44:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:44:11 --> Total execution time: 0.0570
DEBUG - 2021-04-16 15:44:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:44:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:44:14 --> 404 Page Not Found: Homehtml/page
DEBUG - 2021-04-16 15:44:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:44:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:44:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:44:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:44:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:44:25 --> Total execution time: 0.0503
DEBUG - 2021-04-16 15:46:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:46:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:46:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:46:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:46:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:46:28 --> Total execution time: 0.0419
DEBUG - 2021-04-16 15:46:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:46:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:46:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:46:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:46:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:46:29 --> Total execution time: 0.0430
DEBUG - 2021-04-16 15:46:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:46:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:46:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:46:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:46:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:46:32 --> Total execution time: 0.0604
DEBUG - 2021-04-16 15:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:46:34 --> 404 Page Not Found: Homehtml/page
DEBUG - 2021-04-16 15:46:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:46:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:46:53 --> 404 Page Not Found: Homehtml/page
DEBUG - 2021-04-16 15:46:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:46:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:46:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:46:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:46:53 --> Total execution time: 0.0648
DEBUG - 2021-04-16 15:47:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:47:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:47:26 --> 404 Page Not Found: Homehtml/page
DEBUG - 2021-04-16 15:47:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:47:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:47:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:47:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:47:30 --> Total execution time: 0.0655
DEBUG - 2021-04-16 15:47:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:47:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:47:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:47:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:47:52 --> Total execution time: 0.0365
DEBUG - 2021-04-16 15:47:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:47:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:47:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:47:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:47:53 --> Total execution time: 0.0365
DEBUG - 2021-04-16 15:47:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:47:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:47:57 --> 404 Page Not Found: Homehtml/page
DEBUG - 2021-04-16 15:48:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:48:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:48:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:48:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:48:03 --> Total execution time: 0.0367
DEBUG - 2021-04-16 15:48:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:48:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:48:06 --> 404 Page Not Found: Homehtml/page
DEBUG - 2021-04-16 15:48:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:48:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:48:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:48:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:48:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:48:20 --> Total execution time: 0.0546
DEBUG - 2021-04-16 15:48:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:48:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:48:30 --> 404 Page Not Found: Homehtml/page
DEBUG - 2021-04-16 15:48:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:48:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:48:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:48:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:48:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:48:31 --> Total execution time: 0.0382
DEBUG - 2021-04-16 15:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:48:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:48:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:48:52 --> Total execution time: 0.0395
DEBUG - 2021-04-16 15:48:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:48:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:48:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:48:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:48:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:48:53 --> Total execution time: 0.0569
DEBUG - 2021-04-16 15:48:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:48:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:48:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:48:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:48:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:48:54 --> Total execution time: 0.0487
DEBUG - 2021-04-16 15:48:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:48:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:48:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:48:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:48:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:48:57 --> Total execution time: 0.0490
DEBUG - 2021-04-16 15:48:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:48:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:48:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:48:58 --> Total execution time: 0.0378
DEBUG - 2021-04-16 15:49:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:49:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:49:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:49:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:49:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:49:00 --> Total execution time: 0.0410
DEBUG - 2021-04-16 15:49:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:49:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:49:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:49:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:49:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:49:02 --> Total execution time: 0.0554
DEBUG - 2021-04-16 15:49:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:49:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:49:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:49:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:49:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:49:40 --> Total execution time: 0.0405
DEBUG - 2021-04-16 15:49:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:49:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:49:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:49:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:49:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:49:44 --> Total execution time: 0.0543
DEBUG - 2021-04-16 15:49:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:49:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:49:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:49:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:49:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:49:46 --> Total execution time: 0.0645
DEBUG - 2021-04-16 15:49:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:49:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:49:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:49:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:49:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:49:54 --> Total execution time: 0.0398
DEBUG - 2021-04-16 15:50:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:50:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:50:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:50:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:50:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:50:01 --> Total execution time: 0.0538
DEBUG - 2021-04-16 15:50:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:50:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:50:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:50:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:50:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:50:03 --> Total execution time: 0.0418
DEBUG - 2021-04-16 15:50:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:50:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:50:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:50:28 --> Total execution time: 0.0393
DEBUG - 2021-04-16 15:50:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:50:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:50:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:50:48 --> Total execution time: 0.0575
DEBUG - 2021-04-16 15:51:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:51:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:51:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:51:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:51:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:51:19 --> Total execution time: 0.0547
DEBUG - 2021-04-16 15:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:51:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:51:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:51:29 --> Total execution time: 0.0701
DEBUG - 2021-04-16 15:52:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:52:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:52:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:52:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:52:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:52:00 --> Total execution time: 0.0517
DEBUG - 2021-04-16 15:52:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:52:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:52:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:52:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:52:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:52:02 --> Total execution time: 0.0664
DEBUG - 2021-04-16 15:52:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:52:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:52:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:52:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:52:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:52:24 --> Total execution time: 0.0385
DEBUG - 2021-04-16 15:52:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:52:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:52:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:52:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:52:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:52:26 --> Total execution time: 0.0376
DEBUG - 2021-04-16 15:52:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:52:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:52:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:52:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:52:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:52:28 --> Total execution time: 0.0475
DEBUG - 2021-04-16 15:52:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:52:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:52:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:52:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:52:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:52:31 --> Total execution time: 0.0373
DEBUG - 2021-04-16 15:52:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:52:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:52:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:52:39 --> Total execution time: 0.0632
DEBUG - 2021-04-16 15:53:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:53:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:53:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:53:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:53:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:53:34 --> Total execution time: 0.0515
DEBUG - 2021-04-16 15:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:53:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:53:35 --> Severity: error --> Exception: Too few arguments to function Welcome::readmore(), 0 passed in D:\__myproject.my\SIG-trayek\system\core\CodeIgniter.php on line 532 and exactly 1 expected D:\__myproject.my\SIG-trayek\application\controllers\Welcome.php 71
DEBUG - 2021-04-16 15:54:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:54:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:54:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:54:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:54:11 --> Total execution time: 0.0378
DEBUG - 2021-04-16 15:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:54:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 15:54:19 --> Total execution time: 0.0428
DEBUG - 2021-04-16 15:55:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:55:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:55:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:55:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:55:58 --> Severity: error --> Exception: Call to a member function viewData() on null D:\__myproject.my\SIG-trayek\application\controllers\Welcome.php 73
DEBUG - 2021-04-16 15:55:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:55:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:55:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:55:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:55:59 --> Severity: error --> Exception: Call to a member function viewData() on null D:\__myproject.my\SIG-trayek\application\controllers\Welcome.php 73
DEBUG - 2021-04-16 15:56:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:56:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:56:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:56:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:56:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:56:50 --> Total execution time: 0.0767
DEBUG - 2021-04-16 15:57:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:57:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:57:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:57:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:57:10 --> Total execution time: 0.0558
DEBUG - 2021-04-16 15:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:26 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:26 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:27 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:27 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:27 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-16 15:57:27 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:27 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:27 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:31 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:31 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:32 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:32 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:33 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:33 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:57:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:35 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-16 15:57:35 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:36 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:36 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:48 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-16 15:57:48 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:49 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:49 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:57:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 15:57:50 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 15:58:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:58:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:58:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:58:06 --> Total execution time: 0.0515
DEBUG - 2021-04-16 15:58:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:58:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:58:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:58:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:58:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:58:26 --> Total execution time: 0.0410
DEBUG - 2021-04-16 15:58:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:58:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:58:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:58:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:58:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:58:55 --> Total execution time: 0.0410
DEBUG - 2021-04-16 15:59:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 15:59:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 15:59:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 15:59:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 15:59:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 15:59:24 --> Total execution time: 0.0416
DEBUG - 2021-04-16 16:00:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:00:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:00:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:00:19 --> Total execution time: 0.0427
DEBUG - 2021-04-16 16:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:00:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:00:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:00:26 --> Total execution time: 0.0429
DEBUG - 2021-04-16 16:00:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:00:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:00:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:00:39 --> Total execution time: 0.0417
DEBUG - 2021-04-16 16:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:00:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:00:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:00:42 --> Total execution time: 0.0554
DEBUG - 2021-04-16 16:00:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:00:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 16:00:48 --> Total execution time: 0.0460
DEBUG - 2021-04-16 16:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:00:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:00:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:00:51 --> Total execution time: 0.0630
DEBUG - 2021-04-16 16:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:51 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 16:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:51 --> 404 Page Not Found: Images/logo2.png
ERROR - 2021-04-16 16:00:51 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-16 16:00:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:51 --> 404 Page Not Found: Images/avatar
ERROR - 2021-04-16 16:00:51 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 16:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:51 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-16 16:00:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:51 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 16:00:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:52 --> 404 Page Not Found: Images/admin.jpg
ERROR - 2021-04-16 16:00:52 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-16 16:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:52 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 16:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:52 --> 404 Page Not Found: Images/avatar
ERROR - 2021-04-16 16:00:52 --> 404 Page Not Found: Images/avatar
ERROR - 2021-04-16 16:00:52 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 16:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:52 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-16 16:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:52 --> 404 Page Not Found: Apple-iconpng/index
DEBUG - 2021-04-16 16:00:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:52 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-04-16 16:00:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:00:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:00:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:00:53 --> Total execution time: 0.0504
DEBUG - 2021-04-16 16:00:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:00:54 --> 404 Page Not Found: Admin/apple-icon.png
ERROR - 2021-04-16 16:00:54 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-16 16:00:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:00:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:00:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:00:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:00:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:00:58 --> Total execution time: 0.0508
DEBUG - 2021-04-16 16:07:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:07:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:07:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:07:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:07:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:07:10 --> Total execution time: 0.0555
DEBUG - 2021-04-16 16:07:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:07:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:07:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:07:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:07:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:07:58 --> Total execution time: 0.0382
DEBUG - 2021-04-16 16:08:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:08:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:08:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:08:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:08:43 --> Severity: error --> Exception: syntax error, unexpected '$no' (T_VARIABLE), expecting '(' D:\__myproject.my\SIG-trayek\application\views\backend\bus\data.php 21
DEBUG - 2021-04-16 16:09:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:09:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:09:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:09:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 16:09:10 --> Total execution time: 0.0484
DEBUG - 2021-04-16 16:09:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:09:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:09:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:09:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:09:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:09:13 --> Total execution time: 0.0512
DEBUG - 2021-04-16 16:09:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:09:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:09:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:09:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:09:21 --> Severity: error --> Exception: syntax error, unexpected '$no' (T_VARIABLE), expecting '(' D:\__myproject.my\SIG-trayek\application\views\backend\bus\data.php 21
DEBUG - 2021-04-16 16:10:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:10:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:10:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:10:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:10:36 --> Total execution time: 0.0382
DEBUG - 2021-04-16 16:10:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:10:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:10:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:10:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:10:57 --> Severity: error --> Exception: syntax error, unexpected '<' D:\__myproject.my\SIG-trayek\application\views\backend\bus\data.php 24
DEBUG - 2021-04-16 16:11:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:11:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:11:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:11:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:11:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:11:09 --> Total execution time: 0.0401
DEBUG - 2021-04-16 16:11:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:11:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:11:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:11:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:11:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:11:31 --> Total execution time: 0.0370
DEBUG - 2021-04-16 16:12:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:12:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:12:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:12:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:12:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:12:06 --> Total execution time: 0.0366
DEBUG - 2021-04-16 16:13:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:13:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:13:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:13:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:13:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:13:25 --> Total execution time: 0.0409
DEBUG - 2021-04-16 16:13:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:13:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:13:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:13:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:13:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:13:56 --> Total execution time: 0.0598
DEBUG - 2021-04-16 16:14:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:14:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:14:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:14:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:14:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:14:01 --> Total execution time: 0.0664
DEBUG - 2021-04-16 16:14:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:14:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:14:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:14:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:14:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:14:12 --> Total execution time: 0.0737
DEBUG - 2021-04-16 16:14:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:14:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:14:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:14:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:14:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:14:35 --> Total execution time: 0.0390
DEBUG - 2021-04-16 16:14:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:14:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:14:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:14:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:14:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:14:49 --> Total execution time: 0.0386
DEBUG - 2021-04-16 16:14:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:14:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:14:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:14:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:14:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:14:58 --> Total execution time: 0.0399
DEBUG - 2021-04-16 16:15:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:15:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:15:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:15:05 --> Total execution time: 0.0384
DEBUG - 2021-04-16 16:15:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:15:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:15:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:15:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:15:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:15:06 --> Total execution time: 0.0819
DEBUG - 2021-04-16 16:15:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:15:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:15:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:15:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:15:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:15:10 --> Total execution time: 0.0531
DEBUG - 2021-04-16 16:15:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:15:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:15:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:15:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:15:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:15:11 --> Total execution time: 0.0351
DEBUG - 2021-04-16 16:15:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:15:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:15:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:15:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:15:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:15:13 --> Total execution time: 0.0534
DEBUG - 2021-04-16 16:15:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:15:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:15:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:15:14 --> Total execution time: 0.0500
DEBUG - 2021-04-16 16:15:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:15:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:15:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:15:18 --> Total execution time: 0.0607
DEBUG - 2021-04-16 16:18:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:18:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:18:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:18:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:18:12 --> Severity: error --> Exception: Call to undefined method Berita_model::get_bus_list() D:\__myproject.my\SIG-trayek\application\controllers\Welcome.php 87
DEBUG - 2021-04-16 16:18:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:18:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:18:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:18:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 16:18:39 --> Total execution time: 0.0407
DEBUG - 2021-04-16 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:19:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:19:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:19:22 --> Total execution time: 0.0687
DEBUG - 2021-04-16 16:19:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:19:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:19:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:19:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:19:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:19:53 --> Total execution time: 0.0435
DEBUG - 2021-04-16 16:21:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:21:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:21:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:21:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:21:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:21:04 --> Total execution time: 0.0464
DEBUG - 2021-04-16 16:21:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:21:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:21:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:21:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:21:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:21:19 --> Total execution time: 0.0415
DEBUG - 2021-04-16 16:21:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:21:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:21:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:21:59 --> Total execution time: 0.0402
DEBUG - 2021-04-16 16:22:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:22:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:22:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:22:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:22:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:22:18 --> Total execution time: 0.0508
DEBUG - 2021-04-16 16:23:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:23:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:23:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:23:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:23:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:23:08 --> Total execution time: 0.0538
DEBUG - 2021-04-16 16:23:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:23:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:23:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:23:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:23:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:23:27 --> Total execution time: 0.0396
DEBUG - 2021-04-16 16:23:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:23:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:23:29 --> 404 Page Not Found: Welcom/bus
DEBUG - 2021-04-16 16:23:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:23:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:23:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:23:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:23:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:23:48 --> Total execution time: 0.0416
DEBUG - 2021-04-16 16:23:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:23:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:23:49 --> 404 Page Not Found: Welcom/bus
DEBUG - 2021-04-16 16:24:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:24:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:24:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:24:04 --> Total execution time: 0.0461
DEBUG - 2021-04-16 16:24:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:24:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:24:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:24:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:24:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:24:05 --> Total execution time: 0.0413
DEBUG - 2021-04-16 16:24:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:24:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:24:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:24:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:24:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:24:06 --> Total execution time: 0.0632
DEBUG - 2021-04-16 16:24:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:24:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:24:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:24:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:24:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:24:09 --> Total execution time: 0.0575
DEBUG - 2021-04-16 16:24:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:24:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:24:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:24:24 --> Total execution time: 0.0571
DEBUG - 2021-04-16 16:24:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:24:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:24:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:24:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:24:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:24:41 --> Total execution time: 0.0581
DEBUG - 2021-04-16 16:24:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:24:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:24:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:24:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:24:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 16:24:54 --> Total execution time: 0.0742
DEBUG - 2021-04-16 16:26:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:26:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:26:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:26:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:26:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:26:41 --> Total execution time: 0.0567
DEBUG - 2021-04-16 16:26:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:26:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:26:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:26:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:26:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:26:48 --> Total execution time: 0.0508
DEBUG - 2021-04-16 16:27:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:27:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:27:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:27:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:27:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:27:05 --> Total execution time: 0.0586
DEBUG - 2021-04-16 16:27:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:27:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:27:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:27:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:27:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:27:27 --> Total execution time: 0.0433
DEBUG - 2021-04-16 16:28:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:28:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:28:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:28:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:28:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:28:20 --> Total execution time: 0.0573
DEBUG - 2021-04-16 16:28:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:28:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:28:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:28:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:28:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:28:29 --> Total execution time: 0.0406
DEBUG - 2021-04-16 16:28:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:28:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:28:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:28:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:28:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:28:41 --> Total execution time: 0.0640
DEBUG - 2021-04-16 16:33:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:33:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:33:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:33:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 16:33:05 --> Total execution time: 0.0429
DEBUG - 2021-04-16 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:34:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:34:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:34:10 --> Total execution time: 0.0541
DEBUG - 2021-04-16 16:35:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:35:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:35:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:35:36 --> Total execution time: 0.0532
DEBUG - 2021-04-16 16:35:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:35:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:35:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:35:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:35:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:35:55 --> Total execution time: 0.0514
DEBUG - 2021-04-16 16:36:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:36:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:36:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:36:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:36:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:36:58 --> Total execution time: 0.0567
DEBUG - 2021-04-16 16:36:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:36:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:36:58 --> 404 Page Not Found: Images/halte
DEBUG - 2021-04-16 16:38:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:38:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:38:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:38:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:38:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:38:46 --> Total execution time: 0.0703
DEBUG - 2021-04-16 16:38:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:38:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:38:46 --> 404 Page Not Found: Images/halte
DEBUG - 2021-04-16 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:42:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:42:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:42:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:42:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:42:35 --> Total execution time: 0.0661
DEBUG - 2021-04-16 16:42:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:42:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:42:35 --> 404 Page Not Found: Images/halte
DEBUG - 2021-04-16 16:42:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:42:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:42:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:42:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:42:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:42:38 --> Total execution time: 0.1308
DEBUG - 2021-04-16 16:42:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:42:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:42:38 --> 404 Page Not Found: Haltehtml/page
DEBUG - 2021-04-16 16:42:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:42:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:42:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:42:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:42:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:42:40 --> Total execution time: 0.0561
DEBUG - 2021-04-16 16:42:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:42:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:42:40 --> 404 Page Not Found: Haltehtml/page
DEBUG - 2021-04-16 16:42:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:42:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:42:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:42:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:42:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:42:48 --> Total execution time: 0.0587
DEBUG - 2021-04-16 16:42:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:42:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:42:48 --> 404 Page Not Found: Haltehtml/page
DEBUG - 2021-04-16 16:43:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:43:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:43:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:43:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:43:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:43:12 --> Total execution time: 0.0384
DEBUG - 2021-04-16 16:43:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:43:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:43:12 --> 404 Page Not Found: Haltehtml/images
DEBUG - 2021-04-16 16:43:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:43:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:43:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:43:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:43:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:43:16 --> Total execution time: 0.0640
DEBUG - 2021-04-16 16:43:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:43:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:43:16 --> 404 Page Not Found: Haltehtml/page
DEBUG - 2021-04-16 16:43:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:43:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:43:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:43:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:43:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:43:25 --> Total execution time: 0.0435
DEBUG - 2021-04-16 16:43:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:43:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:43:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:43:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:43:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:43:41 --> Total execution time: 0.0460
DEBUG - 2021-04-16 16:43:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:43:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:43:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:43:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:43:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:43:44 --> Total execution time: 0.0398
DEBUG - 2021-04-16 16:43:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:43:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:43:44 --> 404 Page Not Found: Images/halte
DEBUG - 2021-04-16 16:43:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:43:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:43:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:43:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:43:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:43:46 --> Total execution time: 0.0644
DEBUG - 2021-04-16 16:43:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:43:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 16:43:46 --> 404 Page Not Found: Images/halte
DEBUG - 2021-04-16 16:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:47:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:47:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:47:22 --> Total execution time: 0.0462
DEBUG - 2021-04-16 16:47:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:47:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:47:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:47:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:47:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:47:24 --> Total execution time: 0.0387
DEBUG - 2021-04-16 16:47:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:47:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:47:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:47:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:47:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:47:26 --> Total execution time: 0.0407
DEBUG - 2021-04-16 16:48:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:48:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:48:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:48:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:48:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:48:07 --> Total execution time: 0.0401
DEBUG - 2021-04-16 16:48:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:48:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:48:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:48:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:48:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:48:27 --> Total execution time: 0.0687
DEBUG - 2021-04-16 16:48:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:48:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:48:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:48:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:48:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:48:28 --> Total execution time: 0.0653
DEBUG - 2021-04-16 16:48:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:48:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:48:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:48:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:48:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:48:30 --> Total execution time: 0.0405
DEBUG - 2021-04-16 16:49:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:49:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:49:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:49:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:49:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:49:25 --> Total execution time: 0.0639
DEBUG - 2021-04-16 16:50:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:50:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:50:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:50:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:50:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:50:28 --> Total execution time: 0.0408
DEBUG - 2021-04-16 16:51:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:51:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:51:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:51:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:51:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:51:20 --> Total execution time: 0.0603
DEBUG - 2021-04-16 16:51:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:51:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:51:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:51:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:51:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:51:39 --> Total execution time: 0.0539
DEBUG - 2021-04-16 16:58:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:58:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:58:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:58:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:58:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:58:06 --> Total execution time: 0.0445
DEBUG - 2021-04-16 16:58:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 16:58:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 16:58:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 16:58:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 16:58:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 16:58:40 --> Total execution time: 0.0401
DEBUG - 2021-04-16 17:00:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:00:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:00:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:00:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:00:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:00:26 --> Total execution time: 0.0643
DEBUG - 2021-04-16 17:04:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:04:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:04:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:04:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:04:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:04:25 --> Total execution time: 0.0568
DEBUG - 2021-04-16 17:04:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:04:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:04:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:04:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:04:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:04:27 --> Total execution time: 0.0559
DEBUG - 2021-04-16 17:04:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:04:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:04:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:04:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:04:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:04:39 --> Total execution time: 0.0412
DEBUG - 2021-04-16 17:05:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:05:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:05:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:05:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:05:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:05:24 --> Total execution time: 0.0589
DEBUG - 2021-04-16 17:05:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:05:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:05:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:05:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:05:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:05:31 --> Total execution time: 0.0540
DEBUG - 2021-04-16 17:05:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:05:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:05:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:05:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:05:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:05:54 --> Total execution time: 0.0403
DEBUG - 2021-04-16 17:08:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:08:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:08:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:08:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:08:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:08:09 --> Total execution time: 0.0672
DEBUG - 2021-04-16 17:08:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:08:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:08:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:08:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:08:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:08:25 --> Total execution time: 0.0603
DEBUG - 2021-04-16 17:08:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:08:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:08:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:08:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:08:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:08:32 --> Total execution time: 0.0453
DEBUG - 2021-04-16 17:09:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:09:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:09:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:09:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:09:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:09:14 --> Total execution time: 0.0396
DEBUG - 2021-04-16 17:09:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:09:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:09:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:09:51 --> Total execution time: 0.0396
DEBUG - 2021-04-16 17:09:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:09:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:09:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:09:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:09:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:09:53 --> Total execution time: 0.0413
DEBUG - 2021-04-16 17:10:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:10:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:10:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:10:20 --> Total execution time: 0.0488
DEBUG - 2021-04-16 17:11:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:11:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:11:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:11:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:11:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:11:13 --> Total execution time: 0.0412
DEBUG - 2021-04-16 17:11:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:11:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:11:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:11:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:11:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:11:29 --> Total execution time: 0.0423
DEBUG - 2021-04-16 17:11:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:11:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:11:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:11:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:11:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:11:38 --> Total execution time: 0.0416
DEBUG - 2021-04-16 17:11:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:11:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:11:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:11:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:11:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:11:54 --> Total execution time: 0.0657
DEBUG - 2021-04-16 17:12:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:12:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:12:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:12:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:12:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:12:13 --> Total execution time: 0.0440
DEBUG - 2021-04-16 17:12:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:12:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:12:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:12:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:12:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:12:20 --> Total execution time: 0.0559
DEBUG - 2021-04-16 17:12:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:12:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:12:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:12:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:12:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:12:24 --> Total execution time: 0.0704
DEBUG - 2021-04-16 17:15:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:15:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:15:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:15:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:15:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:15:14 --> Total execution time: 0.0454
DEBUG - 2021-04-16 17:15:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:15:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:15:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:15:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:15:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:15:23 --> Total execution time: 0.0421
DEBUG - 2021-04-16 17:18:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:18:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:18:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:18:18 --> Total execution time: 0.0631
DEBUG - 2021-04-16 17:19:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:19:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:19:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:19:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:19:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:19:47 --> Total execution time: 0.0443
DEBUG - 2021-04-16 17:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:19:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:19:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:19:58 --> Total execution time: 0.0561
DEBUG - 2021-04-16 17:20:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:20:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:20:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:20:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:20:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:20:22 --> Total execution time: 0.0418
DEBUG - 2021-04-16 17:20:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:20:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:20:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:20:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:20:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:20:29 --> Total execution time: 0.0622
DEBUG - 2021-04-16 17:21:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:21:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:21:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:21:16 --> Total execution time: 0.0399
DEBUG - 2021-04-16 17:21:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:21:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:21:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:21:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:21:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:21:50 --> Total execution time: 0.0472
DEBUG - 2021-04-16 17:22:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:22:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:22:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:22:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:22:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:22:09 --> Total execution time: 0.0640
DEBUG - 2021-04-16 17:22:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:22:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:22:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:22:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:22:15 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:22:15 --> Total execution time: 0.0393
DEBUG - 2021-04-16 17:22:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:22:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:22:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:22:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:22:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:22:33 --> Total execution time: 0.0403
DEBUG - 2021-04-16 17:22:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:22:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:22:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:22:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:22:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:22:46 --> Total execution time: 0.0630
DEBUG - 2021-04-16 17:23:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:23:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:23:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:23:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:23:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:23:00 --> Total execution time: 0.0430
DEBUG - 2021-04-16 17:23:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:23:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:23:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:23:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:23:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:23:02 --> Total execution time: 0.0398
DEBUG - 2021-04-16 17:23:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:23:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:23:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:23:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:23:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:23:06 --> Total execution time: 0.0564
DEBUG - 2021-04-16 17:23:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:23:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:23:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:23:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:23:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:23:10 --> Total execution time: 0.0522
DEBUG - 2021-04-16 17:23:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:23:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:23:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:23:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:23:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:23:32 --> Total execution time: 0.0407
DEBUG - 2021-04-16 17:23:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:23:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:23:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:23:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:23:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:23:39 --> Total execution time: 0.0398
DEBUG - 2021-04-16 17:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:23:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:23:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:23:46 --> Total execution time: 0.0389
DEBUG - 2021-04-16 17:23:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:23:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:23:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:23:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:23:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:23:51 --> Total execution time: 0.0510
DEBUG - 2021-04-16 17:23:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:23:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:23:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:23:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:23:56 --> Total execution time: 0.0417
DEBUG - 2021-04-16 17:24:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:24:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:24:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:24:00 --> Total execution time: 0.0598
DEBUG - 2021-04-16 17:24:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:24:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:24:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:24:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:24:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:24:14 --> Total execution time: 0.0578
DEBUG - 2021-04-16 17:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:24:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:24:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:24:18 --> Total execution time: 0.0434
DEBUG - 2021-04-16 17:24:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:24:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:24:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:24:19 --> Total execution time: 0.0620
DEBUG - 2021-04-16 17:24:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:24:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:24:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:24:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:24:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:24:21 --> Total execution time: 0.0561
DEBUG - 2021-04-16 17:24:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:24:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:24:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:24:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:24:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:24:28 --> Total execution time: 0.0429
DEBUG - 2021-04-16 17:24:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:24:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:24:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:24:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:24:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:24:32 --> Total execution time: 0.0597
DEBUG - 2021-04-16 17:24:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:24:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:24:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:24:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:24:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:24:36 --> Total execution time: 0.0618
DEBUG - 2021-04-16 17:25:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:25:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:25:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:25:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:25:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:25:01 --> Total execution time: 0.0387
DEBUG - 2021-04-16 17:25:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:25:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:25:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:25:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:25:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:25:18 --> Total execution time: 0.0504
DEBUG - 2021-04-16 17:25:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:25:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:25:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:25:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:25:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:25:24 --> Total execution time: 0.0432
DEBUG - 2021-04-16 17:25:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:25:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:25:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:25:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:25:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:25:55 --> Total execution time: 0.0398
DEBUG - 2021-04-16 17:26:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:26:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:26:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:26:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:26:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:26:10 --> Total execution time: 0.0389
DEBUG - 2021-04-16 17:26:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:26:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:26:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:26:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:26:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:26:28 --> Total execution time: 0.0432
DEBUG - 2021-04-16 17:26:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:26:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:26:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:26:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:26:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:26:34 --> Total execution time: 0.0376
DEBUG - 2021-04-16 17:28:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:28:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:28:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:28:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:28:24 --> Total execution time: 0.0513
DEBUG - 2021-04-16 17:30:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:30:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:30:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:30:10 --> Total execution time: 0.0507
DEBUG - 2021-04-16 17:31:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:31:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:31:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:31:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:31:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:31:01 --> Total execution time: 0.0391
DEBUG - 2021-04-16 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:31:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:31:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:31:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:31:02 --> Total execution time: 0.0575
DEBUG - 2021-04-16 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:31:02 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:31:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:31:02 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:31:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:31:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:31:02 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:31:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:31:02 --> 404 Page Not Found: Crud/apple-icon.png
DEBUG - 2021-04-16 17:31:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:31:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:31:02 --> 404 Page Not Found: Crud/favicon.ico
DEBUG - 2021-04-16 17:32:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:32:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:32:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:32:31 --> Total execution time: 0.0530
DEBUG - 2021-04-16 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:32:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:32:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:32:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:32:32 --> Total execution time: 0.0755
DEBUG - 2021-04-16 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:32:32 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:32:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:32:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:32:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:32:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:32:32 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:32:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:32:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:32:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:32:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:32:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:32:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:33:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:33:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:33:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:33:03 --> Total execution time: 0.0440
DEBUG - 2021-04-16 17:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:33:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:33:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:33:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:33:04 --> Total execution time: 0.0371
DEBUG - 2021-04-16 17:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:33:04 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:33:04 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:33:04 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:33:04 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:33:04 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:33:04 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:33:04 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:33:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:33:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:33:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:33:12 --> Total execution time: 0.0372
DEBUG - 2021-04-16 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:33:12 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:33:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:33:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:33:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:33:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:33:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:33:12 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:33:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:33:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:33:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:33:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:44:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:44:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:44:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:44:23 --> Total execution time: 0.0389
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:44:23 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:44:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:44:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:45:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:45:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:45:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:45:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:45:53 --> Total execution time: 0.0628
DEBUG - 2021-04-16 17:45:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:45:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:45:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:45:54 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:45:54 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:45:54 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:45:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:45:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:45:54 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:45:54 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:45:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:45:54 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:46:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:46:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:46:18 --> Total execution time: 0.0578
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:46:18 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:46:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:46:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:46:20 --> Total execution time: 0.0591
DEBUG - 2021-04-16 17:46:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:46:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:46:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:46:37 --> Total execution time: 0.0492
DEBUG - 2021-04-16 17:46:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:37 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:46:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:37 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:46:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:46:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:46:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:46:37 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:46:37 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:46:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:47:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:47:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:47:20 --> Total execution time: 0.0601
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:47:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:47:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:47:21 --> Total execution time: 0.0507
DEBUG - 2021-04-16 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:21 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:47:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:21 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:47:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:47:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:47:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:47:22 --> Total execution time: 0.0361
DEBUG - 2021-04-16 17:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:22 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:47:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:47:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:23 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:47:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:47:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:47:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:48:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:48:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:48:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:48:12 --> Total execution time: 0.0637
DEBUG - 2021-04-16 17:48:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:48:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:48:14 --> Total execution time: 0.0345
DEBUG - 2021-04-16 17:48:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:14 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 17:48:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:14 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:14 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:48:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:14 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:48:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:48:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:48:36 --> Total execution time: 0.0516
DEBUG - 2021-04-16 17:48:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:36 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-16 17:48:36 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:48:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:36 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:48:51 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:48:51 --> Total execution time: 0.0401
DEBUG - 2021-04-16 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:51 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 17:48:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:51 --> 404 Page Not Found: Assets/js
ERROR - 2021-04-16 17:48:51 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:48:52 --> Total execution time: 0.0343
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:52 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-16 17:48:52 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:52 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:48:52 --> Total execution time: 0.0450
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:52 --> 404 Page Not Found: Assets/js
ERROR - 2021-04-16 17:48:52 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:52 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:48:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:48:52 --> Total execution time: 0.0340
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:52 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:48:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:48:52 --> 404 Page Not Found: Assets/js
ERROR - 2021-04-16 17:48:52 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:49:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:49:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:49:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:49:01 --> Total execution time: 0.0566
DEBUG - 2021-04-16 17:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:49:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:49:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:49:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:49:04 --> Total execution time: 0.0436
DEBUG - 2021-04-16 17:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:04 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-16 17:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:04 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-16 17:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:04 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:04 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:04 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:04 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:49:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:04 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-16 17:49:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:05 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-16 17:49:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:49:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:05 --> 404 Page Not Found: Images/avatar
ERROR - 2021-04-16 17:49:05 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-16 17:49:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-04-16 17:49:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:05 --> 404 Page Not Found: Apple-iconpng/index
DEBUG - 2021-04-16 17:49:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:49:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:49:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:49:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:49:06 --> Total execution time: 0.0363
DEBUG - 2021-04-16 17:49:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:49:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:06 --> 404 Page Not Found: Admin/apple-icon.png
ERROR - 2021-04-16 17:49:06 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-16 17:49:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:49:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:49:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:49:07 --> Total execution time: 0.0358
DEBUG - 2021-04-16 17:49:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:07 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 17:49:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:49:07 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:49:07 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:49:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:07 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:49:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:49:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:49:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:49:08 --> Total execution time: 0.0677
DEBUG - 2021-04-16 17:49:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:49:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:49:10 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:50:12 --> Total execution time: 0.0584
DEBUG - 2021-04-16 17:50:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:12 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-16 17:50:12 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:12 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:50:15 --> Total execution time: 0.0506
DEBUG - 2021-04-16 17:50:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:18 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 17:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:50:36 --> Total execution time: 0.0539
DEBUG - 2021-04-16 17:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:36 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:36 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:36 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:36 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:50:37 --> Total execution time: 0.0394
DEBUG - 2021-04-16 17:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:37 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:37 --> 404 Page Not Found: Crud/vendors
ERROR - 2021-04-16 17:50:37 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:37 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:50:38 --> Total execution time: 0.0475
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Assets/js
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:50:38 --> Total execution time: 0.0359
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Crud/vendors
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:50:38 --> Total execution time: 0.0343
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Crud/vendors
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:38 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:50:48 --> Total execution time: 0.0480
DEBUG - 2021-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:49 --> 404 Page Not Found: Crud/vendors
ERROR - 2021-04-16 17:50:49 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:49 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:49 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:50:49 --> Total execution time: 0.0615
DEBUG - 2021-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:49 --> 404 Page Not Found: Assets/js
ERROR - 2021-04-16 17:50:49 --> 404 Page Not Found: Crud/vendors
ERROR - 2021-04-16 17:50:49 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:49 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:50:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:50:49 --> Total execution time: 0.0471
DEBUG - 2021-04-16 17:50:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:50:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:50:51 --> Total execution time: 0.0629
DEBUG - 2021-04-16 17:50:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:50:52 --> Total execution time: 0.0456
DEBUG - 2021-04-16 17:50:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:52 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:52 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:50:52 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:52 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:50:55 --> Total execution time: 0.0348
DEBUG - 2021-04-16 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:55 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:55 --> 404 Page Not Found: Crud/vendors
ERROR - 2021-04-16 17:50:55 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:50:55 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 17:50:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:50:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:50:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:50:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:50:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:50:59 --> Total execution time: 0.0374
DEBUG - 2021-04-16 17:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:52:36 --> Total execution time: 0.0425
DEBUG - 2021-04-16 17:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:52:36 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:52:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:52:36 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:52:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:38 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:52:38 --> Total execution time: 0.0342
DEBUG - 2021-04-16 17:52:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:52:38 --> 404 Page Not Found: Crud/vendors
ERROR - 2021-04-16 17:52:38 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:52:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:52:39 --> Total execution time: 0.0387
DEBUG - 2021-04-16 17:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:52:39 --> 404 Page Not Found: Crud/vendors
ERROR - 2021-04-16 17:52:39 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:52:39 --> Total execution time: 0.0481
DEBUG - 2021-04-16 17:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:52:39 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:52:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:52:39 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:52:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:52:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:52:41 --> Total execution time: 0.0464
DEBUG - 2021-04-16 17:52:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:52:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:52:46 --> Total execution time: 0.0567
DEBUG - 2021-04-16 17:52:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:52:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:52:47 --> Total execution time: 0.0376
DEBUG - 2021-04-16 17:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:52:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:49 --> No URI present. Default controller set.
DEBUG - 2021-04-16 17:52:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:52:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:52:49 --> Total execution time: 0.0428
DEBUG - 2021-04-16 17:52:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:52:53 --> Total execution time: 0.0489
DEBUG - 2021-04-16 17:52:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:52:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:52:56 --> Total execution time: 0.0493
DEBUG - 2021-04-16 17:52:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:56 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:52:56 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-16 17:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:52:56 --> 404 Page Not Found: Images/logo2.png
ERROR - 2021-04-16 17:52:56 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:52:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:56 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:52:56 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:52:56 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:52:56 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:52:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:52:56 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-16 17:52:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:52:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:52:57 --> Total execution time: 0.0510
DEBUG - 2021-04-16 17:52:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:52:58 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:52:58 --> Total execution time: 0.0574
DEBUG - 2021-04-16 17:52:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:52:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:52:58 --> 404 Page Not Found: Crud/vendors
ERROR - 2021-04-16 17:52:58 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:53:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:10 --> No URI present. Default controller set.
DEBUG - 2021-04-16 17:53:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:53:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:53:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:53:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:53:10 --> Total execution time: 0.0417
DEBUG - 2021-04-16 17:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:53:11 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 17:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:53:11 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 17:53:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:53:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:53:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:53:15 --> Total execution time: 0.0391
DEBUG - 2021-04-16 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:53:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:53:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:53:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:53:18 --> Total execution time: 0.0436
DEBUG - 2021-04-16 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:53:18 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:53:18 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-16 17:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:53:18 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-16 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:53:18 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:53:18 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:53:18 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:53:18 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:53:18 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-16 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:53:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:53:18 --> 404 Page Not Found: Images/logo.png
ERROR - 2021-04-16 17:53:18 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-16 17:53:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:53:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:53:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:53:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:53:19 --> Total execution time: 0.0399
DEBUG - 2021-04-16 17:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:53:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:53:20 --> Total execution time: 0.0609
DEBUG - 2021-04-16 17:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:53:20 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:53:20 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:53:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:53:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:53:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:53:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:53:35 --> Total execution time: 0.0410
DEBUG - 2021-04-16 17:54:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:54:48 --> No URI present. Default controller set.
DEBUG - 2021-04-16 17:54:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:54:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:54:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:54:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 17:54:48 --> Total execution time: 0.0628
DEBUG - 2021-04-16 17:54:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:54:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:54:48 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 17:54:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:54:48 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 17:54:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:54:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:54:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:54:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:54:57 --> Total execution time: 0.0555
DEBUG - 2021-04-16 17:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:55:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:55:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:55:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:55:18 --> Total execution time: 0.0587
DEBUG - 2021-04-16 17:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:55:18 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-16 17:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:55:18 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:55:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:55:18 --> 404 Page Not Found: Images/avatar
ERROR - 2021-04-16 17:55:18 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:55:18 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 17:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:55:18 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-16 17:55:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:55:18 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-16 17:55:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:55:19 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-04-16 17:55:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:55:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:55:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:55:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 17:55:20 --> Total execution time: 0.0394
DEBUG - 2021-04-16 17:55:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:55:21 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-16 17:55:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:55:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:55:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:55:22 --> Total execution time: 0.0358
DEBUG - 2021-04-16 17:55:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:55:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:55:22 --> 404 Page Not Found: Crud/vendors
ERROR - 2021-04-16 17:55:22 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:55:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:55:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:55:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:55:23 --> Total execution time: 0.0338
DEBUG - 2021-04-16 17:55:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:55:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:55:30 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 17:56:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:56:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:56:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:56:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:56:00 --> Total execution time: 0.0560
DEBUG - 2021-04-16 17:56:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:56:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:56:01 --> 404 Page Not Found: Vendors/bootstrap
DEBUG - 2021-04-16 17:56:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:56:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:56:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:56:17 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:56:17 --> Total execution time: 0.0336
DEBUG - 2021-04-16 17:56:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:56:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:56:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:56:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:56:53 --> Total execution time: 0.0576
DEBUG - 2021-04-16 17:57:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:57:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:57:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:57:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:57:04 --> Total execution time: 0.0329
DEBUG - 2021-04-16 17:58:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:58:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:58:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:58:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:58:13 --> Total execution time: 0.0456
DEBUG - 2021-04-16 17:58:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:58:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:58:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:58:14 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 17:58:14 --> Total execution time: 0.0343
DEBUG - 2021-04-16 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:58:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:58:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:58:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 17:58:29 --> Total execution time: 0.0399
DEBUG - 2021-04-16 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:58:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:58:29 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:58:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:58:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:58:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:58:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:58:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:58:29 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:58:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:58:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:58:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:58:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:58:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:58:29 --> 404 Page Not Found: Crud/favicon.ico
DEBUG - 2021-04-16 17:58:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:58:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:58:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:58:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:58:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 17:58:31 --> Total execution time: 0.0362
DEBUG - 2021-04-16 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:59:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:59:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 17:59:06 --> Total execution time: 0.0350
DEBUG - 2021-04-16 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:06 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:06 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:06 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:59:06 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:06 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:59:06 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:06 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:59:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:59:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 17:59:07 --> Total execution time: 0.0552
DEBUG - 2021-04-16 17:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:07 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:59:07 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:07 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:59:07 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:59:07 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:07 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:59:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:59:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 17:59:07 --> Total execution time: 0.0559
DEBUG - 2021-04-16 17:59:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:59:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:59:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 17:59:08 --> Total execution time: 0.0382
DEBUG - 2021-04-16 17:59:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:59:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:59:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 17:59:11 --> Total execution time: 0.0379
DEBUG - 2021-04-16 17:59:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:59:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:59:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 17:59:47 --> Total execution time: 0.0371
DEBUG - 2021-04-16 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:59:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:59:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 17:59:48 --> Total execution time: 0.0382
DEBUG - 2021-04-16 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:59:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:59:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:59:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:59:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 17:59:50 --> Total execution time: 0.0364
DEBUG - 2021-04-16 17:59:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:50 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:59:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:50 --> UTF-8 Support Enabled
ERROR - 2021-04-16 17:59:50 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 17:59:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 17:59:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 17:59:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 17:59:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 17:59:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 17:59:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 17:59:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 17:59:51 --> Total execution time: 0.0352
DEBUG - 2021-04-16 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:01:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:01:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:01:00 --> Total execution time: 0.0354
DEBUG - 2021-04-16 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:00 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:00 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:00 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:00 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:00 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:00 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:01:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:01:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:01:42 --> Total execution time: 0.0379
DEBUG - 2021-04-16 18:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:42 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:42 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:42 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:01:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:01:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:01:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:01:43 --> Total execution time: 0.0549
DEBUG - 2021-04-16 18:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:43 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:43 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:43 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:01:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:01:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:01:44 --> Total execution time: 0.0527
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:01:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:01:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:01:44 --> Total execution time: 0.0345
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:01:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:01:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:01:55 --> Total execution time: 10.7280
DEBUG - 2021-04-16 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:01:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:01:55 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:01:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:01:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:01:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:02:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:02:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:02:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:02:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 18:02:08 --> Total execution time: 0.3803
DEBUG - 2021-04-16 18:02:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:02:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:02:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:02:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 18:02:10 --> Total execution time: 0.0340
DEBUG - 2021-04-16 18:03:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:03:47 --> No URI present. Default controller set.
DEBUG - 2021-04-16 18:03:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:03:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:03:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:03:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 18:03:48 --> Total execution time: 0.0421
DEBUG - 2021-04-16 18:03:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:03:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:03:48 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 18:03:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:03:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:03:48 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 18:03:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:03:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:03:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:03:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 18:03:52 --> Total execution time: 0.0329
DEBUG - 2021-04-16 18:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:04:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:04:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:04:05 --> Total execution time: 0.0458
DEBUG - 2021-04-16 18:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:05 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:05 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-16 18:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:05 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:05 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 18:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:05 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 18:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:05 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 18:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:05 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-16 18:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:05 --> 404 Page Not Found: Apple-iconpng/index
ERROR - 2021-04-16 18:04:05 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-04-16 18:04:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:04:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:04:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:04:07 --> Total execution time: 0.0411
DEBUG - 2021-04-16 18:04:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:07 --> 404 Page Not Found: Admin/apple-icon.png
ERROR - 2021-04-16 18:04:07 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-16 18:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:04:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:04:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:04:08 --> Total execution time: 0.0411
DEBUG - 2021-04-16 18:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:08 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:04:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:08 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:04:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:08 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 18:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:08 --> 404 Page Not Found: Crud/vendors
DEBUG - 2021-04-16 18:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:08 --> 404 Page Not Found: Crud/apple-icon.png
ERROR - 2021-04-16 18:04:08 --> 404 Page Not Found: Crud/favicon.ico
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:04:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:04:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:04:29 --> Total execution time: 0.0382
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:04:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:29 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:04:29 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:04:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:04:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:04:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:04:36 --> Total execution time: 0.0553
DEBUG - 2021-04-16 18:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:36 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:04:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:04:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:04:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:04:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:04:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:04:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:04:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:04:47 --> Total execution time: 0.0441
DEBUG - 2021-04-16 18:05:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:05:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:05:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:05:00 --> Total execution time: 0.0371
DEBUG - 2021-04-16 18:05:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:00 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:00 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:00 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:05:00 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:00 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:00 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:00 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:05:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:05:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:05:21 --> Total execution time: 0.0411
DEBUG - 2021-04-16 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:21 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:05:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:21 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:05:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:05:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:05:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:05:23 --> Total execution time: 0.0489
DEBUG - 2021-04-16 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:23 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:05:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:23 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:05:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:05:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:05:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:05:34 --> Total execution time: 0.0351
DEBUG - 2021-04-16 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:34 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:05:34 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:05:34 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:05:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:34 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:05:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:34 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:05:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:05:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:05:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:05:39 --> Total execution time: 0.0494
DEBUG - 2021-04-16 18:05:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:05:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:05:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:05:42 --> Total execution time: 0.0392
DEBUG - 2021-04-16 18:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:05:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:05:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:05:48 --> Total execution time: 0.0369
DEBUG - 2021-04-16 18:05:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:48 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:05:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:05:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:05:49 --> Total execution time: 0.0461
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:05:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:05:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:05:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:05:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:05:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:05:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:06:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:06:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:06:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:06:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:06:24 --> Total execution time: 0.0387
DEBUG - 2021-04-16 18:06:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:06:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:06:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:06:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:06:26 --> Total execution time: 0.0439
DEBUG - 2021-04-16 18:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:06:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:06:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:06:42 --> Total execution time: 0.0397
DEBUG - 2021-04-16 18:06:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:06:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:06:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:06:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:06:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:06:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:06:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:06:43 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:06:43 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:06:43 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:06:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:06:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:06:44 --> 404 Page Not Found: Crud/favicon.ico
DEBUG - 2021-04-16 18:06:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:06:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:06:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:06:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:06:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:06:51 --> Total execution time: 0.2591
DEBUG - 2021-04-16 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:09:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:09:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:09:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:09:49 --> Total execution time: 0.0381
DEBUG - 2021-04-16 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:09:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:09:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:09:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:09:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:09:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:09:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:09:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:09:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:09:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:09:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:09:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:09:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:10:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:10:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:10:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:10:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:10:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:10:10 --> Total execution time: 0.0602
DEBUG - 2021-04-16 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:10:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:10:10 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:10:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:10:10 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:10:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:10:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:10:10 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:10:10 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:10:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:10:10 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:10:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:10:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:10:10 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:12:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:12:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:12:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:12:03 --> Total execution time: 0.0373
DEBUG - 2021-04-16 18:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:12:03 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:12:03 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:12:03 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:12:03 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:12:03 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:12:03 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:12:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:12:03 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:12:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:12:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:12:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:12:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 18:12:50 --> Total execution time: 0.0366
DEBUG - 2021-04-16 18:12:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:12:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:12:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:12:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:12:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:12:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:12:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:12:50 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:12:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:12:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:12:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:12:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:13:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:13:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:13:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:13:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 18:13:09 --> Total execution time: 0.0372
DEBUG - 2021-04-16 18:13:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:09 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:13:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:09 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:13:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:09 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:13:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:09 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:13:09 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:13:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:09 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:13:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:14 --> No URI present. Default controller set.
DEBUG - 2021-04-16 18:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:13:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:13:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:13:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 130
DEBUG - 2021-04-16 18:13:14 --> Total execution time: 0.0432
DEBUG - 2021-04-16 18:13:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:13:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:14 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-16 18:13:14 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 18:13:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:13:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:13:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 18:13:21 --> Total execution time: 0.0343
DEBUG - 2021-04-16 18:13:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:13:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:13:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 18:13:35 --> Total execution time: 0.0389
DEBUG - 2021-04-16 18:13:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:36 --> 404 Page Not Found: Images/logo.png
DEBUG - 2021-04-16 18:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:36 --> 404 Page Not Found: Images/logo2.png
DEBUG - 2021-04-16 18:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:36 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 18:13:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:36 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 18:13:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:36 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 18:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:36 --> 404 Page Not Found: Images/avatar
DEBUG - 2021-04-16 18:13:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:36 --> 404 Page Not Found: Images/admin.jpg
DEBUG - 2021-04-16 18:13:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:36 --> 404 Page Not Found: Faviconico/index
DEBUG - 2021-04-16 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:13:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:13:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:13:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 18:13:40 --> Total execution time: 0.0376
DEBUG - 2021-04-16 18:13:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:40 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-16 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:13:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:13:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:13:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 18:13:41 --> Total execution time: 0.0372
DEBUG - 2021-04-16 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:13:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:13:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:41 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:13:41 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:13:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:13:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:13:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:13:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:13:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:13:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:13:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:13:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 18:13:44 --> Total execution time: 0.0380
DEBUG - 2021-04-16 18:14:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:14:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:14:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:14:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 18:14:50 --> Total execution time: 0.0361
DEBUG - 2021-04-16 18:14:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:14:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:14:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:14:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:14:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:14:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:14:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:14:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:14:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:14:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:14:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:14:50 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:14:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:14:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:14:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:14:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:14:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:14:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:14:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:14:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:14:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:14:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:14:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 18:14:52 --> Total execution time: 0.0362
DEBUG - 2021-04-16 18:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:15:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:15:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:15:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:15:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:15:35 --> Total execution time: 0.0351
DEBUG - 2021-04-16 18:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:15:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:15:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:15:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:15:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:15:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:15:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:15:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:15:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:15:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:15:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:15:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:15:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:15:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:16:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:16:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:16:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 225
DEBUG - 2021-04-16 18:16:16 --> Total execution time: 0.0351
DEBUG - 2021-04-16 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:16 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:16:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:16 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:16 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:16:16 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:16 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:16 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:16:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:16:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:16:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:16:30 --> Total execution time: 0.0348
DEBUG - 2021-04-16 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:30 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:30 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:16:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:16:30 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:16:30 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:16:30 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:30 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:30 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:33 --> 404 Page Not Found: Crud/index
DEBUG - 2021-04-16 18:16:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:16:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:16:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:16:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:16:34 --> Total execution time: 0.0367
DEBUG - 2021-04-16 18:16:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:16:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:16:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:16:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:16:36 --> Total execution time: 0.0376
DEBUG - 2021-04-16 18:16:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:36 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:16:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:16:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:16:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:16:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:17:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:17:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:17:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:17:13 --> Total execution time: 0.0375
DEBUG - 2021-04-16 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:17:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:17:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:17:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:17:32 --> Total execution time: 0.0368
DEBUG - 2021-04-16 18:17:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:32 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:17:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:17:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:17:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:32 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:17:32 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:17:32 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:17:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:17:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:17:33 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:17:33 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:17:33 --> Total execution time: 0.0362
DEBUG - 2021-04-16 18:17:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:33 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:33 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:17:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:33 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:17:33 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:17:33 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:17:33 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:17:33 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:18:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:18:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:18:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:18:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 18:18:31 --> Total execution time: 0.0358
DEBUG - 2021-04-16 18:18:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:18:31 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-16 18:18:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:18:31 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 18:18:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:18:31 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 18:18:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:18:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:18:31 --> 404 Page Not Found: Assets/js
DEBUG - 2021-04-16 18:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:19:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 18:19:20 --> Total execution time: 0.0359
DEBUG - 2021-04-16 18:20:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:20:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:20:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:20:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:20:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:20:05 --> Total execution time: 0.0388
DEBUG - 2021-04-16 18:20:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:20:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:20:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:20:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:20:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 18:20:38 --> Total execution time: 0.0556
DEBUG - 2021-04-16 18:20:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:20:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:20:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:20:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 18:20:39 --> Total execution time: 0.0488
DEBUG - 2021-04-16 18:20:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:20:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:20:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:20:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:20:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 223
DEBUG - 2021-04-16 18:20:41 --> Total execution time: 0.0616
DEBUG - 2021-04-16 18:21:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:21:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:21:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:21:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:21:28 --> Total execution time: 0.0378
DEBUG - 2021-04-16 18:21:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:21:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:21:30 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-16 18:21:30 --> Total execution time: 0.0355
DEBUG - 2021-04-16 18:21:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:21:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:21:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:21:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:21:40 --> Total execution time: 0.0378
DEBUG - 2021-04-16 18:21:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:21:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:21:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:21:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:21:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:21:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:21:40 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:21:40 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:21:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:21:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:21:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:21:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:21:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:21:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:21:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:21:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:21:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:21:42 --> Total execution time: 0.0375
DEBUG - 2021-04-16 18:21:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:21:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:21:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:21:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:21:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:21:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:21:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:21:42 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:21:42 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:21:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:21:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:21:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:21:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:22:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:22:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:22:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:22:19 --> Total execution time: 0.0371
DEBUG - 2021-04-16 18:22:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:22:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:22:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:22:19 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:22:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:22:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:22:19 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:22:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:22:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:22:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:22:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:22:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:22:27 --> Total execution time: 0.0457
DEBUG - 2021-04-16 18:22:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:22:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:22:27 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:22:27 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:22:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:22:27 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:27 --> UTF-8 Support Enabled
ERROR - 2021-04-16 18:22:27 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:22:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:22:27 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:22:27 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:22:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-16 18:22:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-16 18:22:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 224
DEBUG - 2021-04-16 18:22:51 --> Total execution time: 0.0368
DEBUG - 2021-04-16 18:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:22:51 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:22:51 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:22:51 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:22:51 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-16 18:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-16 18:22:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-16 18:22:51 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-16 18:22:51 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-16 18:22:51 --> 404 Page Not Found: Crud/images
