<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-04-13 13:56:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 13:56:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 13:56:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 13:56:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 13:56:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 13:56:05 --> Total execution time: 0.0628
DEBUG - 2021-04-13 14:59:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 14:59:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 14:59:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 14:59:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 14:59:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 14:59:01 --> Total execution time: 0.0496
DEBUG - 2021-04-13 14:59:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 14:59:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 14:59:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 14:59:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 14:59:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 14:59:30 --> Total execution time: 0.0550
DEBUG - 2021-04-13 14:59:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 14:59:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 14:59:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 14:59:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 14:59:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 14:59:35 --> Total execution time: 0.0647
DEBUG - 2021-04-13 14:59:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 14:59:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 14:59:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 14:59:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 14:59:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 14:59:45 --> Total execution time: 0.0545
DEBUG - 2021-04-13 15:00:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:00:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:00:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:00:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:00:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:00:28 --> Total execution time: 0.0623
DEBUG - 2021-04-13 15:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:00:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:00:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:00:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:00:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:00:43 --> Total execution time: 0.0653
DEBUG - 2021-04-13 15:00:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:00:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:00:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:00:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:00:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:00:49 --> Total execution time: 0.0612
DEBUG - 2021-04-13 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:01:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:01:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:01:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:01:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:01:07 --> Total execution time: 0.0354
DEBUG - 2021-04-13 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:01:07 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-13 15:01:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:01:07 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:01:07 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-13 15:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:02:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:02:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:02:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:02:25 --> Total execution time: 0.0362
DEBUG - 2021-04-13 15:02:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:02:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:02:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:02:40 --> Total execution time: 0.0356
DEBUG - 2021-04-13 15:03:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:03:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:03:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:03:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:03:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:03:01 --> Total execution time: 0.0545
DEBUG - 2021-04-13 15:03:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:03:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:03:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:03:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:03:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:03:06 --> Total execution time: 0.0562
DEBUG - 2021-04-13 15:04:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:04:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:04:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:04:01 --> Total execution time: 0.0445
DEBUG - 2021-04-13 15:04:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:04:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:04:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:04:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:04:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:04:01 --> Total execution time: 0.0437
DEBUG - 2021-04-13 15:04:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:04:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:04:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:04:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:04:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:04:04 --> Total execution time: 0.0528
DEBUG - 2021-04-13 15:04:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:04:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:04:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:04:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:04:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:04:05 --> Total execution time: 0.0559
DEBUG - 2021-04-13 15:04:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:04:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:04:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:04:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:04:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:04:06 --> Total execution time: 0.0521
DEBUG - 2021-04-13 15:04:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:04:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:04:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:04:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:04:07 --> Total execution time: 0.0515
DEBUG - 2021-04-13 15:04:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:04:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:04:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:04:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:04:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:04:08 --> Total execution time: 0.0611
DEBUG - 2021-04-13 15:06:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:06:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:06:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:06:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:06:03 --> Total execution time: 0.0370
DEBUG - 2021-04-13 15:06:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:06:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:06:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:06:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:06:35 --> Total execution time: 0.0369
DEBUG - 2021-04-13 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:06:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:06:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:06:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:06:36 --> Total execution time: 0.0569
DEBUG - 2021-04-13 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:36 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:06:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:06:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:36 --> 404 Page Not Found: Crud/apple-icon.png
ERROR - 2021-04-13 15:06:36 --> 404 Page Not Found: Crud/favicon.ico
DEBUG - 2021-04-13 15:06:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:06:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:06:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:06:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:06:39 --> Total execution time: 0.0600
DEBUG - 2021-04-13 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:06:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:06:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:06:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:06:42 --> Total execution time: 0.0340
DEBUG - 2021-04-13 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:42 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:06:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:42 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:06:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:06:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:06:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:06:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:07:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:07:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:07:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:07:05 --> Total execution time: 0.0453
DEBUG - 2021-04-13 15:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:07:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:07:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:07:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:07:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:07:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:07:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:07:05 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:07:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:07:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:07:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:10:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:10:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:10:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:10:20 --> Total execution time: 0.0343
DEBUG - 2021-04-13 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:10:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:10:20 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:10:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:10:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:10:20 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:10:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:10:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:10:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:10:20 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:10:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:10:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:10:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:10:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:10:47 --> Total execution time: 0.0350
DEBUG - 2021-04-13 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:10:47 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:10:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:10:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:10:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:10:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:10:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:10:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:10:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:10:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:10:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:11:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:11:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:11:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:11:08 --> Total execution time: 0.0456
DEBUG - 2021-04-13 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:11:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:11:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:11:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:11:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:11:08 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:11:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:11:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:11:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:11:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:13:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:13:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:13:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:13:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:13:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:13:31 --> Total execution time: 0.0710
DEBUG - 2021-04-13 15:15:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:15:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:15:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:15:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:15:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:15:20 --> Total execution time: 0.0357
DEBUG - 2021-04-13 15:15:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:15:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:15:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:15:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:15:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:15:55 --> Total execution time: 0.0567
DEBUG - 2021-04-13 15:16:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:16:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:16:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:16:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:16:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:16:40 --> Total execution time: 0.0472
DEBUG - 2021-04-13 15:17:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:17:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:17:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:17:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:17:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:17:26 --> Total execution time: 0.0388
DEBUG - 2021-04-13 15:18:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:18:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:18:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:18:29 --> Total execution time: 0.0369
DEBUG - 2021-04-13 15:18:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:18:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:18:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:18:53 --> Total execution time: 0.0397
DEBUG - 2021-04-13 15:18:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:18:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:18:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:18:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:18:57 --> Total execution time: 0.0340
DEBUG - 2021-04-13 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:18:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:18:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:18:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:18:57 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:18:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:18:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:18:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:18:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:18:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:18:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:19:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:19:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:19:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:19:20 --> Total execution time: 0.0350
DEBUG - 2021-04-13 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:19:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:19:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:19:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:19:50 --> Total execution time: 0.0470
DEBUG - 2021-04-13 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:19:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:19:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:19:50 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:19:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:20:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:20:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:20:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:20:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:20:58 --> Total execution time: 0.0342
DEBUG - 2021-04-13 15:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:20:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:20:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:20:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:20:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:20:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:20:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:20:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:20:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:20:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:20:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:20:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:20:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:20:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:20:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:21:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:21:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:21:10 --> Total execution time: 0.0386
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:21:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:21:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:21:31 --> Total execution time: 0.0515
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:21:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:21:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:21:34 --> Total execution time: 0.0618
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:21:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:21:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:21:36 --> Total execution time: 0.0598
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:21:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:21:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:21:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:21:58 --> Total execution time: 0.0356
DEBUG - 2021-04-13 15:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:21:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:21:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:22:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:22:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:22:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:22:40 --> Total execution time: 0.0354
DEBUG - 2021-04-13 15:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:22:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:22:40 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:22:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:22:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:22:40 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:22:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:22:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:22:40 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:22:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:22:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:22:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:22:50 --> Total execution time: 0.0593
DEBUG - 2021-04-13 15:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:22:50 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:22:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:22:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:22:50 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:22:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:22:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:22:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:22:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:22:50 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:22:50 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:25:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:25:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:25:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:25:19 --> Total execution time: 0.0534
DEBUG - 2021-04-13 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:25:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:25:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:25:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:25:19 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:25:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:25:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:25:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:25:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:25:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:25:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:29:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:29:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:29:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:29:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:29:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:29:17 --> Total execution time: 0.0592
DEBUG - 2021-04-13 15:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:29:17 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:29:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:29:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:29:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:29:17 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:29:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:29:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:29:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:29:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:29:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:31:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:31:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:31:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:31:14 --> Total execution time: 0.0348
DEBUG - 2021-04-13 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:31:15 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:31:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:31:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:31:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:31:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:31:48 --> Total execution time: 0.0517
DEBUG - 2021-04-13 15:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:31:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:31:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:31:48 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:31:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:31:48 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:31:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:31:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:31:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:31:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:31:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:31:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:32:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:32:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:32:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:32:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:32:26 --> Total execution time: 0.0587
DEBUG - 2021-04-13 15:32:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:32:27 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:32:27 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:32:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:32:27 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:32:27 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:32:27 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:32:27 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:32:27 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:32:27 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:32:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:32:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:32:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:32:46 --> Total execution time: 0.0586
DEBUG - 2021-04-13 15:32:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:32:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:32:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:32:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:32:46 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:32:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:32:46 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:32:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:32:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:32:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:33:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:33:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:33:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:33:02 --> Total execution time: 0.0460
DEBUG - 2021-04-13 15:33:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:02 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:33:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:33:02 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:33:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:33:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:33:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:33:29 --> Total execution time: 0.0570
DEBUG - 2021-04-13 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:29 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:33:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:33:29 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:33:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:29 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:33:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:33:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:33:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:33:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:33:30 --> Total execution time: 0.0365
DEBUG - 2021-04-13 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:30 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:30 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:30 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:33:30 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:33:30 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:30 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:30 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:30 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:33:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:33:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:33:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:33:31 --> Total execution time: 0.0344
DEBUG - 2021-04-13 15:33:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:31 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:33:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:33:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:33:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:33:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:34:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:34:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:34:24 --> Total execution time: 0.0341
DEBUG - 2021-04-13 15:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:24 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:34:24 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:24 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:24 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:24 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:24 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:25 --> 404 Page Not Found: Crud/save_halte
DEBUG - 2021-04-13 15:34:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:34:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:34:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:34:41 --> Total execution time: 0.0462
DEBUG - 2021-04-13 15:34:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:41 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:34:41 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:34:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:41 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:34:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:42 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:34:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:34:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 15:34:44 --> Total execution time: 0.0336
DEBUG - 2021-04-13 15:34:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:34:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:34:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:34:48 --> Total execution time: 0.0331
DEBUG - 2021-04-13 15:34:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:34:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:34:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:34:49 --> Total execution time: 0.0327
DEBUG - 2021-04-13 15:34:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:34:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:49 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:34:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:34:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:34:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:34:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:34:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:35:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:35:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:35:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:35:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:35:59 --> Total execution time: 0.0557
DEBUG - 2021-04-13 15:35:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:35:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:35:59 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:35:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:35:59 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:35:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:35:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:35:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:35:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:35:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:35:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:35:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:35:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:35:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:35:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:35:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:35:59 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:35:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:35:59 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:35:59 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:37:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:37:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:37:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:37:29 --> Total execution time: 0.0367
DEBUG - 2021-04-13 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:37:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:37:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:37:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:37:29 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:37:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:37:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:37:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:37:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:37:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:37:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:38:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:38:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:38:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:38:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 15:38:01 --> You did not select a file to upload.
DEBUG - 2021-04-13 15:38:01 --> Total execution time: 0.1026
DEBUG - 2021-04-13 15:38:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:38:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:38:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:38:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:38:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:38:05 --> Total execution time: 0.0362
DEBUG - 2021-04-13 15:39:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:39:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:39:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:39:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:39:06 --> Total execution time: 0.0347
DEBUG - 2021-04-13 15:39:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:39:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:39:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:39:06 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:39:06 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:39:06 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:39:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:39:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:39:06 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:39:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:39:06 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:39:06 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:39:06 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:39:06 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:39:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:39:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:39:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:39:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 15:39:47 --> You did not select a file to upload.
DEBUG - 2021-04-13 15:39:47 --> Total execution time: 0.0356
DEBUG - 2021-04-13 15:39:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:39:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:39:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:39:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:39:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:39:49 --> Total execution time: 0.0337
DEBUG - 2021-04-13 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:40:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:40:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:40:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:40:01 --> Total execution time: 0.0336
DEBUG - 2021-04-13 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:40:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:01 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:40:01 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:40:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:40:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:40:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 15:40:10 --> The filetype you are attempting to upload is not allowed.
DEBUG - 2021-04-13 15:40:10 --> Total execution time: 0.0789
DEBUG - 2021-04-13 15:40:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:40:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:40:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:40:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:40:17 --> Total execution time: 0.0623
DEBUG - 2021-04-13 15:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:40:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:40:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:40:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:40:32 --> Total execution time: 0.0458
DEBUG - 2021-04-13 15:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:32 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:40:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:32 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:40:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:40:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:40:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:40:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:40:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:40:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 15:40:41 --> Total execution time: 0.0600
DEBUG - 2021-04-13 15:41:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:41:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:41:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:41:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:41:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:41:03 --> Total execution time: 0.0346
DEBUG - 2021-04-13 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:41:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:41:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:41:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:41:38 --> Total execution time: 0.0338
DEBUG - 2021-04-13 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:41:38 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:41:38 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:41:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:41:38 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:41:38 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:41:38 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:41:38 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:41:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:41:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:41:38 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:46:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:46:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:46:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:46:05 --> Total execution time: 0.0379
DEBUG - 2021-04-13 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:46:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:46:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:46:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:46:34 --> Total execution time: 0.0460
DEBUG - 2021-04-13 15:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:46:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:46:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:46:46 --> Total execution time: 0.0450
DEBUG - 2021-04-13 15:46:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:46:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:46:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:48:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:48:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:48:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:48:40 --> Total execution time: 0.0357
DEBUG - 2021-04-13 15:48:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:40 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:48:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:48:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:48:40 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:48:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:40 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:48:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:40 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:40 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:48:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:48:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:48:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:48:44 --> Total execution time: 0.0573
DEBUG - 2021-04-13 15:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:44 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:48:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:48:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:48:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:48:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:48:58 --> Total execution time: 0.0568
DEBUG - 2021-04-13 15:48:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:48:58 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:48:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:48:58 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:48:58 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:50:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:50:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:50:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:50:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:50:23 --> Total execution time: 0.0344
DEBUG - 2021-04-13 15:50:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:50:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:50:23 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:50:23 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:50:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:50:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:50:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:50:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:50:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:50:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:50:23 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:50:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:50:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:50:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:50:23 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:50:23 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:51:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:51:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:51:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:51:31 --> Total execution time: 0.0365
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:51:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:51:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:51:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:51:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:51:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:51:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:51:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:51:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:51:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:51:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:51:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:51:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:51:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:52:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:52:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:52:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:52:36 --> Total execution time: 0.0347
DEBUG - 2021-04-13 15:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:52:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:36 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:52:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:52:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:36 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:52:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:52:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:52:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:52:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:52:48 --> Total execution time: 0.0341
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:52:48 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:52:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:52:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:53:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:53:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:53:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:53:20 --> Total execution time: 0.0550
DEBUG - 2021-04-13 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:20 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:53:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:53:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:20 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:53:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:53:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:20 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:53:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:53:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:53:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:53:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:53:36 --> Total execution time: 0.0335
DEBUG - 2021-04-13 15:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:53:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:53:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:55:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:55:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:55:02 --> Total execution time: 0.0522
DEBUG - 2021-04-13 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:02 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:55:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:02 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:02 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:55:02 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:55:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:55:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:55:11 --> Total execution time: 0.0444
DEBUG - 2021-04-13 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:55:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:55:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:55:12 --> Total execution time: 0.0554
DEBUG - 2021-04-13 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:12 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:55:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:12 --> 404 Page Not Found: Crud/apple-icon.png
ERROR - 2021-04-13 15:55:12 --> 404 Page Not Found: Crud/favicon.ico
DEBUG - 2021-04-13 15:55:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:55:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:55:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:55:28 --> Total execution time: 0.0362
DEBUG - 2021-04-13 15:55:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:28 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:55:28 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:28 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:55:28 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:28 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:55:28 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:28 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:55:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:55:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:55:49 --> Total execution time: 0.0629
DEBUG - 2021-04-13 15:55:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:55:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:55:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:55:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:55:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:55:55 --> Total execution time: 0.0376
DEBUG - 2021-04-13 15:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:55 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:55:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:55 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:55:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:55:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:55:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:55:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:56:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:56:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:56:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:56:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:56:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:56:13 --> Total execution time: 0.0608
DEBUG - 2021-04-13 15:56:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:56:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:56:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:56:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:56:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:56:14 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:56:14 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:56:14 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:56:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:56:14 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:56:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:56:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:56:14 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:56:14 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:57:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:57:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:57:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:57:05 --> Total execution time: 0.0357
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:57:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:05 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:57:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:57:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:57:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:57:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:57:48 --> Total execution time: 0.0384
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:57:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:57:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:57:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:58:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:58:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:58:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:58:32 --> Total execution time: 0.0581
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:58:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:58:32 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:58:32 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:58:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:58:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:58:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
ERROR - 2021-04-13 15:58:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:58:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:58:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:58:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:58:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:58:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:58:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:59:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:59:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:59:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:59:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:59:17 --> Total execution time: 0.0500
DEBUG - 2021-04-13 15:59:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:59:17 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:59:17 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:59:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:59:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:59:17 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 15:59:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:59:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:59:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 15:59:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 15:59:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 15:59:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 15:59:21 --> Total execution time: 0.0341
DEBUG - 2021-04-13 15:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:59:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:59:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:59:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:59:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:59:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 15:59:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 15:59:21 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 15:59:21 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:00:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:00:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:00:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:00:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:00:35 --> Total execution time: 0.0374
DEBUG - 2021-04-13 16:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:00:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:00:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:00:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:00:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:00:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:00:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:00:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:00:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:04:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:04:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:04:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:04:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:04:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:04:31 --> Total execution time: 0.0487
DEBUG - 2021-04-13 16:04:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:04:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:04:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:04:32 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:04:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:04:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:04:32 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:04:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:04:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:04:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:04:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:04:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:04:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:04:32 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:06:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:06:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:06:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:06:34 --> Total execution time: 0.0535
DEBUG - 2021-04-13 16:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:06:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:06:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:06:34 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:06:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:06:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:06:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:06:34 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:06:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:06:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:06:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:06:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:06:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:07:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:07:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:07:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:07:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:07:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:07:11 --> Total execution time: 0.0339
DEBUG - 2021-04-13 16:07:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:07:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:07:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:07:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:07:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:07:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:07:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:07:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:07:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:07:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:07:12 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:07:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:07:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:07:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:07:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:07:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:07:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:07:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:09:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:09:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:09:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:09:46 --> Total execution time: 0.0338
DEBUG - 2021-04-13 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:09:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:09:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:09:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:09:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:09:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:09:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:09:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:09:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:09:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:09:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:09:46 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:09:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:09:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:09:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:09:46 --> 404 Page Not Found: Crud/apple-icon.png
DEBUG - 2021-04-13 16:10:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:10:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:10:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:10:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:10:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:10:35 --> Total execution time: 0.0494
DEBUG - 2021-04-13 16:10:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:10:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:10:35 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:10:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:10:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:10:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:10:36 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:10:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:10:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:10:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:10:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:10:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:10:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:10:36 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:10:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:15:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:15:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:15:15 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:15:15 --> Total execution time: 0.0364
DEBUG - 2021-04-13 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:15:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:15:15 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:15:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:15:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:15:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:15:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:15:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:15:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:15:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:15:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:15:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:15:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:15:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:15:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:15:15 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:15:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:16:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:16:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:16:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:16:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 16:16:37 --> Total execution time: 0.0486
DEBUG - 2021-04-13 16:16:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:16:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:16:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:16:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:16:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:16:47 --> Total execution time: 0.0696
DEBUG - 2021-04-13 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:19:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:19:22 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:19:22 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:19:22 --> Total execution time: 0.0353
DEBUG - 2021-04-13 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:19:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:19:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:19:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:19:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:19:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:19:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:19:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:19:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:19:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:22 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:19:22 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:19:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:19:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:19:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:19:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:19:23 --> Total execution time: 0.0395
DEBUG - 2021-04-13 16:19:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:19:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:19:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:19:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:19:43 --> Total execution time: 0.0607
DEBUG - 2021-04-13 16:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:19:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:19:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:19:58 --> Total execution time: 0.0540
DEBUG - 2021-04-13 16:20:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:20:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:20:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:20:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:20:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:20:09 --> Total execution time: 0.0574
DEBUG - 2021-04-13 16:20:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:20:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:20:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:20:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:20:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:20:17 --> Total execution time: 0.0577
DEBUG - 2021-04-13 16:20:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:20:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:20:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:20:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:20:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:20:34 --> Total execution time: 0.0538
DEBUG - 2021-04-13 16:20:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:20:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:20:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:20:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:20:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:20:43 --> Total execution time: 0.0581
DEBUG - 2021-04-13 16:21:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:21:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:21:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:21:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:21:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:21:23 --> Total execution time: 0.0536
DEBUG - 2021-04-13 16:26:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:26:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:26:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:26:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:26:14 --> Total execution time: 0.0569
DEBUG - 2021-04-13 16:26:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:26:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:26:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:26:15 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:26:15 --> Total execution time: 0.0435
DEBUG - 2021-04-13 16:26:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:26:15 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:26:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:26:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:26:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:26:15 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:26:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:26:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:26:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:26:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:26:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:26:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:26:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:26:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:26:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:26:44 --> Total execution time: 0.0571
DEBUG - 2021-04-13 16:26:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:26:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:26:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:26:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:26:44 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:26:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:26:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:26:44 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:26:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:26:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:26:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:26:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:27:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:27:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:27:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:27:14 --> Total execution time: 0.0350
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:27:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:27:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:27:14 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:30:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:30:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 16:30:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:30:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:30:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:30:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:30:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:30:23 --> Total execution time: 0.0579
DEBUG - 2021-04-13 16:30:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:30:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:30:24 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-13 16:31:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:31:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:31:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:31:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:31:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:31:18 --> Total execution time: 0.0409
DEBUG - 2021-04-13 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:33:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:33:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:33:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:33:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:33:19 --> Total execution time: 0.0392
DEBUG - 2021-04-13 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:33:19 --> 404 Page Not Found: Images/halte
DEBUG - 2021-04-13 16:33:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:33:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:33:19 --> 404 Page Not Found: Images/halte
DEBUG - 2021-04-13 16:33:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:33:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:33:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:33:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:33:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:33:29 --> Total execution time: 0.0508
DEBUG - 2021-04-13 16:33:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:33:29 --> 404 Page Not Found: Images/halte
DEBUG - 2021-04-13 16:33:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:33:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:33:29 --> 404 Page Not Found: Images/halte
DEBUG - 2021-04-13 16:33:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:33:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:33:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:33:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:33:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:33:50 --> Total execution time: 0.0399
DEBUG - 2021-04-13 16:34:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:34:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:34:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:34:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:34:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:34:10 --> Total execution time: 0.0361
DEBUG - 2021-04-13 16:34:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:34:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:34:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:34:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:34:15 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:34:15 --> Total execution time: 0.0602
DEBUG - 2021-04-13 16:34:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:34:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:34:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:34:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:34:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:34:29 --> Total execution time: 0.0475
DEBUG - 2021-04-13 16:34:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:34:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:34:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:34:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:34:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:34:32 --> Total execution time: 0.0480
DEBUG - 2021-04-13 16:34:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:34:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:34:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:34:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:34:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:34:56 --> Total execution time: 0.0480
DEBUG - 2021-04-13 16:35:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:35:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:35:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:35:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:35:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:35:02 --> Total execution time: 0.0526
DEBUG - 2021-04-13 16:35:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:35:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:35:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:35:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:35:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:35:12 --> Total execution time: 0.0584
DEBUG - 2021-04-13 16:35:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:35:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:35:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:35:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:35:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:35:27 --> Total execution time: 0.0458
DEBUG - 2021-04-13 16:36:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:36:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:36:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:36:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:36:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:36:12 --> Total execution time: 0.0374
DEBUG - 2021-04-13 16:37:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:37:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:37:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:37:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:37:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:37:53 --> Total execution time: 0.0593
DEBUG - 2021-04-13 16:37:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:37:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:37:54 --> 404 Page Not Found: Crud/edit_halte
DEBUG - 2021-04-13 16:38:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:32 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:38:32 --> 404 Page Not Found: Crud/edit_halte
DEBUG - 2021-04-13 16:38:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:38:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:38:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:38:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:38:34 --> Total execution time: 0.0534
DEBUG - 2021-04-13 16:38:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:38:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:38:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:38:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:38:35 --> Total execution time: 0.0573
DEBUG - 2021-04-13 16:38:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:38:36 --> 404 Page Not Found: Crud/edit_halte
DEBUG - 2021-04-13 16:38:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:38:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:38:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:38:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:38:55 --> Total execution time: 0.0544
DEBUG - 2021-04-13 16:38:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:38:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:38:56 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:38:56 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:38:56 --> Total execution time: 0.0350
DEBUG - 2021-04-13 16:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:38:57 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:38:57 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:38:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:38:57 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:38:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:38:57 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:38:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:38:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:38:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:38:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:38:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:38:57 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:38:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:38:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:38:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:38:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:38:59 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:38:59 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:38:59 --> Total execution time: 0.0573
DEBUG - 2021-04-13 16:39:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:39:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:39:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:39:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:39:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:39:36 --> Total execution time: 0.0560
DEBUG - 2021-04-13 16:39:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:39:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:39:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:39:37 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 16:39:37 --> Total execution time: 0.0498
DEBUG - 2021-04-13 16:39:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:39:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:39:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:39:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:39:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:39:40 --> Total execution time: 0.0374
DEBUG - 2021-04-13 16:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:39:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:39:41 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 16:39:41 --> Total execution time: 0.0365
DEBUG - 2021-04-13 16:39:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:39:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:39:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:39:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:39:42 --> Total execution time: 0.0562
DEBUG - 2021-04-13 16:39:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:39:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:39:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:39:44 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 16:39:44 --> Total execution time: 0.0596
DEBUG - 2021-04-13 16:39:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:39:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:39:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:39:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:39:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:39:45 --> Total execution time: 0.0582
DEBUG - 2021-04-13 16:40:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:40:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:40:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:40:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:40:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:40:44 --> Total execution time: 0.0612
DEBUG - 2021-04-13 16:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:40:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:40:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:40:45 --> Total execution time: 0.0371
DEBUG - 2021-04-13 16:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:40:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:40:45 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:40:45 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:40:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:40:45 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:40:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:40:45 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:40:45 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:40:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:40:45 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:40:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:40:45 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:40:45 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:40:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:40:45 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:41:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:41:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:41:05 --> Total execution time: 0.0559
DEBUG - 2021-04-13 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:05 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:41:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:05 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:41:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:41:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:41:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:41:16 --> Total execution time: 0.0484
DEBUG - 2021-04-13 16:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:16 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:41:16 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:16 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:16 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:16 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:17 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:41:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:17 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:41:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:17 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:17 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:41:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:41:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:41:31 --> Total execution time: 0.0481
DEBUG - 2021-04-13 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:31 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:41:31 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:41:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:31 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:41:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:31 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:41:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:41:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:41:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:41:37 --> Total execution time: 0.0673
DEBUG - 2021-04-13 16:41:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:37 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:41:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:37 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:41:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:37 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:41:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:37 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:41:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:37 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:41:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:41:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:41:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:41:44 --> Total execution time: 0.0624
DEBUG - 2021-04-13 16:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:44 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:41:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:44 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:41:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:41:44 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:41:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:41:44 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:41:44 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:42:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:42:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:42:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:42:34 --> Total execution time: 0.0527
DEBUG - 2021-04-13 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:42:34 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:42:34 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:42:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:42:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:42:34 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:42:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:42:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:42:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:42:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:42:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:42:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:42:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:42:34 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:42:34 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:46:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:46:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:46:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:46:47 --> Total execution time: 0.0517
DEBUG - 2021-04-13 16:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:47 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:46:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:47 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:47 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:46:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:46:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:46:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:46:54 --> Total execution time: 0.0363
DEBUG - 2021-04-13 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:46:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:46:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:46:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:46:55 --> Total execution time: 0.0402
DEBUG - 2021-04-13 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:55 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:46:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:46:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:55 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:46:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:46:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:46:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:46:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:47:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:47:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:47:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:47:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 16:47:32 --> Total execution time: 0.0359
DEBUG - 2021-04-13 16:47:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:47:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:47:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:47:35 --> Total execution time: 0.0524
DEBUG - 2021-04-13 16:48:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:48:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:48:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:48:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:48:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:48:01 --> Total execution time: 0.0383
DEBUG - 2021-04-13 16:48:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:48:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:48:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:48:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 16:48:02 --> Total execution time: 0.0357
DEBUG - 2021-04-13 16:49:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:49:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:49:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 16:49:03 --> Total execution time: 0.0550
DEBUG - 2021-04-13 16:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:49:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:49:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:49:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:49:11 --> Total execution time: 0.0370
DEBUG - 2021-04-13 16:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:49:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:49:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:49:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:49:11 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:49:11 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:49:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:49:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:49:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:49:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:49:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:49:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:49:41 --> Total execution time: 0.0359
DEBUG - 2021-04-13 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:49:41 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:49:41 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:49:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:49:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:49:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:49:41 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:49:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:49:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:49:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:49:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:49:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:49:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:50:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:50:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:50:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:50:57 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:50:57 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:50:57 --> Total execution time: 0.0375
DEBUG - 2021-04-13 16:50:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:50:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:50:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:50:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:50:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:50:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:50:57 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:50:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:50:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:50:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:50:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:50:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:50:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:50:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:50:57 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:50:57 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:50:57 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:51:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:51:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:51:00 --> Total execution time: 0.0475
DEBUG - 2021-04-13 16:51:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:51:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:51:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:51:01 --> Total execution time: 0.0595
DEBUG - 2021-04-13 16:51:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:01 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:51:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:01 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:51:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:51:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:51:25 --> Total execution time: 0.0496
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:51:25 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:51:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:25 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:51:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:25 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:51:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:51:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:51:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:51:29 --> Total execution time: 0.0364
DEBUG - 2021-04-13 16:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:29 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:51:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:29 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:51:29 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:51:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:51:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:51:29 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:51:29 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:51:29 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:52:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:52:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:52:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:52:45 --> Total execution time: 0.0419
DEBUG - 2021-04-13 16:52:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:45 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:45 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:45 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:46 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:52:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:52:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:52:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:52:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:52:55 --> Total execution time: 0.0604
DEBUG - 2021-04-13 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:52:55 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:52:55 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:53:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:53:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:53:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:53:05 --> Total execution time: 0.0505
DEBUG - 2021-04-13 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:53:05 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:53:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:05 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:53:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:05 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:53:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:53:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:53:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:53:11 --> Total execution time: 0.0357
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:53:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:53:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:53:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:53:46 --> Total execution time: 0.0534
DEBUG - 2021-04-13 16:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:46 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:53:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:46 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:53:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:53:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:53:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:53:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:53:53 --> Total execution time: 0.0363
DEBUG - 2021-04-13 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:53 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:53:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:53 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:53:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:53:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:53:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:53:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:54:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:54:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:54:19 --> Total execution time: 0.0438
DEBUG - 2021-04-13 16:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:54:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:54:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:54:19 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:54:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:54:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:54:19 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:54:19 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:54:19 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:54:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:54:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:54:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:54:46 --> Total execution time: 0.0570
DEBUG - 2021-04-13 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:54:46 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:54:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:54:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:54:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:54:46 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:54:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:54:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:54:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:54:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:54:46 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:54:46 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:54:46 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:54:46 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:56:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:56:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:56:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:56:42 --> Total execution time: 0.0541
DEBUG - 2021-04-13 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:56:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:56:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:56:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:56:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:56:42 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:56:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:56:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:56:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:56:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:56:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:56:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:56:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:58:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:58:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:58:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:58:25 --> Total execution time: 0.0574
DEBUG - 2021-04-13 16:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:58:25 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:58:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:28 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:28 --> 404 Page Not Found: Crud/update_halte
DEBUG - 2021-04-13 16:58:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:58:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:58:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:58:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:58:42 --> Total execution time: 0.0505
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:58:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:58:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:58:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:58:43 --> Total execution time: 0.0374
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:58:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 16:58:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 16:58:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 16:58:53 --> Total execution time: 0.0581
DEBUG - 2021-04-13 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:54 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 16:58:54 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 16:58:54 --> UTF-8 Support Enabled
ERROR - 2021-04-13 16:58:54 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:54 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:54 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 16:58:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 16:58:54 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 16:58:54 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:00:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:00:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:00:13 --> Total execution time: 0.0541
DEBUG - 2021-04-13 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:13 --> UTF-8 Support Enabled
ERROR - 2021-04-13 17:00:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:13 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:13 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:00:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:00:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:00:20 --> Total execution time: 0.0608
DEBUG - 2021-04-13 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:20 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:00:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:20 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:00:20 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:00:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:20 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:00:20 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:00:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:00:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:00:31 --> Total execution time: 0.0466
DEBUG - 2021-04-13 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:31 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:35 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:35 --> 404 Page Not Found: Crud/update_halte
DEBUG - 2021-04-13 17:00:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:00:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:00:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:00:37 --> Total execution time: 0.0568
DEBUG - 2021-04-13 17:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:00:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:00:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:00:41 --> Total execution time: 0.0598
DEBUG - 2021-04-13 17:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:41 --> UTF-8 Support Enabled
ERROR - 2021-04-13 17:00:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:41 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:41 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:00:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:00:43 --> 404 Page Not Found: Crud/update_halte
DEBUG - 2021-04-13 17:00:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:00:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:00:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:00:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:00:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:00:44 --> Total execution time: 0.0607
DEBUG - 2021-04-13 17:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:01:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:01:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:01:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:01:08 --> Total execution time: 0.0384
DEBUG - 2021-04-13 17:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:01:08 --> UTF-8 Support Enabled
ERROR - 2021-04-13 17:01:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:01:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:01:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:01:08 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:01:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:01:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:01:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:01:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:01:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:01:08 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:01:08 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:01:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:01:09 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:01:09 --> 404 Page Not Found: Crud/update_halte
DEBUG - 2021-04-13 17:01:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:01:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:01:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:01:11 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:01:11 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:01:11 --> Total execution time: 0.0531
DEBUG - 2021-04-13 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:02:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:02:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:02:03 --> Total execution time: 0.0497
DEBUG - 2021-04-13 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:02:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:03 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:02:03 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:03 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:03 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:03 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:03 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:03 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:04 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:04 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:04 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:05 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:05 --> 404 Page Not Found: Crud/update_halte
DEBUG - 2021-04-13 17:02:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:02:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:02:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:02:06 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:02:06 --> Total execution time: 0.0365
DEBUG - 2021-04-13 17:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:02:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:02:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:02:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:02:24 --> Total execution time: 0.0629
DEBUG - 2021-04-13 17:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:24 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:24 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:24 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:25 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:02:25 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:02:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:02:25 --> UTF-8 Support Enabled
ERROR - 2021-04-13 17:02:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:02:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:26 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:02:26 --> 404 Page Not Found: Crud/update_halte
DEBUG - 2021-04-13 17:02:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:02:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:02:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:02:27 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:02:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:02:27 --> Total execution time: 0.0629
DEBUG - 2021-04-13 17:03:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:03:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:03:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:03:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:03:10 --> Total execution time: 0.0575
DEBUG - 2021-04-13 17:03:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:11 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:03:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:03:11 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:11 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:03:11 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:12 --> 404 Page Not Found: Crud/update_halte
DEBUG - 2021-04-13 17:03:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:03:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:03:13 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:03:13 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:03:13 --> Total execution time: 0.0478
DEBUG - 2021-04-13 17:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:03:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:03:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:03:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:03:25 --> Total execution time: 0.0603
DEBUG - 2021-04-13 17:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:03:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:25 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:03:25 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:03:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:03:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:03:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:03:49 --> Total execution time: 0.0394
DEBUG - 2021-04-13 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:03:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:03:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:03:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:03:49 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:03:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:03:49 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:03:49 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:04:14 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:04:14 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:04:14 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:04:14 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:04:14 --> Total execution time: 0.0373
DEBUG - 2021-04-13 17:04:14 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:04:14 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:04:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:04:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:04:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:04:15 --> UTF-8 Support Enabled
ERROR - 2021-04-13 17:04:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:04:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:04:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:04:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:04:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:04:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:04:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:04:15 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:04:15 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:04:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:04:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:04:20 --> 404 Page Not Found: Crud/update_halte
DEBUG - 2021-04-13 17:04:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:04:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:04:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:04:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:04:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:04:21 --> Total execution time: 0.0471
DEBUG - 2021-04-13 17:05:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:05:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:05:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:05:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:05:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:05:12 --> Total execution time: 0.0486
DEBUG - 2021-04-13 17:05:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:05:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:05:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:05:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:05:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:05:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:05:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:05:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:05:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:05:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:05:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:05:12 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:05:12 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:05:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:05:18 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:05:18 --> 404 Page Not Found: Crud/update_halte
DEBUG - 2021-04-13 17:05:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:05:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:05:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:05:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:05:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:05:20 --> Total execution time: 0.0352
DEBUG - 2021-04-13 17:05:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:05:25 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:05:25 --> 404 Page Not Found: Crud/update_halte
DEBUG - 2021-04-13 17:05:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:05:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:05:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:05:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:05:27 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:05:27 --> Total execution time: 0.0506
DEBUG - 2021-04-13 17:07:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:31 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:31 --> Severity: error --> Exception: syntax error, unexpected 'redirect' (T_STRING) D:\__myproject.my\SIG-trayek\application\controllers\Crud.php 76
DEBUG - 2021-04-13 17:07:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:07:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:07:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:07:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:07:39 --> Total execution time: 0.0382
DEBUG - 2021-04-13 17:07:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:39 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:07:39 --> UTF-8 Support Enabled
ERROR - 2021-04-13 17:07:39 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:39 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:07:39 --> UTF-8 Support Enabled
ERROR - 2021-04-13 17:07:39 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:39 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:39 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:39 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:07:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:07:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:07:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:07:48 --> Total execution time: 0.0381
DEBUG - 2021-04-13 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:07:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:07:48 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:48 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:07:48 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:07:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:07:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:07:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:07:53 --> Total execution time: 0.0396
DEBUG - 2021-04-13 17:07:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:53 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:07:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:07:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:07:53 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:07:53 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:08:38 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:08:38 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:08:38 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:08:38 --> Total execution time: 0.0599
DEBUG - 2021-04-13 17:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:08:38 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:38 --> UTF-8 Support Enabled
ERROR - 2021-04-13 17:08:38 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:08:38 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:38 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:08:38 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:08:38 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:38 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:38 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:08:38 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:08:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 17:08:42 --> You did not select a file to upload.
DEBUG - 2021-04-13 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:08:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:08:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:08:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:08:42 --> Total execution time: 0.0358
DEBUG - 2021-04-13 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:08:42 --> UTF-8 Support Enabled
ERROR - 2021-04-13 17:08:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:08:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:08:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:08:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:08:42 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:08:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:08:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:08:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:08:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:08:42 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:08:42 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:09:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:09:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:09:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:09:36 --> Total execution time: 0.0381
DEBUG - 2021-04-13 17:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:09:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:36 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:09:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:36 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:36 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:37 --> UTF-8 Support Enabled
ERROR - 2021-04-13 17:09:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:37 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:09:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:09:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:09:39 --> Total execution time: 0.0375
DEBUG - 2021-04-13 17:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:09:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:09:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:09:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:09:43 --> Total execution time: 0.0532
DEBUG - 2021-04-13 17:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:43 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:09:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:43 --> 404 Page Not Found: Crud/images
ERROR - 2021-04-13 17:09:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:43 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-13 17:09:43 --> 404 Page Not Found: Crud/images
DEBUG - 2021-04-13 17:09:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:09:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-13 17:09:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-13 17:09:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-13 17:09:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-13 17:09:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-13 17:09:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-13 17:09:52 --> Total execution time: 0.0382
