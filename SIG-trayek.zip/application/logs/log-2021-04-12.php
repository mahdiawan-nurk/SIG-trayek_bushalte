<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

DEBUG - 2021-04-12 09:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 09:54:20 --> No URI present. Default controller set.
DEBUG - 2021-04-12 09:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 09:54:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 09:54:20 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 09:54:20 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-12 09:54:20 --> Total execution time: 0.0373
DEBUG - 2021-04-12 09:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 09:54:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 09:54:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 09:54:20 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-12 09:54:20 --> 404 Page Not Found: Assets/css
ERROR - 2021-04-12 09:54:20 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-12 09:55:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 09:55:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 09:55:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 09:55:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 09:55:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-12 09:55:00 --> Total execution time: 0.0770
DEBUG - 2021-04-12 09:55:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 09:55:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 09:55:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 09:55:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 09:55:19 --> Total execution time: 3.5964
DEBUG - 2021-04-12 10:02:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 10:02:01 --> No URI present. Default controller set.
DEBUG - 2021-04-12 10:02:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 10:02:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 10:02:01 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 10:02:01 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-12 10:02:01 --> Total execution time: 0.0367
DEBUG - 2021-04-12 10:02:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 10:02:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 10:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-12 10:02:01 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-12 10:02:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-12 10:02:01 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-12 10:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 10:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 10:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 10:02:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 10:02:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-12 10:02:03 --> Total execution time: 0.0364
DEBUG - 2021-04-12 10:02:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 10:02:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 10:02:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 10:02:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 10:02:20 --> Total execution time: 0.9901
DEBUG - 2021-04-12 10:02:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 10:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 10:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 10:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 10:02:35 --> Total execution time: 1.0889
DEBUG - 2021-04-12 10:02:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 10:02:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 10:02:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 10:02:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 10:02:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-12 10:02:40 --> Total execution time: 0.0532
DEBUG - 2021-04-12 10:02:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 10:02:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 10:02:41 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 10:02:41 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 10:02:41 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-12 10:02:41 --> Total execution time: 0.0349
DEBUG - 2021-04-12 10:03:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 10:03:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 10:03:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 10:03:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 10:03:01 --> Total execution time: 1.0324
DEBUG - 2021-04-12 10:03:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 10:03:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 10:03:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 10:03:50 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 10:03:52 --> Total execution time: 2.5926
DEBUG - 2021-04-12 10:12:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 10:12:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 10:12:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 10:12:55 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 10:12:58 --> Total execution time: 2.6114
DEBUG - 2021-04-12 11:21:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:21:10 --> No URI present. Default controller set.
DEBUG - 2021-04-12 11:21:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:21:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:21:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 11:21:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\front\awal.php 102
DEBUG - 2021-04-12 11:21:10 --> Total execution time: 0.0653
DEBUG - 2021-04-12 11:21:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-12 11:21:10 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-12 11:21:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:21:10 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-12 11:21:10 --> 404 Page Not Found: Assets/css
DEBUG - 2021-04-12 11:21:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:21:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:21:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:21:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:21:49 --> Total execution time: 0.0511
DEBUG - 2021-04-12 11:21:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:21:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:21:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:21:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:21:52 --> Total execution time: 0.0547
DEBUG - 2021-04-12 11:21:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:21:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:21:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:21:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:21:59 --> Total execution time: 0.0404
DEBUG - 2021-04-12 11:22:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:22:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-12 11:22:01 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-12 11:22:01 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-12 11:22:01 --> 404 Page Not Found: Admin/favicon.ico
DEBUG - 2021-04-12 11:25:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:25:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:25:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:25:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:25:34 --> Total execution time: 0.0512
DEBUG - 2021-04-12 11:25:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:25:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:25:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:25:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:25:48 --> Total execution time: 0.0407
DEBUG - 2021-04-12 11:25:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:25:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:25:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:25:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:25:53 --> Total execution time: 0.0414
DEBUG - 2021-04-12 11:26:01 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:26:01 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:26:01 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:26:01 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:26:01 --> Total execution time: 0.0678
DEBUG - 2021-04-12 11:26:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:26:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:26:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:26:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:26:13 --> Total execution time: 0.0384
DEBUG - 2021-04-12 11:26:22 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:26:22 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:26:22 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:26:22 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:26:22 --> Total execution time: 0.0455
DEBUG - 2021-04-12 11:26:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:26:43 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:26:43 --> Total execution time: 0.0402
DEBUG - 2021-04-12 11:26:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:26:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:26:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:26:46 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:26:46 --> Total execution time: 0.0478
DEBUG - 2021-04-12 11:26:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:26:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:26:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:26:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:26:57 --> Total execution time: 0.0565
DEBUG - 2021-04-12 11:30:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:30:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:30:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:30:10 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:30:10 --> Total execution time: 0.0354
DEBUG - 2021-04-12 11:30:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:30:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:30:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:30:21 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:30:21 --> Total execution time: 0.0577
DEBUG - 2021-04-12 11:30:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:30:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:30:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:30:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:30:32 --> Total execution time: 0.0350
DEBUG - 2021-04-12 11:32:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:32:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:32:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:32:12 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:32:12 --> Total execution time: 0.0559
DEBUG - 2021-04-12 11:32:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:32:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:32:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:32:31 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:32:31 --> Total execution time: 0.0361
DEBUG - 2021-04-12 11:34:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:34:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:34:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:34:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:34:11 --> Total execution time: 0.0356
DEBUG - 2021-04-12 11:34:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:34:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:34:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:34:36 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:34:36 --> Total execution time: 0.0343
DEBUG - 2021-04-12 11:35:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:35:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:35:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:35:04 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:35:04 --> Total execution time: 0.0479
DEBUG - 2021-04-12 11:41:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:41:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:41:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:41:06 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:41:06 --> Total execution time: 0.0349
DEBUG - 2021-04-12 11:43:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:43:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:43:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:43:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:43:20 --> Total execution time: 0.0552
DEBUG - 2021-04-12 11:44:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:44:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:44:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:44:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:44:53 --> Total execution time: 0.0343
DEBUG - 2021-04-12 11:45:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:45:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:45:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:45:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:45:34 --> Total execution time: 0.0356
DEBUG - 2021-04-12 11:45:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:45:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:45:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:45:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:45:49 --> Total execution time: 0.0572
DEBUG - 2021-04-12 11:46:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:46:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:46:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:46:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:46:08 --> Total execution time: 0.0513
DEBUG - 2021-04-12 11:46:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:46:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:46:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:46:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:46:42 --> Total execution time: 0.0349
DEBUG - 2021-04-12 11:47:11 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:47:11 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:47:11 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:47:11 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:47:11 --> Total execution time: 0.0334
DEBUG - 2021-04-12 11:47:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:47:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:47:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:47:47 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:47:47 --> Total execution time: 0.0526
DEBUG - 2021-04-12 11:48:13 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:48:13 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:48:13 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:48:13 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:48:13 --> Total execution time: 0.0469
DEBUG - 2021-04-12 11:53:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:53:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:53:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:53:42 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:53:42 --> Total execution time: 0.0345
DEBUG - 2021-04-12 11:53:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:53:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:53:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:53:52 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:53:52 --> Total execution time: 0.0329
DEBUG - 2021-04-12 11:53:59 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 11:53:59 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 11:53:59 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 11:53:59 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 11:53:59 --> Total execution time: 0.0516
DEBUG - 2021-04-12 15:02:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:02:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:02:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:02:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:02:03 --> Total execution time: 0.0367
DEBUG - 2021-04-12 15:02:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:02:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:02:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:02:15 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:02:15 --> Total execution time: 0.0346
DEBUG - 2021-04-12 15:02:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:02:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:02:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:02:34 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:02:34 --> Total execution time: 0.0573
DEBUG - 2021-04-12 15:02:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:02:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:02:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:02:48 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:02:48 --> Total execution time: 0.0546
DEBUG - 2021-04-12 15:02:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:02:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:02:56 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:02:56 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:02:56 --> Total execution time: 0.0362
DEBUG - 2021-04-12 15:03:57 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:03:57 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:03:57 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:03:57 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:03:57 --> Total execution time: 0.0462
DEBUG - 2021-04-12 15:07:25 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:07:25 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:07:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:07:25 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:07:25 --> Total execution time: 0.0348
DEBUG - 2021-04-12 15:07:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:07:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:07:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:07:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:07:54 --> Total execution time: 0.0331
DEBUG - 2021-04-12 15:09:33 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:09:33 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:09:33 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:09:33 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:09:33 --> Total execution time: 0.0353
DEBUG - 2021-04-12 15:09:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:09:37 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-12 15:09:37 --> 404 Page Not Found: Admin/index.html
DEBUG - 2021-04-12 15:09:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:09:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:09:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:09:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:09:39 --> Total execution time: 0.0333
DEBUG - 2021-04-12 15:10:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:10:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:10:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:10:00 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:10:00 --> Total execution time: 0.0431
DEBUG - 2021-04-12 15:10:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:10:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:10:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:10:02 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:10:02 --> Total execution time: 0.0328
DEBUG - 2021-04-12 15:10:27 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:10:27 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:10:27 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:10:27 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:10:27 --> Total execution time: 0.0332
DEBUG - 2021-04-12 15:10:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:10:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:10:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:10:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:10:39 --> Total execution time: 0.0539
DEBUG - 2021-04-12 15:11:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:11:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:11:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:11:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:11:23 --> Total execution time: 0.0328
DEBUG - 2021-04-12 15:12:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:12:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:12:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:12:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:12:23 --> Total execution time: 0.0532
DEBUG - 2021-04-12 15:12:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:12:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:12:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:12:39 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:12:39 --> Total execution time: 0.0449
DEBUG - 2021-04-12 15:13:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:13:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:13:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:13:35 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:13:35 --> Total execution time: 0.0337
DEBUG - 2021-04-12 15:14:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:14:20 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:14:20 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:14:20 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:14:20 --> Total execution time: 0.0354
DEBUG - 2021-04-12 15:15:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:15:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:15:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:15:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:15:03 --> Total execution time: 0.0357
DEBUG - 2021-04-12 15:15:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:15:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:15:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:15:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:15:05 --> Total execution time: 0.0316
DEBUG - 2021-04-12 15:15:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:15:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:15:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:15:07 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:15:07 --> Total execution time: 0.0338
DEBUG - 2021-04-12 15:15:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:15:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:15:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:15:08 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:15:08 --> Total execution time: 0.0338
DEBUG - 2021-04-12 15:15:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:15:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:15:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:15:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:15:18 --> Total execution time: 0.0331
DEBUG - 2021-04-12 15:16:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:16:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:16:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:16:03 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:16:03 --> Total execution time: 0.0336
DEBUG - 2021-04-12 15:16:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:16:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:16:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:16:19 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:16:19 --> Total execution time: 0.0361
DEBUG - 2021-04-12 15:16:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:16:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:16:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:16:32 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:16:32 --> Total execution time: 0.0319
DEBUG - 2021-04-12 15:17:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:17:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:17:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:17:05 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:17:05 --> Total execution time: 0.0330
DEBUG - 2021-04-12 15:17:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:17:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:17:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:17:23 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:17:23 --> Total execution time: 0.0344
DEBUG - 2021-04-12 15:17:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:17:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:17:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:17:40 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:17:40 --> Total execution time: 0.0450
DEBUG - 2021-04-12 15:18:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:18:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:18:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:18:18 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:18:18 --> Total execution time: 0.0341
DEBUG - 2021-04-12 15:18:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:18:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:18:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:18:29 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:18:29 --> Total execution time: 0.0333
DEBUG - 2021-04-12 15:18:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:18:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:18:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:18:49 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:18:49 --> Total execution time: 0.0531
DEBUG - 2021-04-12 15:18:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:18:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:18:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:18:53 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:18:53 --> Total execution time: 0.0465
DEBUG - 2021-04-12 15:20:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:20:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:20:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:20:54 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:21:12 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:21:12 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:21:12 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:21:12 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:21:12 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:21:12 --> Total execution time: 0.0566
DEBUG - 2021-04-12 15:21:15 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:21:15 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:21:15 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:21:15 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:21:15 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:21:15 --> Total execution time: 0.0344
DEBUG - 2021-04-12 15:21:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:21:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:21:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:21:16 --> Total execution time: 0.0337
DEBUG - 2021-04-12 15:24:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:24:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:24:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:24:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:24:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:24:03 --> Total execution time: 0.0471
DEBUG - 2021-04-12 15:24:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:24:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:24:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:24:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:24:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:24:04 --> Total execution time: 0.0356
DEBUG - 2021-04-12 15:24:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:24:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:24:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:24:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:24:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:24:16 --> Total execution time: 0.0378
DEBUG - 2021-04-12 15:24:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:24:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:24:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:24:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:24:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:24:18 --> Total execution time: 0.0342
DEBUG - 2021-04-12 15:24:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:24:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:24:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:24:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:24:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:24:19 --> Total execution time: 0.0454
DEBUG - 2021-04-12 15:25:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:25:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:25:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:25:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:25:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:25:16 --> Total execution time: 0.0345
DEBUG - 2021-04-12 15:25:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:25:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:25:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:25:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:25:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:25:17 --> Total execution time: 0.0569
DEBUG - 2021-04-12 15:26:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:26:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:26:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:26:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:26:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:26:39 --> Total execution time: 0.0461
DEBUG - 2021-04-12 15:26:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:26:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:26:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:26:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:26:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:26:43 --> Total execution time: 0.0523
DEBUG - 2021-04-12 15:26:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:26:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:26:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:26:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:26:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:26:44 --> Total execution time: 0.0472
DEBUG - 2021-04-12 15:26:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:26:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:26:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:26:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:26:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:26:52 --> Total execution time: 0.0342
DEBUG - 2021-04-12 15:26:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:26:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:26:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:26:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:26:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:26:55 --> Total execution time: 0.0349
DEBUG - 2021-04-12 15:28:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:28:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:28:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:28:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:28:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:28:23 --> Total execution time: 0.0587
DEBUG - 2021-04-12 15:31:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:31:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:31:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:31:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:31:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:31:49 --> Total execution time: 0.0354
DEBUG - 2021-04-12 15:31:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:31:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:31:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:31:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:31:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:31:52 --> Total execution time: 0.0331
DEBUG - 2021-04-12 15:31:53 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:31:53 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:31:53 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:31:53 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:31:53 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:31:53 --> Total execution time: 0.0442
DEBUG - 2021-04-12 15:32:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:32:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:32:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:32:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:32:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:32:03 --> Total execution time: 0.0555
DEBUG - 2021-04-12 15:34:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:34:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:34:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:34:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:34:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:34:26 --> Total execution time: 0.0530
DEBUG - 2021-04-12 15:34:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:34:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:34:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:34:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:34:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:34:34 --> Total execution time: 0.0346
DEBUG - 2021-04-12 15:35:20 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:35:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:35:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:35:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:35:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:35:21 --> Total execution time: 0.0338
DEBUG - 2021-04-12 15:35:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:35:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:35:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:35:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:35:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:35:36 --> Total execution time: 0.0351
DEBUG - 2021-04-12 15:35:37 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:35:37 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:35:37 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:35:37 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:35:37 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 207
DEBUG - 2021-04-12 15:35:37 --> Total execution time: 0.0337
DEBUG - 2021-04-12 15:37:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:37:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:37:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:37:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:37:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:37:26 --> Total execution time: 0.0358
DEBUG - 2021-04-12 15:37:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:37:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:37:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:37:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 15:38:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:38:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:38:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:38:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:38:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:38:51 --> Total execution time: 0.0758
DEBUG - 2021-04-12 15:38:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:38:52 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-12 15:38:52 --> 404 Page Not Found: Admin/datarute
DEBUG - 2021-04-12 15:39:02 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:39:02 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:39:02 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:39:02 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:39:02 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:39:02 --> Total execution time: 0.0350
DEBUG - 2021-04-12 15:39:04 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:39:04 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:39:04 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:39:04 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:39:04 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:39:04 --> Total execution time: 0.0595
DEBUG - 2021-04-12 15:39:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:39:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:39:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:39:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:39:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:39:05 --> Total execution time: 0.0364
DEBUG - 2021-04-12 15:39:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:39:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:39:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:39:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:39:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:39:07 --> Total execution time: 0.0496
DEBUG - 2021-04-12 15:39:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:39:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:39:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:39:30 --> Total execution time: 0.0342
DEBUG - 2021-04-12 15:39:30 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:39:30 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:39:30 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:39:30 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:39:30 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:39:30 --> Total execution time: 0.0344
DEBUG - 2021-04-12 15:39:32 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:39:32 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:39:32 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:39:32 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:39:32 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:39:32 --> Total execution time: 0.0333
DEBUG - 2021-04-12 15:39:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:39:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:39:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:39:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:39:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:39:35 --> Total execution time: 0.0579
DEBUG - 2021-04-12 15:39:41 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:39:41 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:39:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:39:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:39:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:39:42 --> Total execution time: 0.0451
DEBUG - 2021-04-12 15:40:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:40:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:40:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:40:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:40:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:40:45 --> Total execution time: 0.0473
DEBUG - 2021-04-12 15:40:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:40:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:40:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:40:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:40:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:40:47 --> Total execution time: 0.0355
DEBUG - 2021-04-12 15:40:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:40:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:40:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:40:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:40:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:40:48 --> Total execution time: 0.0362
DEBUG - 2021-04-12 15:40:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:40:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:40:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:40:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:40:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:40:50 --> Total execution time: 0.0530
DEBUG - 2021-04-12 15:42:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:42:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:42:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:42:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:42:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:42:26 --> Total execution time: 0.0334
DEBUG - 2021-04-12 15:42:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:42:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:42:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:42:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:42:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:42:28 --> Total execution time: 0.0489
DEBUG - 2021-04-12 15:42:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:42:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:42:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:42:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:42:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:42:29 --> Total execution time: 0.0354
DEBUG - 2021-04-12 15:43:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:43:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:43:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:43:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:43:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:43:24 --> Total execution time: 0.0358
DEBUG - 2021-04-12 15:43:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:43:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:43:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:43:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:43:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:43:42 --> Total execution time: 0.0542
DEBUG - 2021-04-12 15:43:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:43:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:43:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:43:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:43:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 210
DEBUG - 2021-04-12 15:43:43 --> Total execution time: 0.0355
DEBUG - 2021-04-12 15:46:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:46:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:46:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:46:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:46:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:46:21 --> Total execution time: 0.0360
DEBUG - 2021-04-12 15:46:23 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:46:23 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:46:23 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:46:23 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:46:23 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:46:23 --> Total execution time: 0.0346
DEBUG - 2021-04-12 15:46:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:46:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:46:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:46:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:46:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:46:45 --> Total execution time: 0.0360
DEBUG - 2021-04-12 15:46:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:46:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:46:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:46:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:46:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:46:46 --> Total execution time: 0.0452
DEBUG - 2021-04-12 15:46:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:46:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:46:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:46:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:46:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:46:48 --> Total execution time: 0.0346
DEBUG - 2021-04-12 15:46:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:46:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:46:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:46:49 --> Total execution time: 0.0547
DEBUG - 2021-04-12 15:46:49 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:46:49 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:46:49 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:46:49 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:46:49 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:46:49 --> Total execution time: 0.0344
DEBUG - 2021-04-12 15:46:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:46:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:46:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:46:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:46:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:46:51 --> Total execution time: 0.0582
DEBUG - 2021-04-12 15:47:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:47:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:47:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:47:34 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:47:34 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:47:34 --> Total execution time: 0.0514
DEBUG - 2021-04-12 15:47:35 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:47:35 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:47:35 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:47:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:47:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:47:35 --> Total execution time: 0.0546
DEBUG - 2021-04-12 15:47:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:47:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:47:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:47:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:47:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:47:36 --> Total execution time: 0.0409
DEBUG - 2021-04-12 15:51:42 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:51:42 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:51:42 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:51:42 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:51:42 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:51:42 --> Total execution time: 0.0580
DEBUG - 2021-04-12 15:51:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:51:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:51:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:51:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:51:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:51:43 --> Total execution time: 0.0546
DEBUG - 2021-04-12 15:51:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:51:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:51:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:51:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:51:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:51:44 --> Total execution time: 0.0528
DEBUG - 2021-04-12 15:51:45 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:51:45 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:51:45 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:51:45 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:51:45 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:51:45 --> Total execution time: 0.0340
DEBUG - 2021-04-12 15:51:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:51:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:51:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:51:46 --> Total execution time: 0.0354
DEBUG - 2021-04-12 15:51:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:51:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:51:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:51:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:51:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:51:46 --> Total execution time: 0.0512
DEBUG - 2021-04-12 15:51:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:51:47 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:51:47 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:51:47 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:51:47 --> Total execution time: 0.0517
DEBUG - 2021-04-12 15:51:47 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:51:47 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:51:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:51:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:51:48 --> Total execution time: 0.0587
DEBUG - 2021-04-12 15:51:48 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:51:48 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:51:48 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:51:48 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:51:48 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:51:48 --> Total execution time: 0.0362
DEBUG - 2021-04-12 15:51:52 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:51:52 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:51:52 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:51:52 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:51:52 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:51:52 --> Total execution time: 0.0336
DEBUG - 2021-04-12 15:52:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:52:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:52:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:52:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:52:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:52:29 --> Total execution time: 0.0354
DEBUG - 2021-04-12 15:52:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:52:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:52:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:52:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:52:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:52:58 --> Total execution time: 0.0386
DEBUG - 2021-04-12 15:54:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:54:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:54:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:54:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:54:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:54:19 --> Total execution time: 0.0346
DEBUG - 2021-04-12 15:54:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 15:54:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 15:54:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 15:54:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 15:54:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 15:54:24 --> Total execution time: 0.0340
DEBUG - 2021-04-12 16:02:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:02:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:02:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:02:28 --> Encryption: Auto-configured driver 'openssl'.
DEBUG - 2021-04-12 16:02:28 --> Total execution time: 0.0700
DEBUG - 2021-04-12 16:03:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:03:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:03:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:03:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:03:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:03:21 --> Total execution time: 0.0477
DEBUG - 2021-04-12 16:03:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:03:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:03:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:03:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:03:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:03:29 --> Total execution time: 0.0551
DEBUG - 2021-04-12 16:03:34 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:03:34 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:03:34 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:03:35 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:03:35 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:03:35 --> Total execution time: 0.0575
DEBUG - 2021-04-12 16:04:03 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:04:03 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:04:03 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:04:03 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:04:03 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:04:03 --> Total execution time: 0.0370
DEBUG - 2021-04-12 16:05:28 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:05:28 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:05:28 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:05:28 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:05:28 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:05:28 --> Total execution time: 0.0486
DEBUG - 2021-04-12 16:06:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:06:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:06:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:06:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:06:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:06:31 --> Total execution time: 0.0550
DEBUG - 2021-04-12 16:06:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:06:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:06:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:06:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:06:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:06:40 --> Total execution time: 0.0379
DEBUG - 2021-04-12 16:07:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:07:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:07:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:07:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:07:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:07:17 --> Total execution time: 0.0379
DEBUG - 2021-04-12 16:07:26 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:07:26 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:07:26 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:07:26 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:07:26 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:07:26 --> Total execution time: 0.0459
DEBUG - 2021-04-12 16:07:36 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:07:36 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:07:36 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:07:36 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:07:36 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:07:36 --> Total execution time: 0.0553
DEBUG - 2021-04-12 16:08:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:08:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:08:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:08:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:08:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:08:55 --> Total execution time: 0.0366
DEBUG - 2021-04-12 16:09:08 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:09:08 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:09:08 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:09:08 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:09:08 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:09:08 --> Total execution time: 0.0382
DEBUG - 2021-04-12 16:09:44 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:09:44 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:09:44 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:09:44 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:09:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:09:44 --> Total execution time: 0.0611
DEBUG - 2021-04-12 16:09:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:09:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:09:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:09:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:09:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:09:51 --> Total execution time: 0.0390
DEBUG - 2021-04-12 16:10:05 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:10:05 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:10:05 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:10:05 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:10:05 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:10:05 --> Total execution time: 0.0565
DEBUG - 2021-04-12 16:10:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:10:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:10:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:10:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:10:44 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:10:44 --> Total execution time: 0.0377
DEBUG - 2021-04-12 16:12:54 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:12:54 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:12:54 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:12:54 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:12:54 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:12:54 --> Total execution time: 0.0535
DEBUG - 2021-04-12 16:13:39 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:13:39 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:13:39 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:13:39 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:13:39 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:13:39 --> Total execution time: 0.0513
DEBUG - 2021-04-12 16:14:17 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:14:17 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:14:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:14:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:14:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:14:17 --> Total execution time: 0.0371
DEBUG - 2021-04-12 16:14:18 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:14:18 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:14:18 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:14:18 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:14:18 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:14:18 --> Total execution time: 0.0361
DEBUG - 2021-04-12 16:14:19 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:14:19 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:14:19 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:14:19 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:14:19 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:14:19 --> Total execution time: 0.0354
DEBUG - 2021-04-12 16:14:21 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:14:21 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:14:21 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:14:21 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:14:21 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:14:21 --> Total execution time: 0.0373
DEBUG - 2021-04-12 16:14:40 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:14:40 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:14:40 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:14:40 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:14:40 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:14:40 --> Total execution time: 0.0368
DEBUG - 2021-04-12 16:15:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:15:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:15:17 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:15:17 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:15:17 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:15:17 --> Total execution time: 0.0369
DEBUG - 2021-04-12 16:15:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:15:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:15:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:15:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:15:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:15:31 --> Total execution time: 0.0361
DEBUG - 2021-04-12 16:16:10 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:16:10 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:16:10 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:16:10 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:16:10 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:16:10 --> Total execution time: 0.0387
DEBUG - 2021-04-12 16:17:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:17:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:17:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:17:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:17:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:17:00 --> Total execution time: 0.0456
DEBUG - 2021-04-12 16:19:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:19:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:19:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:19:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:19:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:19:09 --> Total execution time: 0.0564
DEBUG - 2021-04-12 16:19:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:19:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:19:25 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:19:25 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:19:25 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:19:25 --> Total execution time: 0.0581
DEBUG - 2021-04-12 16:19:51 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:19:51 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:19:51 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:19:51 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:19:51 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:19:51 --> Total execution time: 0.0609
DEBUG - 2021-04-12 16:19:58 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:19:58 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:19:58 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:19:58 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:19:58 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:19:58 --> Total execution time: 0.0556
DEBUG - 2021-04-12 16:20:06 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:20:06 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:20:06 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:20:06 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:20:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:20:07 --> Total execution time: 0.0361
DEBUG - 2021-04-12 16:21:16 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:21:16 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:21:16 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:21:16 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:21:16 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:21:16 --> Total execution time: 0.0542
DEBUG - 2021-04-12 16:22:50 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:22:50 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:22:50 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:22:50 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:22:50 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:22:50 --> Total execution time: 0.0591
DEBUG - 2021-04-12 16:23:43 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:23:43 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:23:43 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:23:43 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:23:43 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:23:43 --> Total execution time: 0.0600
DEBUG - 2021-04-12 16:23:46 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:23:46 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:23:46 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:23:46 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:23:46 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:23:46 --> Total execution time: 0.0365
DEBUG - 2021-04-12 16:23:55 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:23:55 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:23:55 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:23:55 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:23:55 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:23:55 --> Total execution time: 0.0489
DEBUG - 2021-04-12 16:23:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:23:56 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:23:56 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:23:56 --> Global POST, GET and COOKIE data sanitized
ERROR - 2021-04-12 16:23:56 --> 404 Page Not Found: Admin/favicon.ico
ERROR - 2021-04-12 16:23:56 --> 404 Page Not Found: Admin/apple-icon.png
DEBUG - 2021-04-12 16:24:00 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:24:00 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:24:00 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:24:00 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:24:00 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:24:00 --> Total execution time: 0.0436
DEBUG - 2021-04-12 16:24:24 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:24:24 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:24:24 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:24:24 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:24:24 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:24:24 --> Total execution time: 0.0378
DEBUG - 2021-04-12 16:24:29 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:24:29 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:24:29 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:24:29 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:24:29 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:24:29 --> Total execution time: 0.0383
DEBUG - 2021-04-12 16:25:07 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:25:07 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:25:07 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:25:07 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:25:07 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:25:07 --> Total execution time: 0.0392
DEBUG - 2021-04-12 16:25:09 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:25:09 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:25:09 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:25:09 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:25:09 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:25:09 --> Total execution time: 0.0547
DEBUG - 2021-04-12 16:25:31 --> UTF-8 Support Enabled
DEBUG - 2021-04-12 16:25:31 --> Global POST, GET and COOKIE data sanitized
DEBUG - 2021-04-12 16:25:31 --> Session: "sess_save_path" is empty; using "session.save_path" value from php.ini.
DEBUG - 2021-04-12 16:25:31 --> Encryption: Auto-configured driver 'openssl'.
ERROR - 2021-04-12 16:25:31 --> Severity: 4096 --> Object of class CI_Loader could not be converted to string D:\__myproject.my\SIG-trayek\application\views\backend\template.php 212
DEBUG - 2021-04-12 16:25:31 --> Total execution time: 0.0365
