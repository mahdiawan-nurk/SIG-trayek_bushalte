###################
What is SIG TRAYEK BUS
###################

Sistem informasi geografis untuk informasi trayek bus sekolah dan halte di central business district (CBD) Bangkinang yang akan dibuat berisikan fitur-fitur seperti: Menampilkan trayek bus sekolah yang ada di bangkinag terdapat 5 bus sekolah, menampilkn jarak tempuh, menampilkan jam keberangkatan pulang dan pergi,  menampilkan titik Halte, deskripsi halte. Dengan adanya  sistem informasi geografis untuk informasi trayek bus sekolah dan halte diharapkan masyarakat bisa mengetahui informasi tentang jalur-jalur arah rute bus sekolah bahkan halte di Bangkinag dengan fiture-fitur yang disediakan di sitem informasi geografis. 

*******************
VERSION APPS v-0.1
*******************



